#!/usr/bin/env python3


#  /$$   /$$  /$$$$$$  /$$$$$$$  /$$                                  
# | $$  | $$ /$$__  $$| $$__  $$|__/                                  
# | $$  | $$| $$  \__/| $$  \ $$ /$$  /$$$$$$                         
# | $$$$$$$$|  $$$$$$ | $$  | $$| $$ /$$__  $$                        
# | $$__  $$ \____  $$| $$  | $$| $$| $$  \__/                        
# | $$  | $$ /$$  \ $$| $$  | $$| $$| $$                              
# | $$  | $$|  $$$$$$/| $$$$$$$/| $$| $$                              
# |__/  |__/ \______/ |_______/ |__/|__/                              
                                                                    
                                                                    
                                                                    
#   /$$$$$$                      /$$                     /$$          
#  /$$__  $$                    | $$                    |__/          
# | $$  \ $$ /$$$$$$$   /$$$$$$ | $$ /$$   /$$  /$$$$$$$ /$$  /$$$$$$$
# | $$$$$$$$| $$__  $$ |____  $$| $$| $$  | $$ /$$_____/| $$ /$$_____/
# | $$__  $$| $$  \ $$  /$$$$$$$| $$| $$  | $$|  $$$$$$ | $$|  $$$$$$ 
# | $$  | $$| $$  | $$ /$$__  $$| $$| $$  | $$ \____  $$| $$ \____  $$
# | $$  | $$| $$  | $$|  $$$$$$$| $$|  $$$$$$$ /$$$$$$$/| $$ /$$$$$$$/
# |__/  |__/|__/  |__/ \_______/|__/ \____  $$|_______/ |__/|_______/ 
#                                    /$$  | $$                        
#                                   |  $$$$$$/                        
#

import os
import ast
import json
import ipaddress
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

target_files = [
    "network_hsdir_consensus_snapshots.jsonl",
    "hsdir_ring_events.jsonl",
    "tracked_hsdir_consensus_snapshots.jsonl",
    "rotated_network_hsdir_consensus_snapshots.jsonl",
    "rotated_tracked_hsdir_consensus_snapshots.jsonl"
]

def extract_telemetry(target_filename):
    output_csv = target_filename.replace('.jsonl', '.csv')
    print(f"[EXTRACT-INFO] Ingesting log from source stream: {target_filename}")
    
    consolidated_records = []
    
    with open(target_filename, 'r') as source_file:
        for index, text_line in enumerate(source_file):
            if not text_line.strip():
                continue
            try:
                parsed_json = json.loads(text_line)
            except json.JSONDecodeError as err:
                print(f"[EXTRACT-ERROR] Malformed line entry skipped {index}: {err}")
                continue

            base_timestamp = parsed_json.get("timestamp")
            captured_onion = parsed_json.get("onion_address", None)
            
            nested_array_key = None
            if "relays" in parsed_json:
                nested_array_key = "relays"
                
            if nested_array_key:
                sub_records = parsed_json.get(nested_array_key, [])
                for entry in sub_records:
                    flattened_item = entry.copy()
                    flattened_item["timestamp"] = base_timestamp
                    if captured_onion:
                        flattened_item["onion_address"] = captured_onion
                    consolidated_records.append(flattened_item)
            else:
                consolidated_records.append(parsed_json)
                
    if not consolidated_records:
        print(f"[EXTRACT-WARNING] No usable records extracted from {target_filename}.")
        return False
        
    df_processed = pd.DataFrame(consolidated_records)
    
    if "timestamp" in df_processed.columns:
        parsed_datetimes = pd.to_datetime(df_processed["timestamp"], errors='coerce')
        df_processed["date"] = parsed_datetimes.dt.strftime("%m-%d")
        df_processed["hour"] = parsed_datetimes.dt.strftime("%H:%M")
        
    if "or_port" in df_processed.columns:
        df_processed.drop(columns=["or_port"], inplace=True, errors='ignore')

    if "declared_family_id" in df_processed.columns:
        df_processed["declared_family_id"] = df_processed["declared_family_id"].astype(str).replace(['nan', 'NaN', 'None', '0', '0.0', '', ' '], 'None')
        df_processed["declared_family_id"] = df_processed["declared_family_id"].fillna('None')
    else:
        df_processed["declared_family_id"] = 'None'

    if "declared_family" in df_processed.columns:
        def clean_initial_family(val):
            if isinstance(val, (list, tuple, np.ndarray)):
                return list(val)
                
            if pd.isna(val) or val is None or val in ['None', 'nan', 'NaN', '[]', '', ' ']:
                return []
                
            if isinstance(val, str):
                val_stripped = val.strip()
                if val_stripped.startswith('[') and val_stripped.endswith(']'):
                    try:
                        parsed = ast.literal_eval(val_stripped)
                        if isinstance(parsed, list):
                            return parsed
                    except Exception:
                        pass
                return [val_stripped]
            return []
            
        df_processed["declared_family"] = df_processed["declared_family"].apply(clean_initial_family)
    else:
        df_processed["declared_family"] = [[] for _ in range(len(df_processed))]
        
    for col in df_processed.columns:
        if col == "declared_family":
            continue
        if df_processed[col].dtype == 'object':
            df_processed[col] = df_processed[col].astype(str).replace(['nan', '0', '0.0', '', ' '], 'None')
        elif pd.api.types.is_numeric_dtype(df_processed[col]):
            df_processed[col] = df_processed[col].fillna(0)
        else:
            df_processed[col] = df_processed[col].fillna('None')
    
    df_processed.to_csv(output_csv, index=False)
    print(f"    --> Normalized and written to disk: {output_csv} [Rows: {len(df_processed)}]")
    return True

def validate_sort_data(csv_path):
    if not os.path.exists(csv_path):
        print(f"[VERIFY-ERROR] Target file unavailable: {csv_path}")
        return None
    
    df = pd.read_csv(csv_path, low_memory=False)
    
    for col in df.columns:
        if col in ['ip_address', 'fingerprint', 'status', 'onion_address', 'action', 'reason', 'declared_family_id', 'timestamp_dropped', 'service_type']:
            df[col] = df[col].fillna('None').astype(str)
            df[col] = df[col].replace(['nan', 'NaN', 'None', ''], 'None')
            
    if "declared_family" in df.columns:
        def parse_csv_family_list(val):
            if isinstance(val, (list, tuple, np.ndarray)):
                return list(val)
            if pd.isna(val) or val is None:
                return []
            val_str = str(val).strip()
            if val_str in ['None', 'nan', 'NaN', '', '[]']:
                return []
            if val_str.startswith('[') and val_str.endswith(']'):
                try:
                    parsed = ast.literal_eval(val_str)
                    if isinstance(parsed, list):
                        return parsed
                except Exception:
                    pass
            return [val_str]
        df["declared_family"] = df["declared_family"].apply(parse_csv_family_list)
    else:
        df["declared_family"] = [[] for _ in range(len(df))]

    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df = df.sort_values('timestamp').reset_index(drop=True)
    
    sort_columns = []
    if "date" in df.columns:
        sort_columns.append("date")
    if "hour" in df.columns:
        sort_columns.append("hour")
    if "fingerprint" in df.columns:
        sort_columns.append("fingerprint")
        
    if sort_columns:
        df.sort_values(by=sort_columns, inplace=True)
        df.reset_index(drop=True, inplace=True)
        
    if "date" in df.columns and not df.empty:
        unique_calendar_dates = df["date"].unique()
        unique_calendar_dates = [d for d in unique_calendar_dates if d not in ['', 'nan', 'None']]
        
        date_normalization_map = {date_str: f"Day {idx + 1}" for idx, date_str in enumerate(unique_calendar_dates)}
        df["date"] = df["date"].map(date_normalization_map).fillna(df["date"])
        
    print(f"[VERIFIED-INFO] File loaded: {csv_path} | Dimension Profile: {df.shape}")
    return df


# ---------------------------------------------------------------------------
# Sybil distribution analysis (family-id and IP based)
# ---------------------------------------------------------------------------

def _chronological_days(df):
    """
    Return the distinct values of df['date'] ordered chronologically.
    Post-validate_sort_data(), 'date' holds sequential "Day N" labels, so we
    sort on the numeric N rather than lexicographically (which would put
    "Day 10" before "Day 2"). Any value that doesn't match "Day N" is kept
    but sorted to the end, so nothing is silently dropped.
    """
    days = list(pd.unique(df['date']))

    def day_key(d):
        try:
            return int(str(d).split(' ')[1])
        except (IndexError, ValueError):
            return float('inf')

    return sorted(days, key=day_key)


def _plot_sybil_series(df, group_col, top_group_ids, output_path, title, metric_label):
    """
    Save one figure with, per entry in `top_group_ids`, a solid line for its
    absolute per-day unique-fingerprint count (left axis) and a dashed line
    for its per-day network share (right, twin axis) -- both in the same
    color per group so the two series are easy to pair up visually.

    Network share for a given day is that group's unique-fingerprint count
    on that day divided by the unique-fingerprint count across the WHOLE
    `df` (all groups, including the excluded "None"/ungrouped bucket) on
    that day -- i.e. the daily counterpart of the overall network-share
    figure printed to the terminal, so both numbers describe "share of the
    total observed network" rather than "share among only the top groups".
    """
    days = _chronological_days(df)

    daily_group_counts = (
        df[df[group_col].isin(top_group_ids)]
        .groupby(['date', group_col])['fingerprint']
        .nunique()
    )
    daily_totals = df.groupby('date')['fingerprint'].nunique()

    fig, ax1 = plt.subplots(figsize=(11, 6))
    ax2 = ax1.twinx()
    colors = plt.cm.tab10.colors

    for i, group_id in enumerate(top_group_ids):
        color = colors[i % len(colors)]

        counts = [daily_group_counts.get((day, group_id), 0) for day in days]
        totals = [daily_totals.get(day, 0) for day in days]
        # Days with zero total nodes (shouldn't normally happen) or zero
        # nodes for this group both yield a share of 0, never a ZeroDivisionError.
        shares = [(c / t) if t else 0.0 for c, t in zip(counts, totals)]

        legend_id = str(group_id)
        if len(legend_id) > 18:
            legend_id = legend_id[:15] + "..."

        ax1.plot(days, counts, linestyle='-', marker='o', color=color,
                  label=f"{legend_id} (count)")
        ax2.plot(days, shares, linestyle='--', marker='s', color=color,
                  label=f"{legend_id} (share)")

    ax1.set_xlabel("Day")
    ax1.set_ylabel(f"Unique fingerprint count — solid  ({metric_label})")
    ax2.set_ylabel("Network share — dashed")
    ax1.set_title(title)
    ax1.tick_params(axis='x', rotation=45)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=8,
               loc='upper left', bbox_to_anchor=(1.1, 1))

    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path, bbox_inches='tight')
    plt.close(fig)
    print(f"    --> Saved plot: {output_path}")


def _sybil_top5_report_and_plot(df, group_col, label, output_path, metric_label=None,
                                 exclude_none_bucket=True):
    """
    Shared logic for both deliverables: rank `group_col` values by unique
    -fingerprint count, print the top 5 (full id + absolute count + overall
    network share), and save the per-day count/share figure.

    The "None" bucket (declared_family_id == 'None' means no declared
    family -- i.e. a non-sybil singleton node; ip_address/subnet == 'None'
    means missing/unusable address data) is excluded from the ranking by
    default: for family IDs specifically, singleton nodes would otherwise
    dominate every ranking and defeat the point of a sybil-cluster view.
    Set exclude_none_bucket=False to include it if that's ever useful.
    """
    if metric_label is None:
        metric_label = group_col

    total_unique = df['fingerprint'].nunique()
    scoped = df[df[group_col] != 'None'] if exclude_none_bucket else df

    if scoped.empty:
        print(f"[SYBIL-INFO] No usable '{metric_label}' groups for {label}; skipping.")
        return

    group_counts = scoped.groupby(group_col)['fingerprint'].nunique().sort_values(ascending=False)
    top_groups = group_counts.head(5)

    print(f"\n[SYBIL] Top {metric_label} groups — {label}")
    for group_id, count in top_groups.items():
        share = (count / total_unique) if total_unique else 0.0
        print(f"    {group_id}: {count} unique nodes  (network share: {share:.4%})")

    _plot_sybil_series(
        df, group_col, list(top_groups.index), output_path,
        title=f"{label} — {metric_label} sybil distribution",
        metric_label=metric_label,
    )


def family_id_sybil_distributions(df, context_label):
    """
    Deliverable A. For `df` (network-wide or tracked, post-validate_sort_data
    shape), rank declared_family_id groups by unique-fingerprint count,
    print the top 5 with their overall network share, and save a per-day
    count/share figure to
    analysis-results/sybil/family-id/{context_label}_family_id_sybil.png.

    When context_label == "tracked", additionally repeats the same
    analysis once per distinct service_type, saved to
    analysis-results/sybil/family-id/{service_type_lower}_family_id_sybil.png.
    """
    base_dir = os.path.join("analysis-results", "sybil", "family-id")

    _sybil_top5_report_and_plot(
        df, 'declared_family_id', context_label,
        os.path.join(base_dir, f"{context_label}_family_id_sybil.png"),
        metric_label="declared_family_id",
    )

    if context_label == "tracked" and 'service_type' in df.columns:
        service_types = sorted(t for t in df['service_type'].dropna().unique() if t not in ('None', ''))
        for service_type in service_types:
            subset = df[df['service_type'] == service_type]
            _sybil_top5_report_and_plot(
                subset, 'declared_family_id', f"tracked — {service_type}",
                os.path.join(base_dir, f"{service_type.lower()}_family_id_sybil.png"),
                metric_label="declared_family_id",
            )


def _to_24_subnet(ip_str):
    """
    Derive the /24 subnet string for an IPv4 address (e.g. '192.168.2.12'
    -> '192.168.2.0/24') using the standard ipaddress module. Missing,
    'None', or malformed/non-IPv4 address text is normalized to the
    literal string 'None' so it's excluded the same way a missing
    declared_family_id is elsewhere in this file.
    """
    if ip_str in (None, 'None', ''):
        return 'None'
    try:
        return str(ipaddress.ip_network(f"{ip_str}/24", strict=False))
    except ValueError:
        return 'None'


def ip_sybil_distributions(df, context_label):
    """
    Deliverable B. Same structure as family_id_sybil_distributions, but
    groups by IP-based identity instead of declared_family_id, in two
    variants: exact ip_address, and the derived /24 subnet. Saved under
    analysis-results/sybil/ip_sybil/ as
    {context_label}_ip_sybil.png / {context_label}_ip_24_subnet_sybil.png
    (and, for context_label == "tracked", additionally per service_type as
    {service_type_lower}_ip_sybil.png / {service_type_lower}_ip_24_subnet_sybil.png).
    """
    base_dir = os.path.join("analysis-results", "sybil", "ip_sybil")

    working = df.copy()
    working['_ip_24_subnet'] = working['ip_address'].apply(_to_24_subnet)

    def run_both_variants(sub_df, label, filename_prefix):
        _sybil_top5_report_and_plot(
            sub_df, 'ip_address', label,
            os.path.join(base_dir, f"{filename_prefix}_ip_sybil.png"),
            metric_label="ip_address",
        )
        _sybil_top5_report_and_plot(
            sub_df, '_ip_24_subnet', label,
            os.path.join(base_dir, f"{filename_prefix}_ip_24_subnet_sybil.png"),
            metric_label="/24 subnet",
        )

    run_both_variants(working, context_label, context_label)

    if context_label == "tracked" and 'service_type' in working.columns:
        service_types = sorted(t for t in working['service_type'].dropna().unique() if t not in ('None', ''))
        for service_type in service_types:
            subset = working[working['service_type'] == service_type]
            run_both_variants(subset, f"tracked — {service_type}", service_type.lower())


def service_type_overlap_diagnostic(df, context_label):
    """
    Diagnostic: explains why per-service_type unique-fingerprint counts
    (as printed inside family_id_sybil_distributions / ip_sybil_distributions
    for the tracked DataFrame) don't sum to the overall tracked
    unique-fingerprint count.

    Each row in the tracked data is a (relay, mapped_onion) pairing, not
    one row per physical relay -- so a single relay's fingerprint can
    appear under more than one service_type if it acts as HSDir for
    onions in different service_type buckets (at the same time, or at
    different points across the tracked period). That relay is correctly
    counted once in EACH per-service_type subset it touches, but only
    once in the overall count -- so subsets overlap and their counts are
    not additive. This function quantifies that overlap directly:

    - groups by `fingerprint` and collects the *set* of distinct
      service_type values each one was ever seen under in `df`
    - reports how many relays touch only one service_type vs. 2+ 
    - breaks that down by the exact combination (e.g.
      "EPHEMERAL_VARIABLE + STATIC_CONTROL": N relays)

    Only meaningful where `service_type` exists (the tracked DataFrame --
    network-wide data has no such column, so it's skipped there). Prints
    the summary and combination breakdown to the terminal, and saves the
    full breakdown as a CSV so exact figures can be cited in the thesis
    ("N relays / N% of tracked relays served more than one service_type
    over the study period") at
    analysis-results/sybil/{context_label}_service_type_overlap.csv.
    Returns the breakdown as a DataFrame (None if service_type isn't
    present).
    """
    if 'service_type' not in df.columns:
        print(f"[OVERLAP-INFO] '{context_label}' has no service_type column; skipping diagnostic.")
        return None

    fp_service_sets = (
        df.groupby('fingerprint')['service_type']
        .apply(lambda s: frozenset(t for t in s.unique() if t not in ('None', '')))
    )
    fp_service_sets = fp_service_sets[fp_service_sets.apply(len) > 0]

    total_relays = len(fp_service_sets)
    if total_relays == 0:
        print(f"[OVERLAP-INFO] No relays with a usable service_type for {context_label}; skipping diagnostic.")
        return None

    overlap_mask = fp_service_sets.apply(len) > 1
    overlap_relays = int(overlap_mask.sum())

    print(f"\n[OVERLAP] service_type overlap — {context_label}")
    print(f"    total distinct relays (any service_type): {total_relays}")
    print(f"    relays touching 2+ service_types: {overlap_relays} "
          f"({overlap_relays / total_relays:.2%} of {total_relays})")

    combo_counts = fp_service_sets.value_counts()
    combo_rows = [
        {
            'service_type_combination': " + ".join(sorted(combo)),
            'num_service_types': len(combo),
            'relay_count': count,
        }
        for combo, count in combo_counts.items()
    ]
    combo_df = pd.DataFrame(combo_rows).sort_values(
        ['num_service_types', 'relay_count'], ascending=[False, False]
    ).reset_index(drop=True)

    print("    breakdown by exact combination:")
    for _, row in combo_df.iterrows():
        print(f"      {row['service_type_combination']}: {row['relay_count']} relays")

    out_dir = os.path.join("analysis-results", "sybil")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"{context_label}_service_type_overlap.csv")
    combo_df.to_csv(out_path, index=False)
    print(f"    --> Saved diagnostic table: {out_path}")

    return combo_df


# ---------------------------------------------------------------------------
# Entity-drop distribution analysis (family-id and IP based)
# ---------------------------------------------------------------------------

def _chronological_snapshots(df):
    """
    Return the distinct (date, hour) pairs in `df`, in chronological order:
    by "Day N" number first, then by the literal "HH:MM" hour string within
    each day (which sorts correctly as-is since it's always zero-padded
    24h time). Snapshot cadence is whatever the data actually has -- e.g.
    every 1h in one file, every 2h in another -- so this makes no
    assumption of a fixed interval or a fixed 24-snapshot day.
    """
    pairs = df[['date', 'hour']].drop_duplicates()

    def day_key(d):
        try:
            return int(str(d).split(' ')[1])
        except (IndexError, ValueError):
            return float('inf')

    pairs = pairs.assign(_day_key=pairs['date'].map(day_key))
    pairs = pairs.sort_values(['_day_key', 'hour'])
    return list(zip(pairs['date'], pairs['hour']))


def _classify_drops(df, group_col, exclude_none_bucket=True):
    """
    For every (date, hour) snapshot, classify each `group_col` group (e.g.
    declared_family_id, ip_address, or a /24 subnet) present in that
    snapshot as a 'partial' drop (>=1 ACTIVE_IN_RING member AND >=1
    non-ACTIVE_IN_RING member that snapshot), a 'total' drop (0 active
    members, all present members inactive), or no drop at all (0 inactive
    members -- excluded entirely, since a family with no inactive members
    can't be experiencing any kind of drop).

    The "None"/ungrouped bucket is excluded by default for the same
    reason as in the sybil-distribution functions: a singleton node with
    no declared family (or an unusable IP) can't exhibit a partial-vs
    -total *operator* drop pattern. Set exclude_none_bucket=False to
    include it.

    Returns a long DataFrame, one row per (date, hour, group_col value)
    that has a drop, with columns ['date', 'hour', group_col,
    'total_members', 'drop_type'] -- 'total_members' is that group's
    unique-fingerprint count in that snapshot (active + inactive).
    """
    scoped = df[df[group_col] != 'None'] if exclude_none_bucket else df

    total_counts = (
        scoped.groupby(['date', 'hour', group_col])['fingerprint'].nunique()
    )
    active_counts = (
        scoped[scoped['status'] == 'ACTIVE_IN_RING']
        .groupby(['date', 'hour', group_col])['fingerprint'].nunique()
    )

    summary = total_counts.rename('total_members').to_frame()
    summary['active_members'] = active_counts.reindex(summary.index, fill_value=0)
    summary['inactive_members'] = summary['total_members'] - summary['active_members']

    summary = summary[summary['inactive_members'] > 0].copy()
    summary['drop_type'] = np.where(summary['active_members'] > 0, 'partial', 'total')

    return summary.reset_index()[['date', 'hour', group_col, 'total_members', 'drop_type']]


def _print_top5_drop_counts(drop_df, group_col, label, metric_label):
    """
    Item 4 of the entity-drops spec: across the whole (already
    service-type-scoped, if applicable) DataFrame, count how many distinct
    (date, hour) snapshots each group registered a partial drop in, and
    separately a total drop in, and print the top 5 for each -- full group
    id, drop type, absolute snapshot count.
    """
    for drop_type, drop_name in (('partial', 'partial-drop'), ('total', 'total-drop')):
        subset = drop_df[drop_df['drop_type'] == drop_type]
        if subset.empty:
            print(f"[DROPS-INFO] No {drop_name} snapshots found for {metric_label} — {label}.")
            continue

        snapshot_counts = subset.groupby(group_col).size().sort_values(ascending=False)
        top5 = snapshot_counts.head(5)

        print(f"\n[DROPS] Top {metric_label} groups by {drop_name} snapshot count — {label}")
        for group_id, count in top5.items():
            print(f"    {group_id}: {drop_name}, {count} snapshot(s)")


def _plot_entity_drops_series(df, drop_df, output_path, title):
    """
    Save one figure with 4 series across the chronological (date, hour)
    snapshot sequence: absolute partial-drop count (solid blue), absolute
    total-drop count (solid red), partial-drop network share (dashed
    blue), total-drop network share (dashed red). "Count" here is the sum
    of total_members (active + inactive) across all groups classified
    with that drop type in that snapshot; "share" divides that sum by the
    whole `df`'s unique-fingerprint count for that same snapshot (the
    same "share of the total observed network" convention used by the
    sybil-distribution functions).

    X-axis ticks show one "Day N" label per day (at that day's first
    snapshot) rather than one per (date, hour) snapshot, so hour-to-hour
    spikes stay visible as individual plotted points without the axis
    turning into an unreadable wall of labels. A day with only a single
    snapshot still plots fine as one point.
    """
    snapshots = _chronological_snapshots(df)
    snapshot_totals = df.groupby(['date', 'hour'])['fingerprint'].nunique()

    partial_sums = (
        drop_df[drop_df['drop_type'] == 'partial']
        .groupby(['date', 'hour'])['total_members'].sum()
    )
    total_sums = (
        drop_df[drop_df['drop_type'] == 'total']
        .groupby(['date', 'hour'])['total_members'].sum()
    )

    x = list(range(len(snapshots)))
    partial_counts, total_counts, partial_shares, total_shares = [], [], [], []
    for snap in snapshots:
        denom = snapshot_totals.get(snap, 0)
        p = partial_sums.get(snap, 0)
        t = total_sums.get(snap, 0)
        partial_counts.append(p)
        total_counts.append(t)
        # Zero total-network denominator (or zero drop that snapshot)
        # yields a share of 0, never a ZeroDivisionError.
        partial_shares.append((p / denom) if denom else 0.0)
        total_shares.append((t / denom) if denom else 0.0)

    fig, ax1 = plt.subplots(figsize=(12, 6))
    ax2 = ax1.twinx()

    ax1.plot(x, partial_counts, linestyle='-', color='blue', marker='o', label='Partial drop (count)')
    ax1.plot(x, total_counts, linestyle='-', color='red', marker='o', label='Total drop (count)')
    ax2.plot(x, partial_shares, linestyle='--', color='blue', marker='s', label='Partial drop (share)')
    ax2.plot(x, total_shares, linestyle='--', color='red', marker='s', label='Total drop (share)')

    day_first_index = {}
    for i, (date, _hour) in enumerate(snapshots):
        if date not in day_first_index:
            day_first_index[date] = i
    ax1.set_xticks(list(day_first_index.values()))
    ax1.set_xticklabels(list(day_first_index.keys()), rotation=45)

    ax1.set_xlabel("Day")
    ax1.set_ylabel("Dropped unique-fingerprint count — solid")
    ax2.set_ylabel("Network share — dashed")
    ax1.set_title(title)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=8,
               loc='upper left', bbox_to_anchor=(1.1, 1))

    fig.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path, bbox_inches='tight')
    plt.close(fig)
    print(f"    --> Saved plot: {output_path}")


def _entity_drops_report_and_plot(df, group_col, label, output_path, metric_label=None,
                                   exclude_none_bucket=True):
    """
    Shared logic for both entity-drops deliverables: classify per-snapshot
    partial/total drops for `group_col`, print the top-5-by-snapshot-count
    for each drop type, and save the 4-series time plot.
    """
    if metric_label is None:
        metric_label = group_col

    drop_df = _classify_drops(df, group_col, exclude_none_bucket=exclude_none_bucket)
    if drop_df.empty:
        print(f"[DROPS-INFO] No drop events found for '{metric_label}' — {label}; skipping.")
        return

    _print_top5_drop_counts(drop_df, group_col, label, metric_label)

    _plot_entity_drops_series(
        df, drop_df, output_path,
        title=f"{label} — {metric_label} entity drops",
    )


def family_id_entity_drops_distributions(df, context_label):
    """
    Deliverable A. For `df` (network-wide or tracked, post-validate_sort_data
    shape), classifies each declared_family_id group's per-snapshot status
    as a partial or total drop, prints the top-5-by-snapshot-count for
    each drop type, and saves the 4-series time plot to
    analysis-results/sybil/family-id/{context_label}_family_id_entity_drops.png.

    When context_label == "tracked", additionally repeats the same
    analysis once per distinct service_type, saved to
    analysis-results/sybil/family-id/{service_type_lower}_family_id_entity_drops.png.
    """
    base_dir = os.path.join("analysis-results", "sybil", "family-id")

    _entity_drops_report_and_plot(
        df, 'declared_family_id', context_label,
        os.path.join(base_dir, f"{context_label}_family_id_entity_drops.png"),
        metric_label="declared_family_id",
    )

    if context_label == "tracked" and 'service_type' in df.columns:
        service_types = sorted(t for t in df['service_type'].dropna().unique() if t not in ('None', ''))
        for service_type in service_types:
            subset = df[df['service_type'] == service_type]
            _entity_drops_report_and_plot(
                subset, 'declared_family_id', f"tracked — {service_type}",
                os.path.join(base_dir, f"{service_type.lower()}_family_id_entity_drops.png"),
                metric_label="declared_family_id",
            )


def ip_entity_drops_distributions(df, context_label):
    """
    Deliverable B (IP-based equivalent). Same structure as
    family_id_entity_drops_distributions, but groups by IP-based identity
    instead of declared_family_id, in two variants: exact ip_address, and
    the derived /24 subnet (via the same _to_24_subnet helper used by
    ip_sybil_distributions). Saved under analysis-results/sybil/ip_sybil/
    as {context_label}_ip_entity_drops.png /
    {context_label}_ip_24_subnet_entity_drops.png (and, for
    context_label == "tracked", additionally per service_type as
    {service_type_lower}_ip_entity_drops.png /
    {service_type_lower}_ip_24_subnet_entity_drops.png).
    """
    base_dir = os.path.join("analysis-results", "sybil", "ip_sybil")

    working = df.copy()
    working['_ip_24_subnet'] = working['ip_address'].apply(_to_24_subnet)

    def run_both_variants(sub_df, label, filename_prefix):
        _entity_drops_report_and_plot(
            sub_df, 'ip_address', label,
            os.path.join(base_dir, f"{filename_prefix}_ip_entity_drops.png"),
            metric_label="ip_address",
        )
        _entity_drops_report_and_plot(
            sub_df, '_ip_24_subnet', label,
            os.path.join(base_dir, f"{filename_prefix}_ip_24_subnet_entity_drops.png"),
            metric_label="/24 subnet",
        )

    run_both_variants(working, context_label, context_label)

    if context_label == "tracked" and 'service_type' in working.columns:
        service_types = sorted(t for t in working['service_type'].dropna().unique() if t not in ('None', ''))
        for service_type in service_types:
            subset = working[working['service_type'] == service_type]
            run_both_variants(subset, f"tracked — {service_type}", service_type.lower())


if __name__ == "__main__":
    print("=" * 60)
    print("""
  _   _ ____  ____  _         
 | | | / ___||  _ \(_)_ __
 | |_| \___ \| | | | | '__|
 |  _  |___) | |_| | | |
 |_| |_|____/|____/|_|_|
     _                _           _
    / \   _ __   __ _| |_   _ ___(_)___
   / _ \ | '_ \ / _` | | | | / __| / __|
  / ___ \| | | | (_| | | |_| \__ \ \__ \                              
 /_/   \_\_| |_|\__,_|_|\__, |___/_|___/
                        |___/
    """)
    print("="*60)
    print("STARTING TOR V3 HSDIR DATA EXTRACTION AND PROCESSING")
    print("="*60)
    
    # Run data Ingestion across log profiles (uncomment to process clean logs)
    # for filename in target_files:
    #     if os.path.exists(filename):
    #         extract_telemetry(filename)
    #     else:
    #         print(f"[INGESTION-ERROR] Target telemetry log not found: {filename}")
            
    print("="*60)
    print("PROCESSING FILE VERIFICATION")
    print("="*60)
    
    df_net_consensus   = validate_sort_data("network_hsdir_consensus_snapshots.csv")
    # df_ring_events     = validate_sort_data("hsdir_ring_events.csv")
    df_track_consensus = validate_sort_data("tracked_hsdir_consensus_snapshots.csv")
    # df_rot_net         = validate_sort_data("rotated_network_hsdir_consensus_snapshots.csv")
    # df_rot_track       = validate_sort_data("rotated_tracked_hsdir_consensus_snapshots.csv")

    df_track_consensus_ghost_filtered = df_track_consensus[
            df_track_consensus["consecutive_hourly_absences"].isna() | 
            (df_track_consensus["consecutive_hourly_absences"] <= 1)
        ]

    df_net_consensus_ghost_filtered = df_net_consensus[
            df_net_consensus["consecutive_hourly_absences"].isna() | 
            (df_net_consensus["consecutive_hourly_absences"] <= 1)
        ]

    print("="*60)
    print("PROCESSING CAPACITY STABILITY ANALYSIS")
    print("="*60)

    # Sybil-distribution analysis only needs the network-wide and tracked
    # consensus DataFrames (ring events / rotated snapshots aren't inputs
    # to either function below, and may not be present for every run).
    if df_net_consensus is not None and df_track_consensus is not None:

        print("="*60)
        print("SYBIL DISTRIBUTIONS")
        print("="*60)
        # family_id_sybil_distributions(df_net_consensus, "network")
        # family_id_sybil_distributions(df_track_consensus, "tracked")
        # ip_sybil_distributions(df_net_consensus, "network")
        # ip_sybil_distributions(df_track_consensus, "tracked")
        print("="*60)
        print("SYBIL OVERLAP DISTRIBUTIONS")
        print("="*60)
        # service_type_overlap_diagnostic(df_track_consensus, "tracked")
        print("="*60)
        print("SYBIL TOTAL vs. PARTIAL DROPS DISTRIBUTIONS")
        print("="*60)
        family_id_entity_drops_distributions(df_net_consensus_ghost_filtered, "network")
        family_id_entity_drops_distributions(df_track_consensus_ghost_filtered, "tracked")
        ip_entity_drops_distributions(df_net_consensus_ghost_filtered, "network")
        ip_entity_drops_distributions(df_track_consensus_ghost_filtered, "tracked")
    else:
        print("[ANALYSIS-WARNING] network and/or tracked consensus DataFrame "
              "unavailable; skipping sybil distribution analysis.")

    print("="*60)
    print("ANALYSIS COMPLETED SUCCESSFULLY. ALL MATRIX ARTIFACTS EXPORTED.")
    print("="*60)