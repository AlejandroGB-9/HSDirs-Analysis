import os
import json
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# ENVIRONMENT SETUP & GLOBAL CONFIGURATION
sns.set_theme(style="whitegrid")
plt.rcParams.update({
    'figure.figsize': (12, 6),
    'axes.labelsize': 12,
    'axes.titlesize': 14,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'figure.titlesize': 16,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight'
})

target_files = [
    "network_hsdir_consensus_snapshots.jsonl",
    "hsdir_ring_events.jsonl",
    "tracked_hsdir_consensus_snapshots.jsonl",
    "rotated_network_hsdir_consensus_snapshots.jsonl",
    "rotated_tracked_hsdir_consensus_snapshots.jsonl"
]

# INGESTION AND CLEANSING
def extract_telemetry(target_filename):
    output_csv = target_filename.replace('.jsonl', '.csv')
    print(f"[EXTRACT-INFO] Ingesting log from source stream: {target_filename}")
    
    consolidated_records = []
    
    with open(target_filename, 'r') as source_file:
        for index, text_line in enumerate(source_file):
            if not text_line.strip():
                continue
            try:
                parsed_json = json.loads(text_line)
            except json.JSONDecodeError as err:
                print(f"[EXTRACT-ERROR] Malformed line entry skipped {index}: {err}")
                continue

            base_timestamp = parsed_json.get("timestamp")
            captured_onion = parsed_json.get("onion_address", None)
            
            nested_array_key = None
            if "relays" in parsed_json:
                nested_array_key = "relays"
                
            if nested_array_key:
                sub_records = parsed_json.get(nested_array_key, [])
                for entry in sub_records:
                    flattened_item = entry.copy()
                    flattened_item["timestamp"] = base_timestamp
                    if captured_onion:
                        flattened_item["onion_address"] = captured_onion
                    consolidated_records.append(flattened_item)
            else:
                consolidated_records.append(parsed_json)
                
    if not consolidated_records:
        print(f"[EXTRACT-WARNING] No usable records extracted from {target_filename}.")
        return False
        
    df_processed = pd.DataFrame(consolidated_records)
    
    if "timestamp" in df_processed.columns:
        parsed_datetimes = pd.to_datetime(df_processed["timestamp"], errors='coerce')
        df_processed["date"] = parsed_datetimes.dt.strftime("%m-%d")
        df_processed["hour"] = parsed_datetimes.dt.strftime("%H:%M")
        
    if "or_port" in df_processed.columns:
        df_processed.drop(columns=["or_port"], inplace=True, errors='ignore')
        
    for technical_flag in ["Fast", "HSDir", "Stable", "Valid"]:
        if "flags" in df_processed.columns:
            df_processed[technical_flag] = df_processed["flags"].apply(lambda val: 1 if (isinstance(val, list) and technical_flag in val) or (isinstance(val, str) and technical_flag in val) else 0)
        else:
            df_processed[technical_flag] = 0
            
    # if "flags" in df_processed.columns:
    #     df_processed.drop(columns=["flags"], inplace=True, errors='ignore')

    if "declared_family_id" in df_processed.columns:
        df_processed["declared_family_id"] = df_processed["declared_family_id"].astype(str).replace(['nan', 'NaN', 'None', '0', '0.0', '', ' '], 'None')
        df_processed["declared_family_id"] = df_processed["declared_family_id"].fillna('None')
    else:
        df_processed["declared_family_id"] = 'None'

    if "declared_family" in df_processed.columns:
        def clean_initial_family(val):
            if isinstance(val, (list, tuple, np.ndarray)):
                return list(val)
                
            if pd.isna(val) or val is None or val in ['None', 'nan', 'NaN', '[]', '', ' ']:
                return []
                
            if isinstance(val, str):
                val_stripped = val.strip()
                if val_stripped.startswith('[') and val_stripped.endswith(']'):
                    try:
                        parsed = ast.literal_eval(val_stripped)
                        if isinstance(parsed, list):
                            return parsed
                    except Exception:
                        pass
                return [val_stripped]
            return []
            
        df_processed["declared_family"] = df_processed["declared_family"].apply(clean_initial_family)
    else:
        df_processed["declared_family"] = [[] for _ in range(len(df_processed))]
        
    for col in df_processed.columns:
        if col == "declared_family":
            continue
        if df_processed[col].dtype == 'object':
            df_processed[col] = df_processed[col].astype(str).replace(['nan', '0', '0.0', '', ' '], 'None')
        elif pd.api.types.is_numeric_dtype(df_processed[col]):
            df_processed[col] = df_processed[col].fillna(0)
        else:
            df_processed[col] = df_processed[col].fillna('None')
    
    df_processed.to_csv(output_csv, index=False)
    print(f"    --> Normalized and written to disk: {output_csv} [Rows: {len(df_processed)}]")
    return True


# VERIFICATION, VALIDATION, CHRONOLOGICAL SORT AND DAY ARRANGEMENT
def validate_sort_data(csv_path):
    if not os.path.exists(csv_path):
        print(f"[VERIFY-ERROR] Target file unavailable: {csv_path}")
        return None
    
    df = pd.read_csv(csv_path, low_memory=False)
    
    for col in df.columns:
        if col in ['ip_address', 'fingerprint', 'status', 'onion_address', 'action', 'reason', 'declared_family_id', 'timestamp_dropped', 'service_type']:
            df[col] = df[col].fillna('None').astype(str)
            df[col] = df[col].replace(['nan', 'NaN', 'None', ''], 'None')
            
    if "declared_family" in df.columns:
        def parse_csv_family_list(val):
            if isinstance(val, (list, tuple, np.ndarray)):
                return list(val)
            if pd.isna(val) or val is None:
                return []
            val_str = str(val).strip()
            if val_str in ['None', 'nan', 'NaN', '', '[]']:
                return []
            if val_str.startswith('[') and val_str.endswith(']'):
                try:
                    parsed = ast.literal_eval(val_str)
                    if isinstance(parsed, list):
                        return parsed
                except Exception:
                    pass
            return [val_str]
        df["declared_family"] = df["declared_family"].apply(parse_csv_family_list)
    else:
        df["declared_family"] = [[] for _ in range(len(df))]
    
    sort_columns = []
    if "date" in df.columns:
        sort_columns.append("date")
    if "hour" in df.columns:
        sort_columns.append("hour")
    if "fingerprint" in df.columns:
        sort_columns.append("fingerprint")
        
    if sort_columns:
        df.sort_values(by=sort_columns, inplace=True)
        df.reset_index(drop=True, inplace=True)
        
    if "date" in df.columns and not df.empty:
        unique_calendar_dates = df["date"].unique()
        unique_calendar_dates = [d for d in unique_calendar_dates if d not in ['', 'nan', 'None']]
        
        date_normalization_map = {date_str: f"Day {idx + 1}" for idx, date_str in enumerate(unique_calendar_dates)}
        df["date"] = df["date"].map(date_normalization_map).fillna(df["date"])
        
    print(f"[VERIFIED-INFO] File loaded: {csv_path} | Dimension Profile: {df.shape}")
    return df

# ==============================================================================
# ANALYSIS 1: Sybil & Multi-Node Operator Concentration Analysis
# ==============================================================================


def analyze_sybil_operator_clustering(snapshot_df):
    """
    Computes Sybil concentration metrics by clustering HSDirs into /24 and /16 IP subnets
    and family identifiers, quantifying single-operator network footprint.
    """
    if snapshot_df is None or snapshot_df.empty:
        print("[ANALYSIS-ERROR] Empty or invalid snapshot DataFrame.")
        return None

    df = snapshot_df.copy()

    def extract_subnet(ip_str, prefix):
        if ip_str == 'None':
            return 'Unknown'
        try:
            net = ipaddress.ip_network(f"{ip_str}/{prefix}", strict=False)
            return str(net)
        except Exception:
            return 'Invalid'

    df['subnet_24'] = df['ip_address'].apply(lambda x: extract_subnet(x, 24))
    df['subnet_16'] = df['ip_address'].apply(lambda x: extract_subnet(x, 16))

    latest_timestamp = df['timestamp'].max()
    latest_df = df[df['timestamp'] == latest_timestamp].drop_duplicates(subset=['fingerprint'])

    total_unique_hsdirs = len(latest_df)

    # --- Fixed value_counts formatting (Pandas 2.0+ compliant) ---
    subnet_24_counts = latest_df['subnet_24'].value_counts().reset_index()
    subnet_24_counts.columns = ['subnet_24', 'hsdir_count']

    subnet_16_counts = latest_df['subnet_16'].value_counts().reset_index()
    subnet_16_counts.columns = ['subnet_16', 'hsdir_count']

    filtered_families = latest_df[latest_df['declared_family_id'] != 'None']['declared_family_id']
    family_id_counts = filtered_families.value_counts().reset_index()
    family_id_counts.columns = ['declared_family_id', 'hsdir_count']
    # -------------------------------------------------------------

    sybil_24_clusters = subnet_24_counts[subnet_24_counts['hsdir_count'] > 1]
    sybil_16_clusters = subnet_16_counts[subnet_16_counts['hsdir_count'] > 1]

    sybil_24_nodes = sybil_24_clusters['hsdir_count'].sum()
    sybil_16_nodes = sybil_16_clusters['hsdir_count'].sum()

    summary_metrics = {
        'snapshot_timestamp': str(latest_timestamp),
        'total_unique_hsdirs': total_unique_hsdirs,
        'unique_24_subnets': len(subnet_24_counts),
        'unique_16_subnets': len(subnet_16_counts),
        'multi_node_24_subnets': len(sybil_24_clusters),
        'hsdirs_in_multi_node_24': int(sybil_24_nodes),
        'pct_hsdirs_in_multi_node_24': float(sybil_24_nodes / total_unique_hsdirs * 100) if total_unique_hsdirs > 0 else 0.0,
        'multi_node_16_subnets': len(sybil_16_clusters),
        'hsdirs_in_multi_node_16': int(sybil_16_nodes),
        'pct_hsdirs_in_multi_node_16': float(sybil_16_nodes / total_unique_hsdirs * 100) if total_unique_hsdirs > 0 else 0.0,
        'declared_family_clusters': len(family_id_counts)
    }

    results_df = pd.DataFrame([summary_metrics])
    return results_df, subnet_24_counts, subnet_16_counts


def run_sybil_operator_clustering_analysis(
    jsonl_path, output_csv_path="analyses/sybil-clust"
):
    """
    Wrapper procedure for Sybil and multi-node operator concentration analysis.
    """
    print(f'[EXEC] Processing Sybil Operator Analysis for: {jsonl_path}')
    snapshot_df = validate_sort_data(jsonl_path)
    if snapshot_df is None or snapshot_df.empty:
        print('[ERROR] Unable to load consensus snapshot data.')
        return None

    summary_df, sub24_df, sub16_df = analyze_sybil_operator_clustering(
        snapshot_df
    )

    if output_csv_path:
        os.makedirs(os.path.dirname(output_csv_path), exist_ok=True)
        summary_df.to_csv(output_csv_path, index=False)
        sub24_path = output_csv_path.replace('.csv', '_subnet24.csv')
        sub24_df.to_csv(sub24_path, index=False)
        print(f'[SUCCESS] Results written to: {output_csv_path}')

    return summary_df


# ==============================================================================
# ANALYSIS 2: Hash Ring Distance & Target Index Placement Analysis
# ==============================================================================


def analyze_hsdir_ring_distance_distribution(events_df):
    """
    Calculates ring distance and position metrics between HSDirs and target descriptors.
    """
    if events_df is None or events_df.empty:
        print('[ANALYSIS-ERROR] Empty or invalid events DataFrame.')
        return None

    df = events_df.copy()

    numeric_cols = [
        'onion_target_index_100',
        'hsdir_index_hrt_100',
        'hsdir_to_onion_ring_position',
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    grouped = df.groupby(['service_type', 'action'])

    summary_list = []
    for (stype, action), group in grouped:
        pos_series = group['hsdir_to_onion_ring_position'].dropna()
        hrt_series = group['hsdir_index_hrt_100'].dropna()

        summary_entry = {
            'service_type': stype,
            'action': action,
            'total_events': len(group),
            'unique_onions': group['onion_address'].nunique(),
            'unique_hsdirs': group['hsdir_fingerprint'].nunique(),
            'pos_mean': float(pos_series.mean()) if not pos_series.empty else 0.0,
            'pos_std': float(pos_series.std()) if not pos_series.empty else 0.0,
            'pos_median': (
                float(pos_series.median()) if not pos_series.empty else 0.0
            ),
            'pos_p25': (
                float(pos_series.quantile(0.25))
                if not pos_series.empty
                else 0.0
            ),
            'pos_p75': (
                float(pos_series.quantile(0.75))
                if not pos_series.empty
                else 0.0
            ),
            'hrt_mean': float(hrt_series.mean()) if not hrt_series.empty else 0.0,
            'hrt_std': float(hrt_series.std()) if not hrt_series.empty else 0.0,
        }
        summary_list.append(summary_entry)

    summary_df = pd.DataFrame(summary_list)
    return summary_df


def run_hsdir_ring_distance_analysis(jsonl_path, output_csv_path="analyses/hsdir-ring"):
    """
    Wrapper procedure for hash ring distance and target index placement analysis.
    """
    print(f'[EXEC] Processing Hash Ring Distance Analysis for: {jsonl_path}')
    events_df = validate_sort_data(jsonl_path)
    if events_df is None or events_df.empty:
        print('[ERROR] Unable to load ring event data.')
        return None

    summary_df = analyze_hsdir_ring_distance_distribution(events_df)

    if output_csv_path:
        os.makedirs(os.path.dirname(output_csv_path), exist_ok=True)
        summary_df.to_csv(output_csv_path, index=False)
        print(f'[SUCCESS] Results written to: {output_csv_path}')

    return summary_df


# ==============================================================================
# ANALYSIS 3: HSDir Churn, Uptime, and Lifetime Stability Analysis
# ==============================================================================


def analyze_hsdir_churn_and_uptime(snapshot_df):
    """
    Computes per-relay uptime, observed lifespan, consecutive absence durations,
    and hourly consensus churn metrics across snapshot intervals.
    """
    if snapshot_df is None or snapshot_df.empty:
        print('[ANALYSIS-ERROR] Empty or invalid snapshot DataFrame.')
        return None

    df = snapshot_df.copy()

    timestamps = sorted(df['timestamp'].unique())
    total_snapshots = len(timestamps)

    if total_snapshots == 0:
        return None, None

    relay_grouped = df.groupby('fingerprint')

    relay_stats = []
    for fp, group in relay_grouped:
        obs_count = len(group)
        first_seen = group['timestamp'].min()
        last_seen = group['timestamp'].max()
        uptime_pct = (
            (obs_count / total_snapshots) * 100 if total_snapshots > 0 else 0.0
        )

        ip_addr = group['ip_address'].iloc[-1]
        nickname = (
            group['nickname'].iloc[-1]
            if 'nickname' in group.columns
            else 'Unknown'
        )
        status = group['status'].iloc[-1]
        max_absences = (
            group['consecutive_hourly_absences'].max()
            if 'consecutive_hourly_absences' in group.columns
            else 0
        )

        relay_stats.append(
            {
                'fingerprint': fp,
                'nickname': nickname,
                'ip_address': ip_addr,
                'status': status,
                'first_seen': str(first_seen),
                'last_seen': str(last_seen),
                'observed_snapshots': obs_count,
                'total_snapshots': total_snapshots,
                'uptime_percentage': float(uptime_pct),
                'max_consecutive_absences': int(max_absences),
            }
        )

    relay_uptime_df = pd.DataFrame(relay_stats).sort_values(
        by='uptime_percentage', ascending=False
    )

    churn_stats = []
    prev_set = set()

    for ts in timestamps:
        current_set = set(
            df[df['timestamp'] == ts]['fingerprint'].unique()
        )
        if prev_set:
            joined = len(current_set - prev_set)
            left = len(prev_set - current_set)
        else:
            joined = 0
            left = 0

        churn_stats.append(
            {
                'timestamp': str(ts),
                'total_active': len(current_set),
                'joined_hsdirs': joined,
                'departed_hsdirs': left,
            }
        )
        prev_set = current_set

    hourly_churn_df = pd.DataFrame(churn_stats)

    return relay_uptime_df, hourly_churn_df


def run_hsdir_churn_uptime_analysis(jsonl_path, output_csv_path="analyses/churn-uptime"):
    """
    Wrapper procedure for HSDir churn and stability analysis.
    """
    print(f'[EXEC] Processing Churn and Uptime Analysis for: {jsonl_path}')
    snapshot_df = validate_sort_data(jsonl_path)
    if snapshot_df is None or snapshot_df.empty:
        print('[ERROR] Unable to load consensus snapshot data.')
        return None

    relay_uptime_df, hourly_churn_df = analyze_hsdir_churn_and_uptime(
        snapshot_df
    )

    if output_csv_path:
        os.makedirs(os.path.dirname(output_csv_path), exist_ok=True)
        relay_uptime_df.to_csv(output_csv_path, index=False)
        churn_path = output_csv_path.replace('.csv', '_hourly_churn.csv')
        hourly_churn_df.to_csv(churn_path, index=False)
        print(f'[SUCCESS] Results written to: {output_csv_path}')

    return relay_uptime_df


# ==============================================================================
# ANALYSIS 4: Descriptor Event & Host Action Dynamics
# ==============================================================================


def analyze_descriptor_action_dynamics(events_df):
    """
    Evaluates descriptor event actions (UPLOADED vs RECEIVED) per onion service type,
    measuring descriptor propagation coverage and host overlap.
    """
    if events_df is None or events_df.empty:
        print('[ANALYSIS-ERROR] Empty or invalid events DataFrame.')
        return None

    df = events_df.copy()

    onion_grouped = df.groupby('onion_address')

    onion_metrics = []
    for onion, group in onion_grouped:
        stype = group['service_type'].iloc[0]
        uploaded_hsdirs = set(
            group[group['action'] == 'UPLOADED']['hsdir_fingerprint']
        )
        received_hsdirs = set(
            group[group['action'] == 'RECEIVED']['hsdir_fingerprint']
        )

        overlap = uploaded_hsdirs.intersection(received_hsdirs)

        onion_metrics.append(
            {
                'onion_address': onion,
                'service_type': stype,
                'total_events': len(group),
                'uploaded_count': len(
                    group[group['action'] == 'UPLOADED']
                ),
                'received_count': len(
                    group[group['action'] == 'RECEIVED']
                ),
                'unique_uploaded_hsdirs': len(uploaded_hsdirs),
                'unique_received_hsdirs': len(received_hsdirs),
                'hsdir_intersection_count': len(overlap),
                'jaccard_similarity': (
                    float(
                        len(overlap)
                        / len(uploaded_hsdirs.union(received_hsdirs))
                    )
                    if uploaded_hsdirs.union(received_hsdirs)
                    else 0.0
                ),
            }
        )

    descriptor_dynamics_df = pd.DataFrame(onion_metrics)
    return descriptor_dynamics_df


def run_descriptor_action_dynamics_analysis(
    jsonl_path, output_csv_path="analyses/descriptor-action"
):
    """
    Wrapper procedure for descriptor action dynamics analysis.
    """
    print(f'[EXEC] Processing Descriptor Dynamics Analysis for: {jsonl_path}')
    events_df = validate_sort_data(jsonl_path)
    if events_df is None or events_df.empty:
        print('[ERROR] Unable to load ring event data.')
        return None

    dynamics_df = analyze_descriptor_action_dynamics(events_df)

    if output_csv_path:
        os.makedirs(os.path.dirname(output_csv_path), exist_ok=True)
        dynamics_df.to_csv(output_csv_path, index=False)
        print(f'[SUCCESS] Results written to: {output_csv_path}')

    return dynamics_df

import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


# ==============================================================================
# VISUALIZATION SUITE
# ==============================================================================


def plot_sybil_operator_clustering(
    sub24_df, sub16_df, summary_df, output_dir="plots"
):
    """Generates visualizations for Sybil & Subnet Operator Concentration (Analysis 1)."""
    os.makedirs(output_dir, exist_ok=True)

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    # Subnet /24 Top Clusters
    top_24 = sub24_df[sub24_df["subnet_24"] != "Unknown"].head(10)
    if not top_24.empty:
        sns.barplot(
            data=top_24,
            x="hsdir_count",
            y="subnet_24",
            ax=axes[0],
            palette="Reds_r",
            hue="subnet_24",
            legend=False,
        )
        axes[0].set_title("Top 10 /24 IP Subnet Concentrations")
        axes[0].set_xlabel("HSDir Relay Count")
        axes[0].set_ylabel("/24 Subnet Prefix")
    else:
        axes[0].text(
            0.5, 0.5, "No /24 Data Available", ha="center", va="center"
        )

    # Subnet /16 Top Clusters
    top_16 = sub16_df[sub16_df["subnet_16"] != "Unknown"].head(10)
    if not top_16.empty:
        sns.barplot(
            data=top_16,
            x="hsdir_count",
            y="subnet_16",
            ax=axes[1],
            palette="Oranges_r",
            hue="subnet_16",
            legend=False,
        )
        axes[1].set_title("Top 10 /16 IP Subnet Concentrations")
        axes[1].set_xlabel("HSDir Relay Count")
        axes[1].set_ylabel("/16 Subnet Prefix")
    else:
        axes[1].text(
            0.5, 0.5, "No /16 Data Available", ha="center", va="center"
        )

    plt.tight_layout()
    plot_path = os.path.join(output_dir, "analysis1_sybil_operator_subnets.png")
    plt.savefig(plot_path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"[PLOT-SUCCESS] Saved Sybil analysis plot to {plot_path}")


def plot_hsdir_ring_distance(events_df, output_dir="plots"):
    """Generates Ring Position Distributions and Hash Ring Distance metrics (Analysis 2)."""
    os.makedirs(output_dir, exist_ok=True)

    if events_df is None or events_df.empty:
        print("[PLOT-SKIP] Ring events DataFrame empty.")
        return

    df = events_df.copy()
    if "hsdir_to_onion_ring_position" not in df.columns:
        print(
            "[PLOT-SKIP] Key metric 'hsdir_to_onion_ring_position' not found in events."
        )
        return

    df["hsdir_to_onion_ring_position"] = pd.to_numeric(
        df["hsdir_to_onion_ring_position"], errors="coerce"
    )
    df = df.dropna(subset=["hsdir_to_onion_ring_position"])

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    # Violin Plot of Position by Service Type & Action
    sns.violinplot(
        data=df,
        x="service_type",
        y="hsdir_to_onion_ring_position",
        hue="action",
        split=True,
        inner="quartile",
        palette="Set2",
        ax=axes[0],
    )
    axes[0].set_title(
        "Hash Ring Position Relative to Target by Service & Action"
    )
    axes[0].set_xlabel("Service Type")
    axes[0].set_ylabel("Ring Distance Position Normalized")

    # Cumulative Empirical Distribution Function (ECDF)
    sns.ecdfplot(
        data=df,
        x="hsdir_to_onion_ring_position",
        hue="action",
        style="service_type",
        ax=axes[1],
    )
    axes[1].set_title("ECDF of HSDir Hash Ring Target Offsets")
    axes[1].set_xlabel("Target Distance Offset Ratio")
    axes[1].set_ylabel("Cumulative Empirical Probability")

    plt.tight_layout()
    plot_path = os.path.join(output_dir, "analysis2_hsdir_ring_distance.png")
    plt.savefig(plot_path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"[PLOT-SUCCESS] Saved ring distance plot to {plot_path}")


def plot_churn_and_uptime(relay_uptime_df, hourly_churn_df, output_dir="plots"):
    """Generates timelines for Relay Uptime ECDF and Network Churn (Analysis 3)."""
    os.makedirs(output_dir, exist_ok=True)

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    # 1. Relay Uptime Distribution (ECDF)
    if relay_uptime_df is not None and not relay_uptime_df.empty:
        sns.ecdfplot(
            data=relay_uptime_df,
            x="uptime_percentage",
            ax=axes[0],
            color="teal",
            linewidth=2,
        )
        axes[0].set_title("Cumulative Distribution of HSDir Relay Uptime")
        axes[0].set_xlabel("Consensus Presence Uptime (%)")
        axes[0].set_ylabel("Cumulative Share of HSDir Pool")
        axes[0].grid(True, linestyle="--", alpha=0.6)
    else:
        axes[0].text(
            0.5, 0.5, "No Uptime Data Available", ha="center", va="center"
        )

    # 2. Hourly Churn & Active Relays Time Series
    if hourly_churn_df is not None and not hourly_churn_df.empty:
        churn_df = hourly_churn_df.copy()
        churn_df["step"] = np.arange(len(churn_df))

        axes[1].plot(
            churn_df["step"],
            churn_df["total_active"],
            label="Total Active HSDirs",
            color="navy",
            linewidth=2,
        )
        axes[1].bar(
            churn_df["step"],
            churn_df["joined_hsdirs"],
            alpha=0.6,
            color="green",
            label="Joined Relays",
        )
        axes[1].bar(
            churn_df["step"],
            -churn_df["departed_hsdirs"],
            alpha=0.6,
            color="crimson",
            label="Departed Relays",
        )

        axes[1].axhline(0, color="black", linewidth=0.8, linestyle="--")
        axes[1].set_title("HSDir Consensus Pool Churn Over Snapshot Steps")
        axes[1].set_xlabel("Snapshot Interval Step")
        axes[1].set_ylabel("Relay Count Delta / Active Pool Size")
        axes[1].legend(loc="upper right")
    else:
        axes[1].text(
            0.5, 0.5, "No Churn Data Available", ha="center", va="center"
        )

    plt.tight_layout()
    plot_path = os.path.join(output_dir, "analysis3_churn_and_uptime.png")
    plt.savefig(plot_path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"[PLOT-SUCCESS] Saved churn and uptime plot to {plot_path}")


def plot_descriptor_action_dynamics(dynamics_df, output_dir="plots"):
    """Generates charts for Descriptor Action Dynamics & Host Overlap (Analysis 4)."""
    os.makedirs(output_dir, exist_ok=True)

    if dynamics_df is None or dynamics_df.empty:
        print("[PLOT-SKIP] Descriptor dynamics DataFrame empty.")
        return

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    # 1. Uploaded vs Received Count per Service Type
    sns.scatterplot(
        data=dynamics_df,
        x="uploaded_count",
        y="received_count",
        hue="service_type",
        style="service_type",
        s=100,
        alpha=0.8,
        ax=axes[0],
    )
    axes[0].set_title("Descriptor Propagation: Uploaded vs Received Counts")
    axes[0].set_xlabel("Uploaded Descriptor Events")
    axes[0].set_ylabel("Received Descriptor Events")

    # Add reference identity line (y = x)
    max_val = max(
        dynamics_df["uploaded_count"].max(), dynamics_df["received_count"].max()
    )
    axes[0].plot(
        [0, max_val], [0, max_val], color="gray", linestyle="--", alpha=0.7
    )

    # 2. Jaccard Similarity of HSDir Overlap by Service Type
    sns.boxplot(
        data=dynamics_df,
        x="service_type",
        y="jaccard_similarity",
        palette="Set3",
        hue="service_type",
        legend=False,
        ax=axes[1],
    )
    sns.stripplot(
        data=dynamics_df,
        x="service_type",
        y="jaccard_similarity",
        color="black",
        alpha=0.5,
        jitter=0.2,
        ax=axes[1],
    )

    axes[1].set_title("HSDir Upload/Fetch Overlap (Jaccard Index)")
    axes[1].set_xlabel("Service Deployment Type")
    axes[1].set_ylabel("Jaccard Similarity Score")
    axes[1].set_ylim(-0.05, 1.05)

    plt.tight_layout()
    plot_path = os.path.join(output_dir, "analysis4_descriptor_dynamics.png")
    plt.savefig(plot_path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"[PLOT-SUCCESS] Saved descriptor action dynamics plot to {plot_path}")

# MAIN
if __name__ == "__main__":
    print("=" * 60)
    print("""
  _   _ ____  ____  _         
 | | | / ___||  _ \(_)_ __
 | |_| \___ \| | | | | '__|
 |  _  |___) | |_| | | |
 |_| |_|____/|____/|_|_|
     _                _           _
    / \   _ __   __ _| |_   _ ___(_)___
   / _ \ | '_ \ / _` | | | | / __| / __|
  / ___ \| | | | (_| | | |_| \__ \ \__ \                              
 /_/   \_\_| |_|\__,_|_|\__, |___/_|___/
                        |___/
    """)
    print("="*60)
    print("STARTING TOR V3 HSDIR DATA EXTRACTION AND PROCESSING")
    print("="*60)
    
    # Run data Ingestion across log profiles (uncomment to process clean logs)
    for filename in target_files:
        if os.path.exists(filename):
            extract_telemetry(filename)
        else:
            print(f"[INGESTION-ERROR] Target telemetry log not found: {filename}")
            
    print("="*60)
    print("PROCESSING FILE VERIFICATION")
    print("="*60)

    # --- Analysis 1: Sybil Operator Clustering ---
    tracked_snapshot_df = validate_sort_data(
        "tracked_hsdir_consensus_snapshots.csv"
    )
    if tracked_snapshot_df is not None:
        summary_df, sub24_df, sub16_df = analyze_sybil_operator_clustering(
            tracked_snapshot_df
        )
        plot_sybil_operator_clustering(sub24_df, sub16_df, summary_df)

    # --- Analysis 2: Hash Ring Proximity ---
    events_df = validate_sort_data("hsdir_ring_events.csv")
    if events_df is not None:
        run_hsdir_ring_distance_analysis("hsdir_ring_events.csv")
        plot_hsdir_ring_distance(events_df)

    # --- Analysis 3: Churn and Uptime Stability ---
    if tracked_snapshot_df is not None:
        relay_uptime_df, hourly_churn_df = analyze_hsdir_churn_and_uptime(
            tracked_snapshot_df
        )
        plot_churn_and_uptime(relay_uptime_df, hourly_churn_df)

    # --- Analysis 4: Descriptor Action Dynamics ---
    if events_df is not None:
        dynamics_df = analyze_descriptor_action_dynamics(events_df)
        plot_descriptor_action_dynamics(dynamics_df)

    print("=" * 60)
    print("PIPELINE PROCESSING COMPLETE. ALL PLOTS SAVED TO ./plots/")
    print("=" * 60)