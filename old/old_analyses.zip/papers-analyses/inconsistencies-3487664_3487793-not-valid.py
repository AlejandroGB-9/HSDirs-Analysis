#!/usr/bin/env python3

import os
import json
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# ENVIRONMENT SETUP & GLOBAL CONFIGURATION
sns.set_theme(style="whitegrid")
plt.rcParams.update({
    'figure.figsize': (12, 6),
    'axes.labelsize': 12,
    'axes.titlesize': 14,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'figure.titlesize': 16,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight'
})

def extract_telemetry(target_filename):
    output_csv = target_filename.replace('.jsonl', '.csv')
    print(f"[EXTRACT-INFO] Ingesting log from source stream: {target_filename}")
    
    consolidated_records = []
    
    with open(target_filename, 'r') as source_file:
        for index, text_line in enumerate(source_file):
            if not text_line.strip():
                continue
            try:
                parsed_json = json.loads(text_line)
            except json.JSONDecodeError as err:
                print(f"[EXTRACT-ERROR] Malformed line entry skipped {index}: {err}")
                continue

            base_timestamp = parsed_json.get("timestamp")
            captured_onion = parsed_json.get("onion_address", None)
            
            nested_array_key = None
            if "relays" in parsed_json:
                nested_array_key = "relays"
                
            if nested_array_key:
                sub_records = parsed_json.get(nested_array_key, [])
                for entry in sub_records:
                    flattened_item = entry.copy()
                    flattened_item["timestamp"] = base_timestamp
                    if captured_onion:
                        flattened_item["onion_address"] = captured_onion
                    consolidated_records.append(flattened_item)
            else:
                consolidated_records.append(parsed_json)
                
    if not consolidated_records:
        print(f"[EXTRACT-WARNING] No usable records extracted from {target_filename}.")
        return False
        
    df_processed = pd.DataFrame(consolidated_records)
    
    if "timestamp" in df_processed.columns:
        parsed_datetimes = pd.to_datetime(df_processed["timestamp"], errors='coerce')
        df_processed["date"] = parsed_datetimes.dt.strftime("%m-%d")
        df_processed["hour"] = parsed_datetimes.dt.strftime("%H:%M")
        
    if "or_port" in df_processed.columns:
        df_processed.drop(columns=["or_port"], inplace=True, errors='ignore')
        
    for technical_flag in ["Fast", "HSDir", "Stable", "Valid"]:
        if "flags" in df_processed.columns:
            df_processed[technical_flag] = df_processed["flags"].apply(lambda val: 1 if (isinstance(val, list) and technical_flag in val) or (isinstance(val, str) and technical_flag in val) else 0)
        else:
            df_processed[technical_flag] = 0
            
    # if "flags" in df_processed.columns:
    #     df_processed.drop(columns=["flags"], inplace=True, errors='ignore')

    if "declared_family_id" in df_processed.columns:
        df_processed["declared_family_id"] = df_processed["declared_family_id"].astype(str).replace(['nan', 'NaN', 'None', '0', '0.0', '', ' '], 'None')
        df_processed["declared_family_id"] = df_processed["declared_family_id"].fillna('None')
    else:
        df_processed["declared_family_id"] = 'None'

    if "declared_family" in df_processed.columns:
        def clean_initial_family(val):
            if isinstance(val, (list, tuple, np.ndarray)):
                return list(val)
                
            if pd.isna(val) or val is None or val in ['None', 'nan', 'NaN', '[]', '', ' ']:
                return []
                
            if isinstance(val, str):
                val_stripped = val.strip()
                if val_stripped.startswith('[') and val_stripped.endswith(']'):
                    try:
                        parsed = ast.literal_eval(val_stripped)
                        if isinstance(parsed, list):
                            return parsed
                    except Exception:
                        pass
                return [val_stripped]
            return []
            
        df_processed["declared_family"] = df_processed["declared_family"].apply(clean_initial_family)
    else:
        df_processed["declared_family"] = [[] for _ in range(len(df_processed))]
        
    for col in df_processed.columns:
        if col == "declared_family":
            continue
        if df_processed[col].dtype == 'object':
            df_processed[col] = df_processed[col].astype(str).replace(['nan', '0', '0.0', '', ' '], 'None')
        elif pd.api.types.is_numeric_dtype(df_processed[col]):
            df_processed[col] = df_processed[col].fillna(0)
        else:
            df_processed[col] = df_processed[col].fillna('None')
    
    df_processed.to_csv(output_csv, index=False)
    print(f"    --> Normalized and written to disk: {output_csv} [Rows: {len(df_processed)}]")
    return True


# VERIFICATION, VALIDATION, CHRONOLOGICAL SORT AND DAY ARRANGEMENT
def validate_sort_data(csv_path):
    if not os.path.exists(csv_path):
        print(f"[VERIFY-ERROR] Target file unavailable: {csv_path}")
        return None
    
    df = pd.read_csv(csv_path, low_memory=False)
    
    for col in df.columns:
        if col in ['ip_address', 'fingerprint', 'status', 'onion_address', 'action', 'reason', 'declared_family_id', 'timestamp_dropped', 'service_type']:
            df[col] = df[col].fillna('None').astype(str)
            df[col] = df[col].replace(['nan', 'NaN', 'None', ''], 'None')
            
    if "declared_family" in df.columns:
        def parse_csv_family_list(val):
            if isinstance(val, (list, tuple, np.ndarray)):
                return list(val)
            if pd.isna(val) or val is None:
                return []
            val_str = str(val).strip()
            if val_str in ['None', 'nan', 'NaN', '', '[]']:
                return []
            if val_str.startswith('[') and val_str.endswith(']'):
                try:
                    parsed = ast.literal_eval(val_str)
                    if isinstance(parsed, list):
                        return parsed
                except Exception:
                    pass
            return [val_str]
        df["declared_family"] = df["declared_family"].apply(parse_csv_family_list)
    else:
        df["declared_family"] = [[] for _ in range(len(df))]
    
    sort_columns = []
    if "date" in df.columns:
        sort_columns.append("date")
    if "hour" in df.columns:
        sort_columns.append("hour")
    if "fingerprint" in df.columns:
        sort_columns.append("fingerprint")
        
    if sort_columns:
        df.sort_values(by=sort_columns, inplace=True)
        df.reset_index(drop=True, inplace=True)
        
    if "date" in df.columns and not df.empty:
        unique_calendar_dates = df["date"].unique()
        unique_calendar_dates = [d for d in unique_calendar_dates if d not in ['', 'nan', 'None']]
        
        date_normalization_map = {date_str: f"Day {idx + 1}" for idx, date_str in enumerate(unique_calendar_dates)}
        df["date"] = df["date"].map(date_normalization_map).fillna(df["date"])
        
    print(f"[VERIFIED-INFO] File loaded: {csv_path} | Dimension Profile: {df.shape}")
    return df

def get_day_integer(day_str):
    """Helper function to parse Day integer index from string."""
    if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
        return int(day_str.split()[1])
    return 0


# ==============================================================================
# REPLICATION ANALYSIS 1: CONSENSUS FLAG QUALIFICATION & CO-OCCURRENCE
# ==============================================================================

def compute_flag_cooccurrence_distribution(df_slice, context_label):
    """
    Replicates Höller et al. Section 3.2 & 3.3 by tracking flag qualification
    frictions (HSDir vs Fast, Stable, Valid co-occurrence).
    """
    os.makedirs("analysis-results/flag_cooccurrence", exist_ok=True)
    computed_metrics = []

    unique_days = [d for d in df_slice["date"].unique() if d not in ['', 'None']]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    for observation_day in unique_days_sorted:
        day_data = df_slice[df_slice["date"] == observation_day].copy()
        
        # Deduplicate per fingerprint for daily unique snapshot
        day_unique = day_data.drop_duplicates(subset=["fingerprint"]).copy()
        total_unique = len(day_unique)
        
        if total_unique == 0:
            continue

        # Evaluate Flag Co-occurrences
        all_flags = day_unique[(day_unique["HSDir"] == 1) & (day_unique["Fast"] == 1) & 
                               (day_unique["Stable"] == 1) & (day_unique["Valid"] == 1)]
        
        hsdir_missing_prereq = day_unique[(day_unique["HSDir"] == 1) & 
                                         ((day_unique["Fast"] == 0) | (day_unique["Stable"] == 0))]
        
        qualified_lacking_hsdir = day_unique[(day_unique["HSDir"] == 0) & (day_unique["Fast"] == 1) & 
                                            (day_unique["Stable"] == 1) & (day_unique["Valid"] == 1)]
        
        total_hsdirs = day_unique[day_unique["HSDir"] == 1]

        all_flags_count = len(all_flags)
        missing_prereq_count = len(hsdir_missing_prereq)
        qualified_lacking_count = len(qualified_lacking_hsdir)
        total_hsdir_count = len(total_hsdirs)

        computed_metrics.append({
            "Observation Date": observation_day,
            "Total Unique Relays": total_unique,
            "Total HSDir Relays": total_hsdir_count,
            "Fully Qualified HSDirs (All Flags)": all_flags_count,
            "HSDirs Missing Fast/Stable": missing_prereq_count,
            "Qualified Relays Lacking HSDir": qualified_lacking_count,
            "Fully Qualified Ratio (%)": round((all_flags_count / total_hsdir_count * 100), 2) if total_hsdir_count > 0 else 0.0
        })

    df_summary_matrix = pd.DataFrame(computed_metrics)
    if df_summary_matrix.empty:
        print(f"[FLAG-ERROR] Summary matrix empty for context: {context_label}")
        return None

    # Daily Plot
    plt.figure(figsize=(14, 6))
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Total HSDir Relays"], 
             marker='o', color='purple', linewidth=2, label='Total Active HSDirs')
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Fully Qualified HSDirs (All Flags)"], 
             marker='s', color='green', linewidth=2, label='Fully Qualified HSDirs')
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Qualified Relays Lacking HSDir"], 
             marker='^', color='orange', linewidth=2, label='Qualified Relays Lacking HSDir Flag')
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["HSDirs Missing Fast/Stable"], 
             marker='x', color='red', linewidth=2, label='HSDirs Missing Prereqs (Unqualified)')

    plt.title(f"Tor v3 Consensus Flag Qualification Friction ({context_label.replace('_', ' ').title()} - Daily)")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Unique Relay Count")
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"analysis-results/flag_cooccurrence/{context_label}_daily_progression.png")
    plt.close()

    # Weekly Aggregation
    df_weekly_prep = df_summary_matrix.copy()
    df_weekly_prep["DayNum"] = df_weekly_prep["Observation Date"].apply(get_day_integer)
    df_weekly_prep["WeekIndex"] = df_weekly_prep["DayNum"].apply(lambda d: f"Week {((d - 1) // 7) + 1}")

    df_weekly_matrix = df_weekly_prep.groupby("WeekIndex").agg({
        "Total Unique Relays": "mean",
        "Total HSDir Relays": "mean",
        "Fully Qualified HSDirs (All Flags)": "mean",
        "HSDirs Missing Fast/Stable": "mean",
        "Qualified Relays Lacking HSDir": "mean"
    }).reset_index()

    for col in ["Total Unique Relays", "Total HSDir Relays", "Fully Qualified HSDirs (All Flags)", 
                "HSDirs Missing Fast/Stable", "Qualified Relays Lacking HSDir"]:
        df_weekly_matrix[col] = df_weekly_matrix[col].round(2)

    df_weekly_matrix.rename(columns={"WeekIndex": "Observation Week"}, inplace=True)

    if not df_weekly_matrix.empty:
        plt.figure(figsize=(10, 6))
        plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["Total HSDir Relays"], 
                 marker='o', color='purple', linewidth=2, label='Weekly Avg HSDir Relays')
        plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["Fully Qualified HSDirs (All Flags)"], 
                 marker='s', color='green', linewidth=2, label='Weekly Avg Fully Qualified')
        plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["Qualified Relays Lacking HSDir"], 
                 marker='^', color='orange', linewidth=2, label='Weekly Avg Qualified Lacking HSDir')
        
        plt.title(f"Tor v3 Weekly Averaged Flag Qualification Profile ({context_label.replace('_', ' ').title()})")
        plt.xlabel("Observation Timeline (Weeks)")
        plt.ylabel("Mean Identity Count")
        plt.legend(loc="upper right")
        plt.tight_layout()
        plt.savefig(f"analysis-results/flag_cooccurrence/{context_label}_weekly_progression.png")
        plt.close()

        weekly_totals = {
            "Observation Week": "Overall Weekly Average",
            "Total Unique Relays": round(df_weekly_matrix["Total Unique Relays"].mean(), 2),
            "Total HSDir Relays": round(df_weekly_matrix["Total HSDir Relays"].mean(), 2),
            "Fully Qualified HSDirs (All Flags)": round(df_weekly_matrix["Fully Qualified HSDirs (All Flags)"].mean(), 2),
            "HSDirs Missing Fast/Stable": round(df_weekly_matrix["HSDirs Missing Fast/Stable"].mean(), 2),
            "Qualified Relays Lacking HSDir": round(df_weekly_matrix["Qualified Relays Lacking HSDir"].mean(), 2)
        }
        df_weekly_export = pd.concat([df_weekly_matrix, pd.DataFrame([weekly_totals])], ignore_index=True)
        df_weekly_export.to_csv(f"analysis-results/flag_cooccurrence/{context_label}_weekly_matrix.csv", index=False)

    daily_totals = {
        "Observation Date": "Overall Average",
        "Total Unique Relays": round(df_summary_matrix["Total Unique Relays"].mean(), 2),
        "Total HSDir Relays": round(df_summary_matrix["Total HSDir Relays"].mean(), 2),
        "Fully Qualified HSDirs (All Flags)": round(df_summary_matrix["Fully Qualified HSDirs (All Flags)"].mean(), 2),
        "HSDirs Missing Fast/Stable": round(df_summary_matrix["HSDirs Missing Fast/Stable"].mean(), 2),
        "Qualified Relays Lacking HSDir": round(df_summary_matrix["Qualified Relays Lacking HSDir"].mean(), 2),
        "Fully Qualified Ratio (%)": round(df_summary_matrix["Fully Qualified Ratio (%)"].mean(), 2)
    }
    df_daily_export = pd.concat([df_summary_matrix, pd.DataFrame([daily_totals])], ignore_index=True)
    df_daily_export.to_csv(f"analysis-results/flag_cooccurrence/{context_label}_daily_matrix.csv", index=False)

    print(f"[FLAG-INFO] Flag qualification analysis matrices saved for context: '{context_label}'")
    return df_summary_matrix


def calculate_flag_cooccurrence_distributions(df, context_label):
    """Wrapper function for Flag Qualification Analysis."""
    print(f"=== PROCESSING {context_label.upper()} FLAG QUALIFICATION FRICTION ANALYSIS ===")
    if df is None or df.empty:
        print(f"[FLAG-ERROR] Missing layout arrays for context '{context_label}'.")
        return None

    global_reporting_matrix = compute_flag_cooccurrence_distribution(df, context_label)

    if context_label in ["tracked_targets", "rotated_tracked_targets"] and "service_type" in df.columns:
        unique_services = df["service_type"].dropna().unique()
        unique_services = [s for s in unique_services if s not in ['', 'nan', 'None']]

        for service in unique_services:
            print(f"    --> Isolating flag metrics for specific service type: {service}")
            sub_population_df = df[df["service_type"] == service]
            if not sub_population_df.empty:
                segmented_label = f"{context_label}_{str(service).lower()}"
                compute_flag_cooccurrence_distribution(sub_population_df, segmented_label)

    return global_reporting_matrix


# ==============================================================================
# REPLICATION ANALYSIS 2: PROVIDER & AS-LEVEL DENSITY CLUSTERING
# ==============================================================================

def compute_provider_density_distribution(df_slice, context_label, top_n_clusters=5):
    """
    Replicates Höller et al. Section 3.5 by clustering active HSDir nodes into IP 
    subnets (/24 and /16) to track provider and operator concentration over time.
    """
    os.makedirs("analysis-results/provider_density", exist_ok=True)

    if df_slice.empty or "ip_address" not in df_slice.columns or "fingerprint" not in df_slice.columns:
        print(f"[PROVIDER-ERROR] Missing required IP/fingerprint fields for label: {context_label}")
        return None

    def extract_v4_subnet(ip, mask=24):
        if isinstance(ip, str) and ip != 'None' and '.' in ip:
            parts = ip.split('.')
            if mask == 24 and len(parts) >= 3:
                return f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"
            elif mask == 16 and len(parts) >= 2:
                return f"{parts[0]}.{parts[1]}.0.0/16"
        return "Unknown"

    df_valid = df_slice[df_slice["ip_address"] != 'None'].copy()
    df_valid["subnet_24"] = df_valid["ip_address"].apply(lambda ip: extract_v4_subnet(ip, 24))

    unique_days = [d for d in df_valid["date"].unique() if d not in ['', 'None']]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    # Identify Top Subnets Across Total Dataset Duration
    overall_unique = df_valid.drop_duplicates(subset=["fingerprint", "subnet_24"])
    top_subnets = overall_unique["subnet_24"].value_counts().head(top_n_clusters).index.tolist()
    top_subnets = [s for s in top_subnets if s != "Unknown"]

    daily_records = []
    for obs_day in unique_days_sorted:
        day_data = df_valid[df_valid["date"] == obs_day]
        day_unique = day_data.drop_duplicates(subset=["fingerprint"])
        
        day_entry = {"Observation Date": obs_day}
        for subnet in top_subnets:
            count = len(day_unique[day_unique["subnet_24"] == subnet])
            day_entry[subnet] = count
        daily_records.append(day_entry)

    df_daily_matrix = pd.DataFrame(daily_records)
    if df_daily_matrix.empty:
        print(f"[PROVIDER-WARNING] No density metrics generated for context: {context_label}")
        return None

    # Daily Plot
    plt.figure(figsize=(13, 7))
    for subnet in top_subnets:
        plt.plot(df_daily_matrix["Observation Date"], df_daily_matrix[subnet], marker='o', linewidth=2, label=f"Subnet {subnet}")

    plt.title(f"Tor v3 Top Active HSDir Subnet Concentrations (/24 IP Clusters)\nDataset Segment: {context_label.replace('_', ' ').title()}")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Unique HSDir Node Count")
    plt.xticks(rotation=45)
    plt.legend(title="Network Clusters", loc="upper left", bbox_to_anchor=(1.02, 1))
    plt.tight_layout()
    plt.savefig(f"analysis-results/provider_density/{context_label}_daily_plot.png")
    plt.close()

    # Weekly Plot & Matrix Export
    df_weekly_prep = df_daily_matrix.copy()
    df_weekly_prep["DayNum"] = df_weekly_prep["Observation Date"].apply(get_day_integer)
    df_weekly_prep["WeekIndex"] = df_weekly_prep["DayNum"].apply(lambda d: f"Week {((d - 1) // 7) + 1}")

    df_weekly_matrix = df_weekly_prep.groupby("WeekIndex")[top_subnets].mean().reset_index()
    df_weekly_matrix.rename(columns={"WeekIndex": "Observation Week"}, inplace=True)

    for subnet in top_subnets:
        df_weekly_matrix[subnet] = df_weekly_matrix[subnet].round(2)

    plt.figure(figsize=(11, 6))
    for subnet in top_subnets:
        plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix[subnet], marker='s', linewidth=2, label=f"Subnet {subnet}")

    plt.title(f"Tor v3 Weekly Averaged Subnet Density Profile (/24 IP Clusters)\nDataset Segment: {context_label.replace('_', ' ').title()}")
    plt.xlabel("Observation Timeline (Weeks)")
    plt.ylabel("Mean HSDir Node Count")
    plt.legend(title="Network Clusters", loc="upper left", bbox_to_anchor=(1.02, 1))
    plt.tight_layout()
    plt.savefig(f"analysis-results/provider_density/{context_label}_weekly_plot.png")
    plt.close()

    # Save CSV Matrices
    daily_totals = {"Observation Date": "Overall Average"}
    weekly_totals = {"Observation Week": "Overall Weekly Average"}
    for subnet in top_subnets:
        daily_totals[subnet] = round(df_daily_matrix[subnet].mean(), 2)
        weekly_totals[subnet] = round(df_weekly_matrix[subnet].mean(), 2)

    df_daily_export = pd.concat([df_daily_matrix, pd.DataFrame([daily_totals])], ignore_index=True)
    df_daily_export.to_csv(f"analysis-results/provider_density/{context_label}_daily_matrix.csv", index=False)

    df_weekly_export = pd.concat([df_weekly_matrix, pd.DataFrame([weekly_totals])], ignore_index=True)
    df_weekly_export.to_csv(f"analysis-results/provider_density/{context_label}_weekly_matrix.csv", index=False)

    print(f"[PROVIDER-INFO] Subnet density matrices saved successfully for context: '{context_label}'")
    return df_daily_matrix


def calculate_provider_density_distributions(df, context_label):
    """Wrapper function for Subnet Provider Concentration Analysis."""
    print(f"=== PROCESSING {context_label.upper()} PROVIDER IP CLUSTER ANALYSIS ===")
    if df is None or df.empty:
        print(f"[PROVIDER-ERROR] Missing layout arrays for context '{context_label}'.")
        return None

    global_reporting_matrix = compute_provider_density_distribution(df, context_label)

    if context_label in ["tracked_targets", "rotated_tracked_targets"] and "service_type" in df.columns:
        unique_services = df["service_type"].dropna().unique()
        unique_services = [s for s in unique_services if s not in ['', 'nan', 'None']]

        for service in unique_services:
            print(f"    --> Isolating provider density metrics for service type: {service}")
            sub_population_df = df[df["service_type"] == service]
            if not sub_population_df.empty:
                segmented_label = f"{context_label}_{str(service).lower()}"
                compute_provider_density_distribution(sub_population_df, segmented_label)

    return global_reporting_matrix


# ==============================================================================
# REPLICATION ANALYSIS 3: PERIODIC REAPPEARANCE & CHURN DYNAMICS
# ==============================================================================

def compute_periodic_reappearance_churn(df_slice, context_label):
    """
    Replicates Höller et al. Section 3.5 by evaluating node persistence, cyclic
    reappearances, and daily join/drop churn metrics.
    """
    os.makedirs("analysis-results/periodic_churn", exist_ok=True)

    if df_slice.empty or "fingerprint" not in df_slice.columns or "date" not in df_slice.columns:
        print(f"[CHURN-ERROR] Missing critical structural fields for label: {context_label}")
        return None

    unique_days = [d for d in df_slice["date"].unique() if d not in ['', 'None']]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    seen_historical_fingerprints = set()
    previous_day_fingerprints = set()

    daily_metrics = []

    for idx, obs_day in enumerate(unique_days_sorted):
        day_data = df_slice[df_slice["date"] == obs_day]
        current_day_fingerprints = set(day_data[day_data["fingerprint"] != 'None']["fingerprint"].unique())

        if idx == 0:
            # First day baseline setup
            seen_historical_fingerprints.update(current_day_fingerprints)
            previous_day_fingerprints = current_day_fingerprints
            daily_metrics.append({
                "Observation Date": obs_day,
                "Active HSDirs": len(current_day_fingerprints),
                "New HSDirs (Joined)": len(current_day_fingerprints),
                "Reappearing HSDirs": 0,
                "Continuous Active HSDirs": len(current_day_fingerprints),
                "Departed HSDirs (Dropped)": 0
            })
            continue

        # Calculate Churn Metrics
        new_nodes = current_day_fingerprints - seen_historical_fingerprints
        reappearing_nodes = (current_day_fingerprints - previous_day_fingerprints) & seen_historical_fingerprints
        continuous_nodes = current_day_fingerprints & previous_day_fingerprints
        departed_nodes = previous_day_fingerprints - current_day_fingerprints

        daily_metrics.append({
            "Observation Date": obs_day,
            "Active HSDirs": len(current_day_fingerprints),
            "New HSDirs (Joined)": len(new_nodes),
            "Reappearing HSDirs": len(reappearing_nodes),
            "Continuous Active HSDirs": len(continuous_nodes),
            "Departed HSDirs (Dropped)": len(departed_nodes)
        })

        # Update historical state trackers
        seen_historical_fingerprints.update(current_day_fingerprints)
        previous_day_fingerprints = current_day_fingerprints

    df_daily_matrix = pd.DataFrame(daily_metrics)
    if df_daily_matrix.empty:
        print(f"[CHURN-WARNING] No periodic churn metrics generated for context: {context_label}")
        return None

    # Daily Plot
    plt.figure(figsize=(14, 6))
    plt.plot(df_daily_matrix["Observation Date"], df_daily_matrix["Continuous Active HSDirs"], 
             marker='o', color='blue', linewidth=2, label='Continuous Active')
    plt.plot(df_daily_matrix["Observation Date"], df_daily_matrix["Reappearing HSDirs"], 
             marker='s', color='orange', linewidth=2, label='Reappearing HSDirs (Cyclic)')
    plt.plot(df_daily_matrix["Observation Date"], df_daily_matrix["New HSDirs (Joined)"], 
             marker='^', color='green', linewidth=2, label='New First-Seen HSDirs')
    plt.plot(df_daily_matrix["Observation Date"], df_daily_matrix["Departed HSDirs (Dropped)"], 
             marker='x', color='red', linewidth=2, label='Departed HSDirs (Dropped)')

    plt.title(f"Tor v3 Periodic Reappearance & Daily Churn Dynamics ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Unique Fingerprint Count")
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"analysis-results/periodic_churn/{context_label}_daily_progression.png")
    plt.close()

    # Weekly Aggregation
    df_weekly_prep = df_daily_matrix.copy()
    df_weekly_prep["DayNum"] = df_weekly_prep["Observation Date"].apply(get_day_integer)
    df_weekly_prep["WeekIndex"] = df_weekly_prep["DayNum"].apply(lambda d: f"Week {((d - 1) // 7) + 1}")

    df_weekly_matrix = df_weekly_prep.groupby("WeekIndex").agg({
        "Active HSDirs": "mean",
        "New HSDirs (Joined)": "mean",
        "Reappearing HSDirs": "mean",
        "Continuous Active HSDirs": "mean",
        "Departed HSDirs (Dropped)": "mean"
    }).reset_index()

    for col in ["Active HSDirs", "New HSDirs (Joined)", "Reappearing HSDirs", 
                "Continuous Active HSDirs", "Departed HSDirs (Dropped)"]:
        df_weekly_matrix[col] = df_weekly_matrix[col].round(2)

    df_weekly_matrix.rename(columns={"WeekIndex": "Observation Week"}, inplace=True)

    if not df_weekly_matrix.empty:
        plt.figure(figsize=(10, 6))
        plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["Continuous Active HSDirs"], 
                 marker='o', color='blue', linewidth=2, label='Weekly Avg Continuous')
        plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["Reappearing HSDirs"], 
                 marker='s', color='orange', linewidth=2, label='Weekly Avg Reappearing')
        plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["Departed HSDirs (Dropped)"], 
                 marker='x', color='red', linewidth=2, label='Weekly Avg Departed')

        plt.title(f"Tor v3 Weekly Averaged Churn Profile ({context_label.replace('_', ' ').title()})")
        plt.xlabel("Observation Timeline (Weeks)")
        plt.ylabel("Mean Identity Count")
        plt.legend(loc="upper right")
        plt.tight_layout()
        plt.savefig(f"analysis-results/periodic_churn/{context_label}_weekly_progression.png")
        plt.close()

        weekly_totals = {
            "Observation Week": "Overall Weekly Average",
            "Active HSDirs": round(df_weekly_matrix["Active HSDirs"].mean(), 2),
            "New HSDirs (Joined)": round(df_weekly_matrix["New HSDirs (Joined)"].mean(), 2),
            "Reappearing HSDirs": round(df_weekly_matrix["Reappearing HSDirs"].mean(), 2),
            "Continuous Active HSDirs": round(df_weekly_matrix["Continuous Active HSDirs"].mean(), 2),
            "Departed HSDirs (Dropped)": round(df_weekly_matrix["Departed HSDirs (Dropped)"].mean(), 2)
        }
        df_weekly_export = pd.concat([df_weekly_matrix, pd.DataFrame([weekly_totals])], ignore_index=True)
        df_weekly_export.to_csv(f"analysis-results/periodic_churn/{context_label}_weekly_matrix.csv", index=False)

    daily_totals = {
        "Observation Date": "Overall Average",
        "Active HSDirs": round(df_daily_matrix["Active HSDirs"].mean(), 2),
        "New HSDirs (Joined)": round(df_daily_matrix["New HSDirs (Joined)"].mean(), 2),
        "Reappearing HSDirs": round(df_daily_matrix["Reappearing HSDirs"].mean(), 2),
        "Continuous Active HSDirs": round(df_daily_matrix["Continuous Active HSDirs"].mean(), 2),
        "Departed HSDirs (Dropped)": round(df_daily_matrix["Departed HSDirs (Dropped)"].mean(), 2)
    }
    df_daily_export = pd.concat([df_daily_matrix, pd.DataFrame([daily_totals])], ignore_index=True)
    df_daily_export.to_csv(f"analysis-results/periodic_churn/{context_label}_daily_matrix.csv", index=False)

    print(f"[CHURN-INFO] Periodic churn matrices saved successfully for context: '{context_label}'")
    return df_daily_matrix


def calculate_periodic_reappearance_churn(df, context_label):
    """Wrapper function for Periodic Reappearance & Churn Analysis."""
    print(f"=== PROCESSING {context_label.upper()} PERIODIC REAPPEARANCE & CHURN ANALYSIS ===")
    if df is None or df.empty:
        print(f"[CHURN-ERROR] Missing layout arrays for context '{context_label}'.")
        return None

    global_reporting_matrix = compute_periodic_reappearance_churn(df, context_label)

    if context_label in ["tracked_targets", "rotated_tracked_targets"] and "service_type" in df.columns:
        unique_services = df["service_type"].dropna().unique()
        unique_services = [s for s in unique_services if s not in ['', 'nan', 'None']]

        for service in unique_services:
            print(f"    --> Isolating churn metrics for specific service type: {service}")
            sub_population_df = df[df["service_type"] == service]
            if not sub_population_df.empty:
                segmented_label = f"{context_label}_{str(service).lower()}"
                compute_periodic_reappearance_churn(sub_population_df, segmented_label)

    return global_reporting_matrix

# MAIN
if __name__ == "__main__":
    print("=" * 60)
    print("""
  _   _ ____  ____  _         
 | | | / ___||  _ \(_)_ __
 | |_| \___ \| | | | | '__|
 |  _  |___) | |_| | | |
 |_| |_|____/|____/|_|_|
     _                _           _
    / \   _ __   __ _| |_   _ ___(_)___
   / _ \ | '_ \ / _` | | | | / __| / __|
  / ___ \| | | | (_| | | |_| \__ \ \__ \                              
 /_/   \_\_| |_|\__,_|_|\__, |___/_|___/
                        |___/
    """)
    print("="*60)
    print("STARTING TOR V3 HSDIR DATA EXTRACTION AND PROCESSING")
    print("="*60)
    
    # Run data Ingestion across log profiles (uncomment to process clean logs)
    # for filename in target_files:
    #     if os.path.exists(filename):
    #         extract_telemetry(filename)
    #     else:
    #         print(f"[INGESTION-ERROR] Target telemetry log not found: {filename}")
            
    print("="*60)
    print("PROCESSING FILE VERIFICATION")
    print("="*60)
    
    df_net_consensus   = validate_sort_data("network_hsdir_consensus_snapshots.csv")
    df_ring_events     = validate_sort_data("hsdir_ring_events.csv")
    df_track_consensus = validate_sort_data("tracked_hsdir_consensus_snapshots.csv")
    df_rot_net         = validate_sort_data("rotated_network_hsdir_consensus_snapshots.csv")
    df_rot_track       = validate_sort_data("rotated_tracked_hsdir_consensus_snapshots.csv")

    calculate_flag_cooccurrence_distributions(df_track_consensus, context_label="tracked_targets")
    calculate_provider_density_distributions(df_track_consensus, context_label="tracked_targets")
    calculate_periodic_reappearance_churn(df_track_consensus, context_label="tracked_targets")

