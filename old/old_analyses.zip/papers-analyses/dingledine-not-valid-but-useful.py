#!/usr/bin/env python3
"""
Tor v3 HSDir Research - Dingledine (2004) Replication & Continuity Suite
Replicates and extends foundational Tor paper analyses using modern v3 HSDir data.
"""

import os
import ast
import json
import pandas as pd
import numpy as np
from datetime import datetime


def validate_sort_data(csv_path):
    """
    Validates, parses, normalizes, and sorts Tor consensus or ring event data from CSV.
    Preserved and adapted from hsdir-analysis-v3.py.
    """
    if not os.path.exists(csv_path):
        print(f"[VERIFY-ERROR] Target file unavailable: {csv_path}")
        return None
    
    df = pd.read_csv(csv_path, low_memory=False)
    
    # Standard string cleaning
    target_str_cols = [
        'ip_address', 'fingerprint', 'status', 'onion_address', 
        'action', 'reason', 'declared_family_id', 'timestamp_dropped', 'service_type'
    ]
    for col in df.columns:
        if col in target_str_cols:
            df[col] = df[col].fillna('None').astype(str)
            df[col] = df[col].replace(['nan', 'NaN', 'None', ''], 'None')
            
    # Family list parsing
    if "declared_family" in df.columns:
        def parse_csv_family_list(val):
            if isinstance(val, (list, tuple, np.ndarray)):
                return list(val)
            if pd.isna(val) or val is None:
                return []
            val_str = str(val).strip()
            if val_str in ['None', 'nan', 'NaN', '', '[]']:
                return []
            if val_str.startswith('[') and val_str.endswith(']'):
                try:
                    parsed = ast.literal_eval(val_str)
                    if isinstance(parsed, list):
                        return parsed
                except Exception:
                    pass
            return [val_str]
        df["declared_family"] = df["declared_family"].apply(parse_csv_family_list)
    else:
        df["declared_family"] = [[] for _ in range(len(df))]

    # Parse and sort by timestamp
    if 'timestamp' in df.columns:
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp').reset_index(drop=True)
    
    sort_columns = []
    if "date" in df.columns:
        sort_columns.append("date")
    if "hour" in df.columns:
        sort_columns.append("hour")
    if "fingerprint" in df.columns:
        sort_columns.append("fingerprint")
        
    if sort_columns:
        df.sort_values(by=sort_columns, inplace=True)
        df.reset_index(drop=True, inplace=True)
        
    if "date" in df.columns and not df.empty:
        unique_calendar_dates = df["date"].unique()
        unique_calendar_dates = [d for d in unique_calendar_dates if str(d) not in ['', 'nan', 'None']]
        
        date_normalization_map = {date_str: f"Day {idx + 1}" for idx, date_str in enumerate(unique_calendar_dates)}
        df["date"] = df["date"].map(date_normalization_map).fillna(df["date"])
        
    return df


def analyze_protocol_evolution_ring_dynamics(ring_events_df):
    """
    Replicates & Extends: Dingledine Section 5.1 & 5.2
    Evaluates v3 Hash Ring Token (HRT) index positioning dynamics vs legacy lookup assumptions.
    """
    print("\n" + "="*80)
    print("ANALYSIS 1: Protocol Evolution Baseline - Ring Position Dynamics (Dingledine Sec 5.1/5.2)")
    print("="*80)
    
    if ring_events_df is None or ring_events_df.empty:
        print("[WARN] Ring events dataset empty or invalid.")
        return {}

    metrics = {}
    
    # Calculate position distribution across ring (0-100%)
    if 'hsdir_index_hrt_100' in ring_events_df.columns:
        hrt_pos = pd.to_numeric(ring_events_df['hsdir_index_hrt_100'], errors='coerce').dropna()
        metrics['hrt_position_mean'] = float(hrt_pos.mean())
        metrics['hrt_position_std'] = float(hrt_pos.std())
        metrics['hrt_position_min'] = float(hrt_pos.min())
        metrics['hrt_position_max'] = float(hrt_pos.max())
        
        print(f"[*] HSDir HRT Ring Position (0-100% Range):")
        print(f"    - Mean Position : {metrics['hrt_position_mean']:.2f}%")
        print(f"    - Std Deviation : {metrics['hrt_position_std']:.2f}% (Ideal uniform std ~28.87%)")
        print(f"    - Min / Max     : {metrics['hrt_position_min']:.2f}% / {metrics['hrt_position_max']:.2f}%")

    # Evaluate distance from Onion target to assigned HSDir
    if 'hsdir_to_onion_ring_position' in ring_events_df.columns:
        distances = pd.to_numeric(ring_events_df['hsdir_to_onion_ring_position'], errors='coerce').dropna()
        metrics['ring_distance_mean'] = float(distances.mean())
        metrics['ring_distance_median'] = float(distances.median())
        
        print(f"[*] Target Onion to HSDir Relative Ring Distance:")
        print(f"    - Mean Distance   : {metrics['ring_distance_mean']:.2f}%")
        print(f"    - Median Distance : {metrics['ring_distance_median']:.2f}%")

    # Group by Service Type (Static vs Ephemeral)
    if 'service_type' in ring_events_df.columns and 'action' in ring_events_df.columns:
        svc_summary = ring_events_df.groupby(['service_type', 'action']).size().unstack(fill_value=0)
        metrics['service_action_breakdown'] = svc_summary.to_dict()
        print("\n[*] Service Type Action Distribution (UPLOADED vs RECEIVED):")
        print(svc_summary.to_string())

    return metrics


def analyze_directory_authority_flag_reliability(consensus_df, ring_events_df=None):
    """
    Replicates & Extends: Dingledine Section 3.4
    Evaluates whether Directory Authority flags (Stable, Guard, Fast) correlate with modern HSDir retention.
    """
    print("\n" + "="*80)
    print("ANALYSIS 2: Directory Authority Flag Dependency & Hosting Reliability (Dingledine Sec 3.4)")
    print("="*80)

    if consensus_df is None or consensus_df.empty:
        print("[WARN] Consensus dataset empty or invalid.")
        return {}

    metrics = {}

    # Parse consensus flags
    def parse_flags(val):
        if isinstance(val, list):
            return val
        if isinstance(val, str):
            try:
                parsed = ast.literal_eval(val)
                if isinstance(parsed, list):
                    return parsed
            except Exception:
                return [f.strip() for f in val.replace('[', '').replace(']', '').replace("'", "").split(',')]
        return []

    if 'flags' in consensus_df.columns:
        consensus_df['parsed_flags'] = consensus_df['flags'].apply(parse_flags)

        
        # Check specific flag presence
        consensus_df['is_stable'] = consensus_df['parsed_flags'].apply(lambda x: 'Stable' in x)
        consensus_df['is_guard'] = consensus_df['parsed_flags'].apply(lambda x: 'Guard' in x)
        consensus_df['is_fast'] = consensus_df['parsed_flags'].apply(lambda x: 'Fast' in x)

        total_relays = len(consensus_df)
        stable_count = int(consensus_df['is_stable'].sum())
        guard_count = int(consensus_df['is_guard'].sum())
        fast_count = int(consensus_df['is_fast'].sum())

        metrics['flag_counts'] = {
            'total_relays': total_relays,
            'stable': stable_count,
            'guard': guard_count,
            'fast': fast_count
        }

        print(f"[*] Consensus Flag Distribution among HSDirs (Total Sampled: {total_relays}):")
        print(f"    - Stable Flag Presence : {stable_count} ({stable_count/total_relays*100:.2f}%)")
        print(f"    - Guard Flag Presence  : {guard_count} ({guard_count/total_relays*100:.2f}%)")
        print(f"    - Fast Flag Presence   : {fast_count} ({fast_count/total_relays*100:.2f}%)")

        # Evaluate absences/instability grouped by Stable flag
        if 'consecutive_hourly_absences' in consensus_df.columns:
            consensus_df['consecutive_hourly_absences'] = pd.to_numeric(consensus_df['consecutive_hourly_absences'], errors='coerce').fillna(0)
            absence_by_stable = consensus_df.groupby('is_stable')['consecutive_hourly_absences'].mean()
            metrics['mean_absences_by_stable'] = absence_by_stable.to_dict()
            
            print("\n[*] Mean Hourly Absences by Authority 'Stable' Flag Assignment:")
            print(f"    - Non-Stable HSDirs : {absence_by_stable.get(False, 0.0):.3f} mean absences")
            print(f"    - Stable HSDirs     : {absence_by_stable.get(True, 0.0):.3f} mean absences")

    return metrics


def analyze_sybil_concentration_and_operator_clusters(consensus_df):
    """
    Replicates & Extends: Dingledine Section 9.1 & 9.2
    Quantifies Sybil vulnerability and operator concentration across IP subnets (/16, /24) and declared families.
    """
    print("\n" + "="*80)
    print("ANALYSIS 3: Sybil Concentration & Operator Clustering (Dingledine Sec 9.1/9.2)")
    print("="*80)

    if consensus_df is None or consensus_df.empty:
        print("[WARN] Consensus dataset empty or invalid.")
        return {}

    metrics = {}

    # Subnet Extraction
    if 'ip_address' in consensus_df.columns:
        valid_ips = consensus_df[consensus_df['ip_address'] != 'None']['ip_address']
        
        def get_subnet_24(ip):
            parts = str(ip).split('.')
            return '.'.join(parts[:3]) + '.0/24' if len(parts) == 4 else 'Invalid'

        def get_subnet_16(ip):
            parts = str(ip).split('.')
            return '.'.join(parts[:2]) + '.0.0/16' if len(parts) == 4 else 'Invalid'

        subnets_24 = valid_ips.apply(get_subnet_24)
        subnets_16 = valid_ips.apply(get_subnet_16)

        top_24 = subnets_24.value_counts().head(5)
        top_16 = subnets_16.value_counts().head(5)

        metrics['top_subnet_24'] = top_24.to_dict()
        metrics['top_subnet_16'] = top_16.to_dict()

        print(f"[*] Top IPv4 /24 Subnet Clusters (Sybil Vulnerability Indicator):")
        for subnet, count in top_24.items():
            print(f"    - Subnet {subnet:<18}: {count} HSDir instances ({count/len(valid_ips)*100:.2f}%)")

        print(f"\n[*] Top IPv4 /16 Subnet Clusters:")
        for subnet, count in top_16.items():
            print(f"    - Subnet {subnet:<18}: {count} HSDir instances ({count/len(valid_ips)*100:.2f}%)")

    # Family Concentration
    if 'declared_family_id' in consensus_df.columns:
        valid_fam = consensus_df[consensus_df['declared_family_id'] != 'None']['declared_family_id']
        top_families = valid_fam.value_counts().head(5)
        metrics['top_family_ids'] = top_families.to_dict()

        print(f"\n[*] Top Declared Effective Family Groups:")
        for fam_id, count in top_families.items():
            print(f"    - Family ID {fam_id[:20]}... : {count} HSDir instances ({count/len(consensus_df)*100:.2f}%)")

    return metrics


def analyze_hsdir_churn_and_lifetime_stability(consensus_df):
    """
    Replicates & Extends: Dingledine Section 3.1 & 5.2
    Measures HSDir relay churn rates, active longevity, and transition frequencies.
    """
    print("\n" + "="*80)
    print("ANALYSIS 4: HSDir Node Churn & Lifetime Stability Analysis (Dingledine Sec 3.1/5.2)")
    print("="*80)

    if consensus_df is None or consensus_df.empty:
        print("[WARN] Consensus dataset empty or invalid.")
        return {}

    metrics = {}

    # Status distribution
    if 'status' in consensus_df.columns:
        status_counts = consensus_df['status'].value_counts()
        metrics['status_distribution'] = status_counts.to_dict()
        print("[*] Ring HSDir Operational Status Breakdown:")
        for status, count in status_counts.items():
            print(f"    - Status '{status}': {count} nodes ({count/len(consensus_df)*100:.2f}%)")

    # Discovery vs Drop Lifespans
    if 'first_discovery' in consensus_df.columns and 'last_timestamp' in consensus_df.columns:
        consensus_df['first_discovery_dt'] = pd.to_datetime(consensus_df['first_discovery'], errors='coerce')
        consensus_df['last_timestamp_dt'] = pd.to_datetime(consensus_df['last_timestamp'], errors='coerce')
        
        consensus_df['lifespan_hours'] = (
            consensus_df['last_timestamp_dt'] - consensus_df['first_discovery_dt']
        ).dt.total_seconds() / 3600.0

        valid_lifespans = consensus_df['lifespan_hours'].dropna()
        metrics['lifespan_mean_hours'] = float(valid_lifespans.mean()) if not valid_lifespans.empty else 0.0
        metrics['lifespan_max_hours'] = float(valid_lifespans.max()) if not valid_lifespans.empty else 0.0

        print(f"\n[*] HSDir Consensus Longevity Metrics:")
        print(f"    - Mean Observed Lifespan : {metrics['lifespan_mean_hours']:.2f} hours")
        print(f"    - Max Observed Lifespan  : {metrics['lifespan_max_hours']:.2f} hours")

    return metrics


def run_dingledine_replication_suite(ring_events_csv, consensus_csv, output_json=None):
    """
    Execution Wrapper: Integrates validation, analytical workflows, and structured reporting.
    """
    print(f"=== Starting Tor v3 Replication Suite for Dingledine et al. ===")
    print(f"Timestamp: {datetime.now().isoformat()}\n")

    # 1. Validate and load datasets
    print(f"[+] Loading Ring Events CSV: {ring_events_csv}")
    ring_events_df = validate_sort_data(ring_events_csv)
    
    print(f"[+] Loading Consensus Snapshots CSV: {consensus_csv}")
    consensus_df = validate_sort_data(consensus_csv)

    results = {}

    # 2. Execute analytical functions
    if ring_events_df is not None:
        results['protocol_evolution'] = analyze_protocol_evolution_ring_dynamics(ring_events_df)
    
    if consensus_df is not None:
        results['directory_flags'] = analyze_directory_authority_flag_reliability(consensus_df, ring_events_df)
        results['sybil_concentration'] = analyze_sybil_concentration_and_operator_clusters(consensus_df)
        results['churn_stability'] = analyze_hsdir_churn_and_lifetime_stability(consensus_df)

    # 3. Export structured summary
    if output_json:
        with open(output_json, 'w') as f:
            json.dump(results, f, indent=4)
        print(f"\n[+] Consolidated analysis results exported to: {output_json}")

    print("\n=== Analytical Suite Execution Complete ===")
    return results


if __name__ == "__main__":
    # Example local paths for stand-alone execution
    RING_EVENTS_CSV = "hsdir_ring_events.csv"
    CONSENSUS_CSV = "tracked_hsdir_consensus_snapshots.csv"
    OUTPUT_JSON = "dingledine_replication_summary.json"

    # Execute wrapper if files exist
    if os.path.exists(RING_EVENTS_CSV) or os.path.exists(CONSENSUS_CSV):
        run_dingledine_replication_suite(RING_EVENTS_CSV, CONSENSUS_CSV, OUTPUT_JSON)
    else:
        print("[!] Execution note: Place target CSV datasets in working directory or update file paths.")