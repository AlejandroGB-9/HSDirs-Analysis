#!/usr/bin/env python3

import os
import json
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# ENVIRONMENT SETUP & GLOBAL CONFIGURATION

sns.set_theme(style="whitegrid")
plt.rcParams.update({
    'figure.figsize': (12, 6),
    'axes.labelsize': 12,
    'axes.titlesize': 14,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'figure.titlesize': 16,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight'
})

target_files = [
    "network_hsdir_consensus_snapshots.jsonl",
    "hsdir_ring_events.jsonl",
    "tracked_hsdir_consensus_snapshots.jsonl",
    "rotated_network_hsdir_consensus_snapshots.jsonl",
    "rotated_tracked_hsdir_consensus_snapshots.jsonl"
]

print("[INIT] Environment configurations and path parameters established.")

# INGESTION, CLEANSING, AND CACHING PIPELINE
def extract_and_flatten_telemetry(target_filename):
    output_csv = target_filename.replace('.jsonl', '.csv')
    print(f"[PROCESS] Ingesting log arrays from source stream: {target_filename}")
    
    consolidated_records = []
    
    with open(target_filename, 'r') as source_file:
        for index, text_line in enumerate(source_file):
            if not text_line.strip():
                continue
            try:
                parsed_json = json.loads(text_line)
            except json.JSONDecodeError as err:
                print(f"[METRIC ERROR] Skipping malformed schema line entry {index}: {err}")
                continue

            base_timestamp = parsed_json.get("timestamp")
            captured_onion = parsed_json.get("onion_address", None)
            
            nested_array_key = None
            if "relays" in parsed_json:
                nested_array_key = "relays"
                
            if nested_array_key:
                sub_records = parsed_json.get(nested_array_key, [])
                for entry in sub_records:
                    flattened_item = entry.copy()
                    flattened_item["timestamp"] = base_timestamp
                    if captured_onion:
                        flattened_item["onion_address"] = captured_onion
                    consolidated_records.append(flattened_item)
            else:
                consolidated_records.append(parsed_json)
                
    if not consolidated_records:
        print(f"[WARNING] Zero usable records extracted from {target_filename}.")
        return False
        
    df_processed = pd.DataFrame(consolidated_records)
    
    if "timestamp" in df_processed.columns:
        parsed_datetimes = pd.to_datetime(df_processed["timestamp"], errors='coerce')
        df_processed["date"] = parsed_datetimes.dt.strftime("%m-%d")
        df_processed["hour"] = parsed_datetimes.dt.strftime("%H:%M")
        
    if "or_port" in df_processed.columns:
        df_processed.drop(columns=["or_port"], inplace=True, errors='ignore')
        
    for technical_flag in ["Fast", "HSDir", "Stable", "Valid"]:
        if "flags" in df_processed.columns:
            df_processed[technical_flag] = df_processed["flags"].apply(
                lambda val: 1 if (isinstance(val, list) and technical_flag in val) or \
                                 (isinstance(val, str) and technical_flag in val) else 0
            )
        else:
            df_processed[technical_flag] = 0
            
    if "flags" in df_processed.columns:
        df_processed.drop(columns=["flags"], inplace=True, errors='ignore')
        
    for col in df_processed.columns:
        if col in ['ip', 'fingerprint', 'status', 'onion_address', 'action', 'reason', 'family_ids', 'timestamp_dropped']:
            df_processed[col] = df_processed[col].astype(str).replace(['nan', 'None', '0', '0.0'], '')
        elif pd.api.types.is_numeric_dtype(df_processed[col]):
            df_processed[col] = df_processed[col].fillna(0)
        else:
            df_processed[col] = df_processed[col].fillna('')
    
    df_processed.to_csv(output_csv, index=False)
    print(f"[SUCCESS] Normalized and written to disk: {output_csv} [Rows: {len(df_processed)}]")
    return True

# VERIFICATION, SCHEMA VALIDATION, AND CHRONOLOGICAL SORT
def verify_and_load_cached_matrix(csv_path):
    if not os.path.exists(csv_path):
        print(f"[CRITICAL] Operational vector file unavailable on path: {csv_path}")
        return None
    
    df = pd.read_csv(csv_path, low_memory=False)
    
    for col in df.columns:
        if col in ['ip', 'fingerprint', 'status', 'onion_address', 'action', 'reason', 'family_ids', 'timestamp_dropped']:
            df[col] = df[col].fillna('').astype(str)
    
    sort_columns = []
    if "date" in df.columns:
        sort_columns.append("date")
    if "hour" in df.columns:
        sort_columns.append("hour")
    if "fingerprint" in df.columns:
        sort_columns.append("fingerprint")
        
    if sort_columns:
        df.sort_values(by=sort_columns, inplace=True)
        df.reset_index(drop=True, inplace=True)
        
    print(f"[VERIFIED] File loaded: {csv_path} | Dimension Profile: {df.shape}")
    return df

# ANALYSIS 1: NET-WIDE AND TRACKED (+ROATED) STABILITY ANALYSIS (REVISED)
def calculate_stability_matrices(df, context_label):
    print(f"=== PROCESSING {context_label.upper()} CONSENSUS RESILIENCE ===")
    if df is None or df.empty:
        print(f"[ERROR] DataFrame for context '{context_label}' is empty or missing.")
        return None
        
    computed_metrics = []
    grouped_epochs = df.groupby("date")
    
    for observation_day, data_slice in grouped_epochs:
        if observation_day == '':
            continue
        total_unique_identities = data_slice["fingerprint"].nunique()
        
        offline_indicators = (data_slice["status"] == "offline") | \
                             (data_slice.get("consecutive_hourly_absences", pd.Series(0, index=data_slice.index)) > 0)
        total_offline_identities = data_slice[offline_indicators]["fingerprint"].nunique()
        
        total_active_identities = total_unique_identities - total_offline_identities
        
        ratio_active = (total_active_identities / total_unique_identities * 100) if total_unique_identities > 0 else 0
        ratio_offline = 100.0 - ratio_active
        
        computed_metrics.append({
            "Observation Date": observation_day,
            "Total Unique HSDirs": total_unique_identities,
            "Active Directories": total_active_identities,
            "Active Ratio (%)": round(ratio_active, 2),
            "Offline Attrition": total_offline_identities,
            "Offline Ratio (%)": round(ratio_offline, 2)
        })

    df_summary_matrix = pd.DataFrame(computed_metrics)
    
    matrix_csv_name = f"analysis-results/{context_label}_hsdir_daily_stability_matrix.csv"
    df_summary_matrix.to_csv(matrix_csv_name, index=False)
    print(f"[DATA EXPORT] Saved {context_label} daily stability matrix table to: {matrix_csv_name}")
    
    if not df_summary_matrix.empty:
        plt.figure(figsize=(14, 6))
        plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Active Directories"], marker='o', color='green', linewidth=2, label='Active HSDirs Count')
        plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Offline Attrition"], marker='o', color='red', linewidth=2, label='Offline HSDirs Count')

        for x, y in zip(df_summary_matrix["Observation Date"], df_summary_matrix["Active Directories"]):
            plt.annotate(
                f"{y}",
                (x, y),
                textcoords="offset points",
                xytext=(0, 8),   # 8 points above the marker
                ha='center',
                fontsize=9
            )

        for x, y in zip(df_summary_matrix["Observation Date"], df_summary_matrix["Offline Attrition"]):
            plt.annotate(
                f"{y}",
                (x, y),
                textcoords="offset points",
                xytext=(0, 8),   # 8 points above the marker
                ha='center',
                fontsize=9
            )

        plt.title(f"Tor v3 Active HSDirs vs Attrition Churn ({context_label.replace('_', ' ').title()} - 30-Day Timeline)")
        plt.xlabel("Observation Timeline")
        plt.ylabel("Unique Fingerprint Directory Count")
        plt.xticks(rotation=45)
        plt.legend(loc="upper right")
        plt.tight_layout()
        
        figure_png_name = f"analysis-results/{context_label}_hsdir_daily_stability_progression.png"
        plt.savefig(figure_png_name)
        plt.close()
        print(f"[GRAPHIC EXPORT] Saved {context_label} timeline visualization profile to: {figure_png_name}")
        
    return df_summary_matrix

# ANALYSIS 2: SYBIL INFRASTRUCTURE CLUSTERING & AS BLOCK ANALYSIS
def analyze_sybil_and_infrastructure_risk(df, context_label):
    print(f"\n=== PROCESSING {context_label.upper()} SYBIL & ROUTING RISKS ===")
    
    if df is None or df.empty:
        print(f"[ERROR] Infrastructure matrix for '{context_label}' empty or unavailable.")
        return
        
    # Standardize string parameters to prevent unreadable column exceptions
    if "ip_address" not in df.columns:
        df["ip_address"] = ""
    df["ip_block"] = df["ip_address"].astype(str)

    print(df["ip_block"])
    
    s = df["ip_block"]

    df["/24_block"] = s.fillna("").astype(str).str.strip()
    df["/24_block"] = df["/24_block"].where(df["/24_block"].str.count(r"\.") >= 3, "UNKNOWN").str.split(".").str[:3].str.join(".")

    df["/16_block"] = df["ip_block"].fillna("").astype(str).str.strip()
    df["/16_block"] = df["/16_block"].where(df["/16_block"].str.count(r"\.") >= 2, "UNKNOWN").str.split(".").str[:2].str.join(".")
    
    print(df["/16_block"])
    print(df["/24_block"])
    
    # Isolate missing nodes
    offline_indicators = (df["status"] == "offline") | \
                         (df.get("consecutive_hourly_absences", pd.Series(0, index=df.index)) > 0)
    offline_subset = df[offline_indicators].copy()
    
    if offline_subset.empty:
        print(f"[INFO] No structural directory absences detected inside {context_label} data models.")
        return
        
    # Analyze daily progression profiles of top subnet concentrations
    subnet_daily_matrix = offline_subset.groupby(["date", "/24_block"])["fingerprint"].count().reset_index()
    subnet_daily_matrix.rename(columns={"fingerprint": "Outage Count"}, inplace=True)
    
    # Save subnet tracking metrics table to disk path
    subnet_csv_name = f"analysis-results/{context_label}_hsdir_sybil_subnet_report.csv"
    subnet_daily_matrix.sort_values(by="Outage Count", ascending=False).to_csv(subnet_csv_name, index=False)
    print(f"[DATA EXPORT] Saved {context_label} network tracking log to: {subnet_csv_name}")
    
    # Visual Tracking: Cumulative Top Outages across the 30-day scope
    top_blocks = subnet_daily_matrix.groupby("/24_block")["Outage Count"].sum().sort_values(ascending=False).head(5).index.tolist()
    top_blocks = [b for b in top_blocks if b != "UNKNOWN"]
    
    if top_blocks:
        plt.figure(figsize=(14, 6))
        plot_data = subnet_daily_matrix[subnet_daily_matrix["/24_block"].isin(top_blocks)]
        sns.lineplot(data=plot_data, x="date", y="Outage Count", hue="/24_block", marker='s', linewidth=2)
        
        plt.title(f"Daily Coordinated Subnet Absences ({context_label.replace('_', ' ').title()} Vulnerable Clusters)")
        plt.xlabel("Observation Timeline Frame (Chronological ISO Date)")
        plt.ylabel("Concurrent Node Displacements")
        plt.xticks(rotation=45)
        plt.legend(title="Target Subnet Block", loc="upper left")
        plt.tight_layout()
        
        subnet_png_name = f"analysis-results/{context_label}_hsdir_sybil_subnet_outages.png"
        plt.savefig(subnet_png_name)
        plt.close()
        print(f"[GRAPHIC EXPORT] Saved {context_label} routing concentration plot to: {subnet_png_name}")

# ANALYSIS 3: HASH RING TABLE (HRT) SPATIAL MAPPINGS & DISTRIBUTIONS
def generate_spatial_hrt_plots(df_tracked_source, df_network_source):
    print("\n=== PROCESSING HASH RING TABLE SPATIAL LAYOUT ANALYSIS ===")
    
    target_field = "hsdir_to_onion_ring_position"
    background_field = "hsdir_index_hrt_100"
    
    has_tracked = df_tracked_source is not None and target_field in df_tracked_source.columns
    has_network = df_network_source is not None and background_field in df_network_source.columns
    
    if not (has_tracked or has_network):
        print("[WARNING] Positional distance features missing. Hash ring spatial tracking skipped.")
        return

    plt.figure(figsize=(14, 6))
    
    if has_tracked:
        tracked_clean = df_tracked_source.dropna(subset=[target_field]).copy()
        spatial_csv_name = "analysis-results/tracked_hash_ring_spatial_summary.csv"
        tracked_clean.groupby("date")[target_field].describe().to_csv(spatial_csv_name)
        print(f"[DATA EXPORT] Saved coordinate distance metrics to: {spatial_csv_name}")
        
        sns.violinplot(data=tracked_clean, x="date", y=target_field, color="darkred", inner="quart")
        plt.title("Targeted HSDir Proximity Position Distortions (30-Day Spatial Track Progression)")
        plt.ylabel("Ring Arc Distance Offset Percentage")
    elif has_network:
        network_clean = df_network_source.dropna(subset=[background_field])
        sns.boxplot(data=network_clean, x="date", y=background_field, color="teal")
        plt.title("Global Consensus Background Hash Ring Layout Matrix Dispersion Tracker")
        plt.ylabel("Consensus Ring Circumference Percentage")

    plt.xlabel("Observation Timeline Frame (Chronological ISO Date)")
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    figure_png_name = "analysis-results/hsdir_hash_ring_spatial_progression.png"
    plt.savefig(figure_png_name)
    plt.close()
    print(f"[GRAPHIC EXPORT] Saved spatial geometry tracking profile plot to: {figure_png_name}")

# ANALYSIS 4: TOPO SHIFT ANALYSIS ACROSS SRV ROTATION BOUNDARIES
def analyze_srv_rotation_impact(df_standard, df_rotated, context_label):
    print(f"\n=== PROCESSING {context_label.upper()} SRV ROTATION TOPOLOGICAL SHIFTS ===")
    if df_standard is None or df_rotated is None:
        print(f"[INFO] Post-rotation parameters omitted or unreadable across {context_label} workspaces.")
        return
        
    available_dates = sorted(list(set(df_standard["date"].unique()).intersection(set(df_rotated["date"].unique()))))
    srv_progression_metrics = []
    
    for day in available_dates:
        if day == '':
            continue
        std_slice = set(df_standard[df_standard["date"] == day]["fingerprint"].unique())
        rot_slice = set(df_rotated[df_rotated["date"] == day]["fingerprint"].unique())
        
        persistent = std_slice.intersection(rot_slice)
        displaced = std_slice.difference(rot_slice)
        introduced = rot_slice.difference(std_slice)
        
        srv_progression_metrics.append({
            "Observation Date": day,
            "Persistent Nodes": len(persistent),
            "Displaced Nodes": len(displaced),
            "Introduced Nodes": len(introduced)
        })
        
    df_srv_summary = pd.DataFrame(srv_progression_metrics)
    
    # Save the day-by-day SRV tracking table directly to disk
    srv_csv_name = f"analysis-results/{context_label}_srv_rotation_summary.csv"
    df_srv_summary.to_csv(srv_csv_name, index=False)
    print(f"[DATA EXPORT] Saved {context_label} SRV drift tracking table to: {srv_csv_name}")
    
    # Render tracking stack chart progression over the 30-day window
    if not df_srv_summary.empty:
        plt.figure(figsize=(14, 6))
        x_axis = df_srv_summary["Observation Date"]
        
        plt.bar(x_axis, df_srv_summary["Persistent Nodes"], label="Persistent (Survived Rotation)", color="navy")
        plt.bar(x_axis, df_srv_summary["Displaced Nodes"], bottom=df_srv_summary["Persistent Nodes"], label="Displaced (Dropped from Ring)", color="crimson")
        plt.bar(x_axis, df_srv_summary["Introduced Nodes"], bottom=df_srv_summary["Persistent Nodes"] + df_srv_summary["Displaced Nodes"], label="Introduced (New Mappings)", color="goldenrod")
        
        plt.title(f"Tor v3 Topological Drift Across SRV Consensus Update Boundaries ({context_label.replace('_', ' ').title()})")
        plt.xlabel("Observation Timeline Frame (Chronological ISO Date)")
        plt.ylabel("Unique Directory Identity Elements")
        plt.xticks(rotation=45)
        plt.legend(loc="lower left")
        plt.tight_layout()
        
        srv_png_name = f"analysis-results/{context_label}_srv_rotation_timeline.png"
        plt.savefig(srv_png_name)
        plt.close()
        print(f"[GRAPHIC EXPORT] Saved {context_label} SRV drift timeline chart to: {srv_png_name}")

# ANALYSIS 5: LIVE TARGETED HSDIR EVENT TELEMETRY DIAGNOSTICS
def process_live_event_telemetry(df_events_source, context_label):
    print(f"\n=== PROCESSING {context_label.upper()} LIVE TARGETED EVENT DIAGNOSTICS ===")
    if df_events_source is None or df_events_source.empty:
        print(f"[ERROR] Live transaction event logs for '{context_label}' are empty or missing.")
        return
        
    if "date" in df_events_source.columns and "action" in df_events_source.columns:
        # Construct daily cross-tabulation metrics tracking actions across the 30 days
        daily_events = pd.crosstab(df_events_source["date"], df_events_source["action"])
        
        # Save structural performance data table directly to disk
        events_csv_name = f"analysis-results/{context_label}_live_events_summary.csv"
        daily_events.to_csv(events_csv_name)
        print(f"[DATA EXPORT] Saved {context_label} transactional performance summary matrix to: {events_csv_name}")
        
        # Render 30-day timeline operational performance plot
        plt.figure(figsize=(14, 6))
        for transaction_column in daily_events.columns:
            plt.plot(daily_events.index, daily_events[transaction_column], marker='x', label=f"Action: {transaction_column}", linewidth=2)
            
        plt.title(f"Live Activity & Descriptor Transaction Volume Profiles ({context_label.replace('_', ' ').title()})")
        plt.xlabel("Observation Timeline Frame (Chronological ISO Date)")
        plt.ylabel("Log Execution Transaction Frequency")
        plt.xticks(rotation=45)
        plt.legend(loc="upper left")
        plt.tight_layout()
        
        events_png_name = f"analysis-results/{context_label}_live_events_timeline.png"
        plt.savefig(events_png_name)
        plt.close()
        print(f"[GRAPHIC EXPORT] Saved {context_label} operational performance trace plot to: {events_png_name}")

if __name__ == "__main__":
    print("="*60)
    print("STARTING TOR V3 HSDIR DATA EXTRACTION AND PROCESSING")
    print("="*60)
    
    # Run data Ingestion across log profiles
    # for filename in target_files:
    #     if os.path.exists(filename):
    #         extract_and_flatten_telemetry(filename)
    #     else:
    #         print(f"[SKIPPED] Target telemetry log not found in working path: {filename}")
            
    print("="*60)
    print("PROCESSING FILE VERIFICATION")
    print("="*60)
    
    # Reload cleaned frames with explicit index checking and multi-index sorting
    df_net_consensus   = verify_and_load_cached_matrix("network_hsdir_consensus_snapshots.csv")
    df_ring_events     = verify_and_load_cached_matrix("hsdir_ring_events.csv")
    df_track_consensus = verify_and_load_cached_matrix("tracked_hsdir_consensus_snapshots.csv")
    df_rot_net         = verify_and_load_cached_matrix("rotated_network_hsdir_consensus_snapshots.csv")
    df_rot_track       = verify_and_load_cached_matrix("rotated_tracked_hsdir_consensus_snapshots.csv")

    print("="*60)
    print("PROCESSING CAPACITY STABILITY ANALYSIS")
    print("="*60)
    
    # Analysis for Network-Wide and Tracked HSDirs over the 30-day timeline
    if df_net_consensus is not None:
        calculate_stability_matrices(df_net_consensus, context_label="network_wide")
        # analyze_sybil_and_infrastructure_risk(df_net_consensus, context_label="network_wide")
        
    if df_track_consensus is not None:
        calculate_stability_matrices(df_track_consensus, context_label="tracked_targets")
        # analyze_sybil_and_infrastructure_risk(df_track_consensus, context_label="tracked_targets")

    if df_rot_net is not None:
        calculate_stability_matrices(df_rot_net, context_label="rotated_network_wide")
        # analyze_sybil_and_infrastructure_risk(df_rot_net, context_label="rotated_network_wide")

    if df_rot_track is not None:
        calculate_stability_matrices(df_rot_track, context_label="rotated_tracked_targets")
        # analyze_sybil_and_infrastructure_risk(df_rot_track, context_label="rotated_tracked_targets")
        
    # if df_track_consensus is not None or df_net_consensus is not None:
        # generate_spatial_hrt_plots(df_track_consensus, df_net_consensus)
        
    # # Analyze Shared Random Value (SRV) rotation shifts across both dataset variants
    # analyze_srv_rotation_impact(df_net_consensus, df_rot_net, context_label="network_wide")
    # analyze_srv_rotation_impact(df_track_consensus, df_rot_track, context_label="tracked_targets")
    
    # # Evaluate live event diagnostics broken down by telemetry classification mapping
    # if df_ring_events is not None:
    #     # Evaluate global events
    #     process_live_event_telemetry(df_ring_events, context_label="network_wide_events")
        
    #     # Isolate tracked contexts from event streams if targeted tracking flags are present
    #     if "onion_address" in df_ring_events.columns:
    #         tracked_events = df_ring_events[df_ring_events["onion_address"] != ""].copy()
    #         if not tracked_events.empty:
    #             process_live_event_telemetry(tracked_events, context_label="tracked_target_events")

    print("="*60)
    print("ANALYSIS COMPLETED")
    print("="*60)
