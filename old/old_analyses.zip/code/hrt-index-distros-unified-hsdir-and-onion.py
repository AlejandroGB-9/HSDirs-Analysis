def compute_hrt_index_distributions(df_slice, context_label):
    os.makedirs("analysis-results/hrt_index_distributions", exist_ok=True)
    computed_metrics = []
    
    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    has_onion_idx = "mapped_onion_index_100" in df_slice.columns #mapped_onion
    has_rot_onion_idx = "last_known_onion_index_100" in df_slice.columns #last_known_onion
    has_hsdir_idx = "hsdir_index_hrt_100" in df_slice.columns

    if (not has_onion_idx or not has_rot_onion_idx) and not has_hsdir_idx :
        print(f"[HRT-INDEX-ERROR] Neither onion's index nor HSDir's index found for {context_label}")
        return None

    unique_days = [d for d in df_slice["date"].unique() if d not in ['', 'None']]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)
    
    for observation_day in unique_days_sorted:
        day_data = df_slice[df_slice["date"] == observation_day].copy()
        
        # 1. Process HSDir HRT Index Distributions (Unique by Fingerprint)
        hsdir_1st, hsdir_2nd, hsdir_3rd = 0, 0, 0
        hsdir_1st_ratio, hsdir_2nd_ratio, hsdir_3rd_ratio = 0.0, 0.0, 0.0
        total_unique_hsdirs = 0
        
        if has_hsdir_idx:
            day_data["parsed_hsdir_idx"] = pd.to_numeric(day_data["hsdir_index_hrt_100"], errors='coerce')
            valid_hsdir = day_data.dropna(subset=["parsed_hsdir_idx", "fingerprint"])
            valid_hsdir = valid_hsdir[valid_hsdir["fingerprint"] != "None"]
            unique_hsdirs = valid_hsdir.drop_duplicates(subset=["fingerprint"])
            
            total_unique_hsdirs = unique_hsdirs["fingerprint"].nunique()
            if total_unique_hsdirs > 0:
                hsdir_1st = unique_hsdirs[unique_hsdirs["parsed_hsdir_idx"] <= 33.33]["fingerprint"].nunique()
                hsdir_2nd = unique_hsdirs[(unique_hsdirs["parsed_hsdir_idx"] > 33.33) & (unique_hsdirs["parsed_hsdir_idx"] <= 66.66)]["fingerprint"].nunique()
                hsdir_3rd = unique_hsdirs[unique_hsdirs["parsed_hsdir_idx"] > 66.66]["fingerprint"].nunique()
                
                hsdir_1st_ratio = (hsdir_1st / total_unique_hsdirs * 100)
                hsdir_2nd_ratio = (hsdir_2nd / total_unique_hsdirs * 100)
                hsdir_3rd_ratio = (hsdir_3rd / total_unique_hsdirs * 100)

        # 2. Process Onion Target Index Distributions (Unique by Onion Address if available)
        onion_1st, onion_2nd, onion_3rd = 0, 0, 0
        onion_1st_ratio, onion_2nd_ratio, onion_3rd_ratio = 0.0, 0.0, 0.0
        total_unique_onions = 0
        
        onion_col = "mapped_onion" if "mapped_onion" in day_data.columns else ("last_known_onion" if "last_known_onion" in day_data.columns else "fingerprint")
        
        if (has_onion_idx or has_rot_onion_idx) and onion_col in day_data.columns:
            if has_onion_idx:
                day_data["parsed_onion_idx"] = pd.to_numeric(day_data["mapped_onion_index_100"], errors='coerce')
            else:
                day_data["parsed_onion_idx"] = pd.to_numeric(day_data["last_known_onion_index_100"], errors='coerce')
            valid_onion = day_data.dropna(subset=["parsed_onion_idx", onion_col])
            valid_onion = valid_onion[valid_onion[onion_col] != "None"]
            unique_onions = valid_onion.drop_duplicates(subset=[onion_col])
            
            total_unique_onions = unique_onions[onion_col].nunique()
            if total_unique_onions > 0:
                onion_1st = unique_onions[unique_onions["parsed_onion_idx"] <= 33.33][onion_col].nunique()
                onion_2nd = unique_onions[(unique_onions["parsed_onion_idx"] > 33.33) & (unique_onions["parsed_onion_idx"] <= 66.66)][onion_col].nunique()
                onion_3rd = unique_onions[unique_onions["parsed_onion_idx"] > 66.66][onion_col].nunique()
                
                onion_1st_ratio = (onion_1st / total_unique_onions * 100)
                onion_2nd_ratio = (onion_2nd / total_unique_onions * 100)
                onion_3rd_ratio = (onion_3rd / total_unique_onions * 100)

        computed_metrics.append({
            "Observation Date": observation_day,
            "Total Unique HSDirs": total_unique_hsdirs,
            "HSDir 1st tertile HRT Count": hsdir_1st,
            "HSDir 1st tertile HRT Ratio (%)": round(hsdir_1st_ratio, 2),
            "HSDir 2nd tertile HRT Count": hsdir_2nd,
            "HSDir 2nd tertile HRT Ratio (%)": round(hsdir_2nd_ratio, 2),
            "HSDir 3rd tertile HRT Count": hsdir_3rd,
            "HSDir 3rd tertile HRT Ratio (%)": round(hsdir_3rd_ratio, 2),
            "Total Unique Onions": total_unique_onions,
            "Onion 1st tertile HRT Count": onion_1st,
            "Onion 1st tertile HRT Ratio (%)": round(onion_1st_ratio, 2),
            "Onion 2nd tertile HRT Count": onion_2nd,
            "Onion 2nd tertile HRT Ratio (%)": round(onion_2nd_ratio, 2),
            "Onion 3rd tertile HRT Count": onion_3rd,
            "Onion 3rd tertile HRT Ratio (%)": round(onion_3rd_ratio, 2)
        })

    df_summary_matrix = pd.DataFrame(computed_metrics)
    if df_summary_matrix.empty:
        print(f"[HRT-INDEX-WARNING] No data metrics generated for context: {context_label}")
        return None
        
    # --- Daily Plotting (Color matched to compute_hrt_onion_to_hsdir) ---
    plt.figure(figsize=(14, 6))
    metric_cols_to_annotate = []
    
    if has_hsdir_idx and df_summary_matrix["Total Unique HSDirs"].sum() > 0:
        plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["HSDir 1st tertile HRT Count"], marker='o', color='green', linewidth=2, label='HSDir 1st Tertile (<=33.33%)')
        plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["HSDir 2nd tertile HRT Count"], marker='s', color='blue', linewidth=2, label='HSDir 2nd Tertile (33.33-66.66%)')
        plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["HSDir 3rd tertile HRT Count"], marker='d', color='red', linewidth=2, label='HSDir 3rd Tertile (>66.66%)')
        metric_cols_to_annotate.extend(["HSDir 1st tertile HRT Count", "HSDir 2nd tertile HRT Count", "HSDir 3rd tertile HRT Count"])
    
    if (has_onion_idx or has_rot_onion_idx) and df_summary_matrix["Total Unique Onions"].sum() > 0:
        plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Onion 1st tertile HRT Count"], marker='o', color='green', linewidth=2, linestyle='--', label='Onion 1st Tertile')
        plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Onion 2nd tertile HRT Count"], marker='s', color='blue', linewidth=2, linestyle='--', label='Onion 2nd Tertile')
        plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Onion 3rd tertile HRT Count"], marker='d', color='red', linewidth=2, linestyle='--', label='Onion 3rd Tertile')
        metric_cols_to_annotate.extend(["Onion 1st tertile HRT Count", "Onion 2nd tertile HRT Count", "Onion 3rd tertile HRT Count"])

    # Precise structural duplication of text annotations loop
    for metric_col in metric_cols_to_annotate:
        for x, y in zip(df_summary_matrix["Observation Date"], df_summary_matrix[metric_col]):
            plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=9)

    plt.title(f"Tor v3 HRT Index Tertile Distribution ({context_label.replace('_', ' ').title()} - Daily)")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Unique Identity Count")
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"analysis-results/hrt_index_distributions/{context_label}_hrt_index_daily_progression.png")
    plt.close()

    # --- Weekly Aggregation ---
    df_weekly_prep = df_summary_matrix.copy()
    df_weekly_prep["DayNum"] = df_weekly_prep["Observation Date"].apply(get_day_integer)
    df_weekly_prep["WeekIndex"] = df_weekly_prep["DayNum"].apply(lambda d: f"Week {((d - 1) // 7) + 1}")
    
    df_weekly_matrix = df_weekly_prep.groupby("WeekIndex").agg({
        "Total Unique HSDirs": "mean",
        "HSDir 1st tertile HRT Count": "mean",
        "HSDir 2nd tertile HRT Count": "mean",
        "HSDir 3rd tertile HRT Count": "mean",
        "Total Unique Onions": "mean",
        "Onion 1st tertile HRT Count": "mean",
        "Onion 2nd tertile HRT Count": "mean",
        "Onion 3rd tertile HRT Count": "mean"
    }).reset_index()
    
    # Recalculate ratios for weekly structures accurately
    df_weekly_matrix["HSDir 1st tertile HRT Ratio (%)"] = (df_weekly_matrix["HSDir 1st tertile HRT Count"] / df_weekly_matrix["Total Unique HSDirs"] * 100).round(2)
    df_weekly_matrix["HSDir 2nd tertile HRT Ratio (%)"] = (df_weekly_matrix["HSDir 2nd tertile HRT Count"] / df_weekly_matrix["Total Unique HSDirs"] * 100).round(2)
    df_weekly_matrix["HSDir 3rd tertile HRT Ratio (%)"] = (df_weekly_matrix["HSDir 3rd tertile HRT Count"] / df_weekly_matrix["Total Unique HSDirs"] * 100).round(2)
    
    df_weekly_matrix["Onion 1st tertile HRT Ratio (%)"] = (df_weekly_matrix["Onion 1st tertile HRT Count"] / df_weekly_matrix["Total Unique Onions"] * 100).round(2)
    df_weekly_matrix["Onion 2nd tertile HRT Ratio (%)"] = (df_weekly_matrix["Onion 2nd tertile HRT Count"] / df_weekly_matrix["Total Unique Onions"] * 100).round(2)
    df_weekly_matrix["Onion 3rd tertile HRT Ratio (%)"] = (df_weekly_matrix["Onion 3rd tertile HRT Count"] / df_weekly_matrix["Total Unique Onions"] * 100).round(2)
    
    for col in ["Total Unique HSDirs", "HSDir 1st tertile HRT Count", "HSDir 2nd tertile HRT Count", "HSDir 3rd tertile HRT Count",
                "Total Unique Onions", "Onion 1st tertile HRT Count", "Onion 2nd tertile HRT Count", "Onion 3rd tertile HRT Count"]:
        df_weekly_matrix[col] = df_weekly_matrix[col].round(2)
        
    df_weekly_matrix.rename(columns={"WeekIndex": "Observation Week"}, inplace=True)

    if not df_weekly_matrix.empty:
        plt.figure(figsize=(10, 6))
        weekly_annotate_cols = []
        
        if has_hsdir_idx and df_weekly_matrix["Total Unique HSDirs"].sum() > 0:
            plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["HSDir 1st tertile HRT Count"], marker='o', color='green', linewidth=2, label='Weekly Avg HSDir 1st Tertile')
            plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["HSDir 2nd tertile HRT Count"], marker='s', color='blue', linewidth=2, label='Weekly Avg HSDir 2nd Tertile')
            plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["HSDir 3rd tertile HRT Count"], marker='d', color='red', linewidth=2, label='Weekly Avg HSDir 3rd Tertile')
            weekly_annotate_cols.extend(["HSDir 1st tertile HRT Count", "HSDir 2nd tertile HRT Count", "HSDir 3rd tertile HRT Count"])
            
        if (has_onion_idx or has_rot_onion_idx) and df_weekly_matrix["Total Unique Onions"].sum() > 0:
            plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["Onion 1st tertile HRT Count"], marker='o', color='green', linewidth=2, linestyle='--', label='Weekly Avg Onion 1st Tertile')
            plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["Onion 2nd tertile HRT Count"], marker='s', color='blue', linewidth=2, linestyle='--', label='Weekly Avg Onion 2nd Tertile')
            plt.plot(df_weekly_matrix["Observation Week"], df_weekly_matrix["Onion 3rd tertile HRT Count"], marker='d', color='red', linewidth=2, linestyle='--', label='Weekly Avg Onion 3rd Tertile')
            weekly_annotate_cols.extend(["Onion 1st tertile HRT Count", "Onion 2nd tertile HRT Count", "Onion 3rd tertile HRT Count"])
            
        for metric_col in weekly_annotate_cols:
            for x, y in zip(df_weekly_matrix["Observation Week"], df_weekly_matrix[metric_col]):
                plt.annotate(f"{y}", (x, y), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=9)
        
        plt.title(f"Tor v3 Weekly Averaged HRT Index Distribution ({context_label.replace('_', ' ').title()})")
        plt.xlabel("Observation Timeline (Weeks)")
        plt.ylabel("Mean Identity Footprint Volume")
        plt.legend(loc="upper right")
        plt.tight_layout()
        plt.savefig(f"analysis-results/hrt_index_distributions/{context_label}_hrt_index_weekly_progression.png")
        plt.close()
        
        # Structure overall average summary row matching compute_hrt_onion_to_hsdir exactly
        weekly_totals = {
            "Observation Week": "Overall Weekly Average",
            "Total Unique HSDirs": round(df_weekly_matrix["Total Unique HSDirs"].mean(), 2),
            "HSDir 1st tertile HRT Count": round(df_weekly_matrix["HSDir 1st tertile HRT Count"].mean(), 2),
            "HSDir 1st tertile HRT Ratio (%)": round(df_weekly_matrix["HSDir 1st tertile HRT Ratio (%)"].mean(), 2),
            "HSDir 2nd tertile HRT Count": round(df_weekly_matrix["HSDir 2nd tertile HRT Count"].mean(), 2),
            "HSDir 2nd tertile HRT Ratio (%)": round(df_weekly_matrix["HSDir 2nd tertile HRT Ratio (%)"].mean(), 2),
            "HSDir 3rd tertile HRT Count": round(df_weekly_matrix["HSDir 3rd tertile HRT Count"].mean(), 2),
            "HSDir 3rd tertile HRT Ratio (%)": round(df_weekly_matrix["HSDir 3rd tertile HRT Ratio (%)"].mean(), 2),
            "Total Unique Onions": round(df_weekly_matrix["Total Unique Onions"].mean(), 2),
            "Onion 1st tertile HRT Count": round(df_weekly_matrix["Onion 1st tertile HRT Count"].mean(), 2),
            "Onion 1st tertile HRT Ratio (%)": round(df_weekly_matrix["Onion 1st tertile HRT Ratio (%)"].mean(), 2),
            "Onion 2nd tertile HRT Count": round(df_weekly_matrix["Onion 2nd tertile HRT Count"].mean(), 2),
            "Onion 2nd tertile HRT Ratio (%)": round(df_weekly_matrix["Onion 2nd tertile HRT Ratio (%)"].mean(), 2),
            "Onion 3rd tertile HRT Count": round(df_weekly_matrix["Onion 3rd tertile HRT Count"].mean(), 2),
            "Onion 3rd tertile HRT Ratio (%)": round(df_weekly_matrix["Onion 3rd tertile HRT Ratio (%)"].mean(), 2)
        }
        df_weekly_matrix_export = pd.concat([df_weekly_matrix, pd.DataFrame([weekly_totals])], ignore_index=True)
        df_weekly_matrix_export.to_csv(f"analysis-results/hrt_index_distributions/{context_label}_hrt_index_weekly_matrix.csv", index=False)

    daily_totals = {
        "Observation Date": "Overall Average",
        "Total Unique HSDirs": round(df_summary_matrix["Total Unique HSDirs"].mean(), 2),
        "HSDir 1st tertile HRT Count": round(df_summary_matrix["HSDir 1st tertile HRT Count"].mean(), 2),
        "HSDir 1st tertile HRT Ratio (%)": round(df_summary_matrix["HSDir 1st tertile HRT Ratio (%)"].mean(), 2),
        "HSDir 2nd tertile HRT Count": round(df_summary_matrix["HSDir 2nd tertile HRT Count"].mean(), 2),
        "HSDir 2nd tertile HRT Ratio (%)": round(df_summary_matrix["HSDir 2nd tertile HRT Ratio (%)"].mean(), 2),
        "HSDir 3rd tertile HRT Count": round(df_summary_matrix["HSDir 3rd tertile HRT Count"].mean(), 2),
        "HSDir 3rd tertile HRT Ratio (%)": round(df_summary_matrix["HSDir 3rd tertile HRT Ratio (%)"].mean(), 2),
        "Total Unique Onions": round(df_summary_matrix["Total Unique Onions"].mean(), 2),
        "Onion 1st tertile HRT Count": round(df_summary_matrix["Onion 1st tertile HRT Count"].mean(), 2),
        "Onion 1st tertile HRT Ratio (%)": round(df_summary_matrix["Onion 1st tertile HRT Ratio (%)"].mean(), 2),
        "Onion 2nd tertile HRT Count": round(df_summary_matrix["Onion 2nd tertile HRT Count"].mean(), 2),
        "Onion 2nd tertile HRT Ratio (%)": round(df_summary_matrix["Onion 2nd tertile HRT Ratio (%)"].mean(), 2),
        "Onion 3rd tertile HRT Count": round(df_summary_matrix["Onion 3rd tertile HRT Count"].mean(), 2),
        "Onion 3rd tertile HRT Ratio (%)": round(df_summary_matrix["Onion 3rd tertile HRT Ratio (%)"].mean(), 2)
    }
    df_summary_matrix_export = pd.concat([df_summary_matrix, pd.DataFrame([daily_totals])], ignore_index=True)
    df_summary_matrix_export.to_csv(f"analysis-results/hrt_index_distributions/{context_label}_hrt_index_daily_matrix.csv", index=False)
    
    print(f"[HRT-INDEX-INFO] Metric matrices saved successfully for context: '{context_label}'")
    return df_summary_matrix

def compute_onion_to_hsdir_uniformity(df_slice, context_label):
    """
    Computes distance uniformity metrics for onion services and their assigned HSDirs,
    correlating ring distance dispersion with refined churn & stability metrics.
    """
    os.makedirs("analysis-results/onion_uniformity", exist_ok=True)

    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    if df_slice is None or df_slice.empty:
        print(f"[UNIFORMITY-WARNING] Empty snapshot slice received for context: {context_label}")
        return None

    # Identify onion column
    onion_col = None
    for candidate in ["mapped_onion", "last_known_onion", "onion_address"]:
        if candidate in df_slice.columns:
            onion_col = candidate
            break

    dist_col = "hsdir_to_onion_ring_distance"
    pos_col = "hsdir_to_onion_ring_position"

    if not onion_col or "fingerprint" not in df_slice.columns:
        print(f"[UNIFORMITY-ERROR] Missing onion identifier or fingerprint in context: {context_label}")
        return None

    df_working = df_slice[
        (df_slice[onion_col].notna()) & (df_slice[onion_col] != 'None') &
        (df_slice['fingerprint'].notna()) & (df_slice['fingerprint'] != 'None')
    ].copy()

    # -------------------------------------------------------------
    # MODIFICATION 1: Omit ghost nodes (consecutive_hourly_absences > 1)
    # -------------------------------------------------------------
    if "consecutive_hourly_absences" in df_working.columns:
        df_working = df_working[
            df_working["consecutive_hourly_absences"].isna() | 
            (df_working["consecutive_hourly_absences"] <= 1)
        ]

    if df_working.empty:
        print(f"[UNIFORMITY-WARNING] No valid entries in context: {context_label}")
        return None

    # Standardize status column
    status_col = "status" if "status" in df_working.columns else ("state" if "state" in df_working.columns else None)
    df_working["clean_status"] = df_working[status_col].fillna("ACTIVE_IN_RING").astype(str) if status_col else "ACTIVE_IN_RING"

    # Hour numeric normalization for accurate chronological ordering
    if "hour" in df_working.columns:
        if df_working["hour"].dtype == object or isinstance(df_working["hour"].iloc[0], str):
            if df_working["hour"].str.contains(":").any():
                hour_parts = df_working["hour"].str.split(":", expand=True)
                df_working["hour_num"] = hour_parts[0].astype(int) + hour_parts[1].astype(int) / 60.0
            else:
                df_working["hour_num"] = pd.to_numeric(df_working["hour"], errors='coerce').fillna(0)
        else:
            df_working["hour_num"] = df_working["hour"].astype(float)
    else:
        df_working["hour_num"] = 0.0

    # Compute normalized ring distance in [0, 1]
    TWO_POW_256 = 2**256
    if dist_col in df_working.columns:
        def parse_dist(val):
            try:
                return float(val) / TWO_POW_256
            except (ValueError, TypeError):
                return np.nan
        df_working["norm_distance"] = df_working[dist_col].apply(parse_dist)
    elif pos_col in df_working.columns:
        df_working["norm_distance"] = pd.to_numeric(df_working[pos_col], errors='coerce') / 100.0
    else:
        print(f"[UNIFORMITY-ERROR] Neither distance nor position column found in {context_label}")
        return None

    df_working = df_working.dropna(subset=["norm_distance"])

    unique_days = [d for d in df_working["date"].unique() if d not in ['', 'None']]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    daily_uniformity_records = []

    for obs_day in unique_days_sorted:
        day_data = df_working[df_working["date"] == obs_day]
        unique_onions = day_data[onion_col].unique()

        for onion in unique_onions:
            onion_data = day_data[day_data[onion_col] == onion]
            distances = onion_data["norm_distance"].values

            if len(distances) == 0:
                continue

            mean_dist = np.mean(distances)
            std_dist = np.std(distances) if len(distances) > 1 else 0.0
            min_dist = np.min(distances)
            max_dist = np.max(distances)
            dist_range = max_dist - min_dist

            # KS-test against Uniform distribution U(0,1)
            ks_stat, _ = kstest(distances, 'uniform') if len(distances) >= 3 else (np.nan, np.nan)
            uniformity_score = 1.0 - ks_stat if not np.isnan(ks_stat) else np.nan

            # -------------------------------------------------------------
            # MODIFICATION 2 & 3: Refined Hourly Churn Logic
            # -------------------------------------------------------------
            hours_sorted = sorted(onion_data["hour_num"].unique())
            
            seen_active_fps_today = set()
            tot_new = 0
            tot_reconnect = 0
            tot_disappeared = 0

            prev_fp_status = {}  # {fingerprint: clean_status}

            for idx, hr in enumerate(hours_sorted):
                hr_slice = onion_data[onion_data["hour_num"] == hr]
                curr_fp_status = dict(zip(hr_slice["fingerprint"], hr_slice["clean_status"]))
                
                # Active nodes in current snapshot
                curr_active_fps = {fp for fp, st in curr_fp_status.items() if st in ["ACTIVE_IN_RING", "None"]}

                if idx == 0:
                    # First hour of observation: initial set of active nodes added to cumulative seen set
                    seen_active_fps_today.update(curr_active_fps)
                    tot_new += len(curr_active_fps)
                else:
                    # 1. Evaluate Arrivals (New vs Reconnections)
                    for fp in curr_active_fps:
                        was_active_prev = (fp in prev_fp_status) and (prev_fp_status[fp] in ["ACTIVE_IN_RING", "None"])
                        if not was_active_prev:
                            if fp not in seen_active_fps_today:
                                # First time seen active today -> Truly NEW
                                tot_new += 1
                                seen_active_fps_today.add(fp)
                            else:
                                # Seen active earlier today -> RECONNECTION
                                tot_reconnect += 1

                    # 2. Evaluate Disappearances based on state transition
                    for fp, prev_st in prev_fp_status.items():
                        if prev_st in ["ACTIVE_IN_RING", "None"]:
                            curr_st = curr_fp_status.get(fp, None)
                            # Was active, but now missing or non-active -> Count DISAPPEARANCE
                            if curr_st is None or curr_st not in ["ACTIVE_IN_RING", "None"]:
                                tot_disappeared += 1
                        # If prev_st was already non-active/absent, do NOT count again.

                prev_fp_status = curr_fp_status

            total_churn = tot_new + tot_reconnect + tot_disappeared

            daily_uniformity_records.append({
                "Observation Date": obs_day,
                "Onion Service": onion,
                "Sample Count": len(distances),
                "Mean Distance": round(float(mean_dist), 4),
                "Std Distance": round(float(std_dist), 4),
                "Min Distance": round(float(min_dist), 4),
                "Max Distance": round(float(max_dist), 4),
                "Distance Range": round(float(dist_range), 4),
                "Uniformity Score": round(float(uniformity_score), 4) if not np.isnan(uniformity_score) else np.nan,
                "New HSDirs": tot_new,
                "Reconnecting HSDirs": tot_reconnect,
                "Disappeared HSDirs": tot_disappeared,
                "Total Churn": total_churn
            })

    df_uniformity = pd.DataFrame(daily_uniformity_records)
    if df_uniformity.empty:
        print(f"[UNIFORMITY-ERROR] No uniformity records calculated for {context_label}")
        return None

    # Correlation Matrix calculation
    corr_cols = [
        "Mean Distance", "Std Distance", "Distance Range", 
        "Uniformity Score", "New HSDirs", "Reconnecting HSDirs", 
        "Disappeared HSDirs", "Total Churn"
    ]
    df_corr = df_uniformity[corr_cols].corr(method='pearson').round(4)

    # Save CSV Matrices
    df_uniformity.to_csv(f"analysis-results/onion_uniformity/{context_label}_onion_daily_uniformity_matrix.csv", index=False)
    df_corr.to_csv(f"analysis-results/onion_uniformity/{context_label}_onion_churn_uniformity_correlation_matrix.csv")

    # -------------------------------------------------------------
    # PLOTTING SPECIFICATIONS
    # -------------------------------------------------------------
    unique_onions = df_uniformity["Onion Service"].unique()

    # --- Plot 1: Daily Distance Mean & Standard Deviation (Dispersion) ---
    plt.figure(figsize=(15, 8))
    avg_colors = plt.cm.Dark2(np.linspace(0.0, 1.0, max(1, len(unique_onions))))
    warm_colors = plt.cm.YlOrRd(np.linspace(0.5, 0.9, max(1, len(unique_onions))))

    for idx, onion in enumerate(unique_onions):
        sub = df_uniformity[df_uniformity["Onion Service"] == onion]
        plt.plot(sub["Observation Date"], sub["Mean Distance"], linestyle='-', color=avg_colors[idx % len(avg_colors)], alpha=0.8, linewidth=1.5)
        plt.fill_between(
            sub["Observation Date"],
            np.maximum(0, sub["Mean Distance"] - sub["Std Distance"]),
            np.minimum(1, sub["Mean Distance"] + sub["Std Distance"]),
            color=warm_colors[idx % len(warm_colors)], alpha=0.15
        )

    legend_elements = [
        Line2D([0], [0], color='black', linestyle='-', label='Mean Relative Ring Distance'),
        Line2D([0], [0], color='orange', linestyle='--', label='±1 Std Dev Dispersion (Shaded)')
    ]
    plt.title(f"Tor v3 Daily HSDir Distance Uniformity & Dispersion per Onion Service\nSegment: {context_label.replace('_', ' ').title()}")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Normalized Ring Distance [0, 1]")
    plt.ylim(-0.05, 1.05)
    plt.xticks(rotation=45)
    plt.legend(handles=legend_elements, loc="upper right")
    plt.tight_layout()
    plt.savefig(f"analysis-results/onion_uniformity/{context_label}_onion_distance_uniformity.png")
    plt.close()

    # --- Plot 2: Total Churn vs. Distance Dispersion (Scatter & Trend) ---
    plt.figure(figsize=(12, 7))
    plt.scatter(df_uniformity["Total Churn"], df_uniformity["Std Distance"], color='#1f77b4', alpha=0.6, edgecolors='none', s=40)

    if len(df_uniformity) > 1 and df_uniformity["Total Churn"].nunique() > 1:
        z = np.polyfit(df_uniformity["Total Churn"], df_uniformity["Std Distance"].fillna(0), 1)
        p = np.poly1d(z)
        x_vals = np.linspace(df_uniformity["Total Churn"].min(), df_uniformity["Total Churn"].max(), 100)
        plt.plot(x_vals, p(x_vals), color='#d62728', linestyle='--', linewidth=2.0, label=f'Linear Trend (slope={z[0]:.4f})')

    plt.title(f"HSDir Daily Churn vs. Target Ring Distance Dispersion ($\sigma_d$)\nSegment: {context_label.replace('_', ' ').title()}")
    plt.xlabel("Daily Total Churn (New + Reconnected + Disappeared HSDirs)")
    plt.ylabel("Distance Standard Deviation ($\sigma_d$)")
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"analysis-results/onion_uniformity/{context_label}_onion_churn_vs_distance_dispersion.png")
    plt.close()

    # --- Plot 3: Cumulative Distribution Function (ECDF vs Ideal Uniform) ---
    plt.figure(figsize=(10, 6))
    all_distances = np.sort(df_working["norm_distance"].values)
    ecdf = np.arange(1, len(all_distances) + 1) / len(all_distances)

    plt.plot(all_distances, ecdf, color='#2ca02c', linewidth=2.0, label='Empirical Cumulative Dist (ECDF)')
    plt.plot([0, 1], [0, 1], color='gray', linestyle='--', linewidth=1.5, label='Ideal Uniform Dist U(0,1)')

    plt.title(f"Empirical CDF of HSDir-to-Onion Ring Distance vs. Uniformity\nSegment: {context_label.replace('_', ' ').title()}")
    plt.xlabel("Normalized Distance [0, 1]")
    plt.ylabel("Cumulative Probability")
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(f"analysis-results/onion_uniformity/{context_label}_onion_distance_ecdf.png")
    plt.close()

    print(f"[UNIFORMITY-INFO] Distance uniformity analysis saved for context: '{context_label}'")
    return df_uniformity

def compute_hsdir_index_uniformity(df_slice, context_label):
    """
    Computes hash ring index uniformity metrics for HSDir nodes across the Tor v3 ring,
    correlating ring index dispersion with refined churn & stability metrics.
    """
    output_dir = f"analysis-results/hsdir_index_uniformity/{context_label}"
    os.makedirs(output_dir, exist_ok=True)

    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    if df_slice is None or df_slice.empty:
        print(f"[UNIFORMITY-WARNING] Empty snapshot slice received for context: {context_label}")
        return None

    if "fingerprint" not in df_slice.columns:
        print(f"[UNIFORMITY-ERROR] Missing 'fingerprint' column in context: {context_label}")
        return None

    df_working = df_slice[
        (df_slice['fingerprint'].notna()) & (df_slice['fingerprint'] != 'None')
    ].copy()

    # Filter ghost nodes
    if "consecutive_hourly_absences" in df_working.columns:
        df_working = df_working[
            df_working["consecutive_hourly_absences"].isna() | 
            (df_working["consecutive_hourly_absences"] <= 1)
        ]

    if df_working.empty:
        print(f"[UNIFORMITY-WARNING] No valid entries in context: {context_label}")
        return None

    # Normalize status column
    status_col = "status" if "status" in df_working.columns else ("state" if "state" in df_working.columns else None)
    df_working["clean_status"] = df_working[status_col].fillna("ACTIVE_IN_RING").astype(str) if status_col else "ACTIVE_IN_RING"

    # Normalize hourly ordering
    if "hour" in df_working.columns:
        if df_working["hour"].dtype == object or isinstance(df_working["hour"].iloc[0], str):
            if df_working["hour"].str.contains(":").any():
                hour_parts = df_working["hour"].str.split(":", expand=True)
                df_working["hour_num"] = hour_parts[0].astype(int) + hour_parts[1].astype(int) / 60.0
            else:
                df_working["hour_num"] = pd.to_numeric(df_working["hour"], errors='coerce').fillna(0)
        else:
            df_working["hour_num"] = df_working["hour"].astype(float)
    else:
        df_working["hour_num"] = 0.0

    # Parse normalized ring index in range [0, 1]
    TWO_POW_256 = 2**256

    if "hsdir_index_hrt_hex" in df_working.columns:
        def parse_hex_index(val):
            try:
                if pd.isna(val) or val is None or str(val).strip() in ['None', 'nan', '']:
                    return np.nan
                val_str = str(val).strip()
                if val_str.startswith("0x") or val_str.startswith("0X"):
                    val_str = val_str[2:]
                return float(int(val_str, 16)) / TWO_POW_256
            except (ValueError, TypeError):
                return np.nan

        df_working["norm_index"] = df_working["hsdir_index_hrt_hex"].apply(parse_hex_index)
    elif "hsdir_index_hrt_100" in df_working.columns:
        df_working["norm_index"] = pd.to_numeric(df_working["hsdir_index_hrt_100"], errors='coerce') / 100.0
    else:
        print(f"[UNIFORMITY-ERROR] Neither 'hsdir_index_hrt_hex' nor 'hsdir_index_hrt_100' found in {context_label}")
        return None

    if df_working["norm_index"].dropna().empty and "hsdir_index_hrt_100" in df_working.columns:
        df_working["norm_index"] = pd.to_numeric(df_working["hsdir_index_hrt_100"], errors='coerce') / 100.0

    df_working = df_working.dropna(subset=["norm_index"])

    if df_working.empty:
        print(f"[UNIFORMITY-WARNING] All normalized index values are invalid/NaN in context: {context_label}")
        return None

    unique_days = [d for d in df_working["date"].unique() if d not in ['', 'None']]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    # ==============================================================================
    # OPTION A: GLOBAL SPATIAL UNIFORMITY ANALYSIS & CHURN CORRELATION
    # ==============================================================================
    daily_uniformity_records = []

    for obs_day in unique_days_sorted:
        day_data = df_working[df_working["date"] == obs_day]
        unique_nodes_day = day_data.drop_duplicates(subset=["fingerprint"])
        indices = unique_nodes_day["norm_index"].values

        if len(indices) == 0:
            continue

        mean_idx = np.mean(indices)
        std_idx = np.std(indices) if len(indices) > 1 else 0.0
        min_idx = np.min(indices)
        max_idx = np.max(indices)
        idx_range = max_idx - min_idx

        # One-sample KS test against Uniform distribution U(0,1)
        ks_stat, _ = kstest(indices, 'uniform') if len(indices) >= 3 else (np.nan, np.nan)
        uniformity_score = 1.0 - ks_stat if not np.isnan(ks_stat) else np.nan

        # Hourly Churn Calculation
        hours_sorted = sorted(day_data["hour_num"].unique())
        seen_active_fps_today = set()
        tot_new = 0
        tot_disappeared = 0
        prev_fp_status = {}

        for idx, hr in enumerate(hours_sorted):
            hr_slice = day_data[day_data["hour_num"] == hr]
            curr_fp_status = dict(zip(hr_slice["fingerprint"], hr_slice["clean_status"]))
            curr_active_fps = {fp for fp, st in curr_fp_status.items() if st in ["ACTIVE_IN_RING", "None"]}

            if idx == 0:
                seen_active_fps_today.update(curr_active_fps)
                tot_new += len(curr_active_fps)
            else:
                for fp in curr_active_fps:
                    was_active_prev = (fp in prev_fp_status) and (prev_fp_status[fp] in ["ACTIVE_IN_RING", "None"])
                    if not was_active_prev and fp not in seen_active_fps_today:
                        tot_new += 1
                        seen_active_fps_today.add(fp)

                for fp, prev_st in prev_fp_status.items():
                    if prev_st in ["ACTIVE_IN_RING", "None"]:
                        curr_st = curr_fp_status.get(fp, None)
                        if curr_st is None or curr_st not in ["ACTIVE_IN_RING", "None"]:
                            tot_disappeared += 1

            prev_fp_status = curr_fp_status

        total_churn = tot_new + tot_disappeared

        daily_uniformity_records.append({
            "Observation Date": obs_day,
            "Unique HSDir Count": len(indices),
            "Mean Ring Index": round(float(mean_idx), 4),
            "Std Ring Index": round(float(std_idx), 4),
            "Min Ring Index": round(float(min_idx), 4),
            "Max Ring Index": round(float(max_idx), 4),
            "Ring Index Range": round(float(idx_range), 4),
            "Uniformity Score": round(float(uniformity_score), 4) if not np.isnan(uniformity_score) else np.nan,
            "New HSDirs": tot_new,
            "Disappeared HSDirs": tot_disappeared,
            "Total Churn": total_churn
        })

    df_uniformity = pd.DataFrame(daily_uniformity_records)

    # Export Option A Metrics & Pearson Correlation
    corr_cols = ["Mean Ring Index", "Std Ring Index", "Ring Index Range", "Uniformity Score", "New HSDirs", "Disappeared HSDirs", "Total Churn"]
    df_corr = df_uniformity[corr_cols].corr(method='pearson').round(4)
    df_uniformity.to_csv(f"{output_dir}/option_a_daily_index_uniformity_matrix.csv", index=False)
    df_corr.to_csv(f"{output_dir}/option_a_churn_uniformity_correlation_matrix.csv")

    # Option A Plots
    # Plot A1: Daily Mean & Std Dev
    plt.figure(figsize=(14, 7))
    plt.plot(df_uniformity["Observation Date"], df_uniformity["Mean Ring Index"], linestyle='-', color='#1f77b4', marker='o', linewidth=2.0, label='Mean Ring Index')
    plt.fill_between(
        df_uniformity["Observation Date"],
        np.maximum(0, df_uniformity["Mean Ring Index"] - df_uniformity["Std Ring Index"]),
        np.minimum(1, df_uniformity["Mean Ring Index"] + df_uniformity["Std Ring Index"]),
        color='#ff7f0e', alpha=0.25, label='±1 Std Dev Dispersion'
    )
    plt.title(f"Option A: Daily HSDir Ring Index Mean & Dispersion\nSegment: {context_label}")
    plt.xlabel("Observation Date")
    plt.ylabel("Normalized Ring Index [0, 1]")
    plt.ylim(-0.05, 1.05)
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/option_a_index_uniformity_trend.png")
    plt.close()

    # Plot A2: Churn vs Dispersion Scatter
    plt.figure(figsize=(10, 6))
    plt.scatter(df_uniformity["Total Churn"], df_uniformity["Std Ring Index"], color='#1f77b4', alpha=0.7, s=60)
    if len(df_uniformity) > 1 and df_uniformity["Total Churn"].nunique() > 1:
        z = np.polyfit(df_uniformity["Total Churn"], df_uniformity["Std Ring Index"].fillna(0), 1)
        p = np.poly1d(z)
        x_vals = np.linspace(df_uniformity["Total Churn"].min(), df_uniformity["Total Churn"].max(), 100)
        plt.plot(x_vals, p(x_vals), color='#d62728', linestyle='--', linewidth=2.0, label=f'Linear Trend (slope={z[0]:.4f})')
    plt.title(f"Option A: Daily Churn vs. Spatial Dispersion ($\sigma_i$)\nSegment: {context_label}")
    plt.xlabel("Total Daily Churn")
    plt.ylabel("Ring Index Std Dev ($\sigma_i$)")
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/option_a_churn_vs_dispersion.png")
    plt.close()

    # Plot A3: Global ECDF vs Ideal Uniform
    plt.figure(figsize=(9, 6))
    global_unique = df_working.drop_duplicates(subset=["fingerprint"])
    all_indices = np.sort(global_unique["norm_index"].values)
    if len(all_indices) > 0:
        ecdf = np.arange(1, len(all_indices) + 1) / len(all_indices)
        plt.plot(all_indices, ecdf, color='#2ca02c', linewidth=2.0, label='Global Empirical CDF')
        plt.plot([0, 1], [0, 1], color='gray', linestyle='--', label='Ideal Uniform U(0,1)')
        plt.title(f"Option A: Global Empirical CDF vs. Ideal Uniformity\nSegment: {context_label}")
        plt.xlabel("Normalized Ring Index [0, 1]")
        plt.ylabel("Cumulative Probability")
        plt.legend(loc="lower right")
        plt.tight_layout()
        plt.savefig(f"{output_dir}/option_a_global_ecdf.png")
    plt.close()


    # ==============================================================================
    # OPTION B: TERTILE DENSITY & CHURN OVERLAY ANALYSIS
    # ==============================================================================
    tertile_records = []

    for obs_day in unique_days_sorted:
        day_data = df_working[df_working["date"] == obs_day]
        unique_nodes_day = day_data.drop_duplicates(subset=["fingerprint"])
        
        # Categorize nodes into three equal key-space tertiles
        t1_mask = (unique_nodes_day["norm_index"] >= 0.0) & (unique_nodes_day["norm_index"] <= (1.0 / 3.0))
        t2_mask = (unique_nodes_day["norm_index"] > (1.0 / 3.0)) & (unique_nodes_day["norm_index"] <= (2.0 / 3.0))
        t3_mask = (unique_nodes_day["norm_index"] > (2.0 / 3.0)) & (unique_nodes_day["norm_index"] <= 1.0)

        t1_count = int(t1_mask.sum())
        t2_count = int(t2_mask.sum())
        t3_count = int(t3_mask.sum())
        total_day_nodes = len(unique_nodes_day)

        tertile_records.append({
            "Observation Date": obs_day,
            "Tertile 1 Count [0.0 - 0.33]": t1_count,
            "Tertile 2 Count [0.33 - 0.67]": t2_count,
            "Tertile 3 Count [0.67 - 1.00]": t3_count,
            "Tertile 1 Share": round(t1_count / total_day_nodes, 4) if total_day_nodes > 0 else 0,
            "Tertile 2 Share": round(t2_count / total_day_nodes, 4) if total_day_nodes > 0 else 0,
            "Tertile 3 Share": round(t3_count / total_day_nodes, 4) if total_day_nodes > 0 else 0,
        })

    df_tertiles = pd.DataFrame(tertile_records)
    df_tertiles.to_csv(f"{output_dir}/option_b_tertile_density_matrix.csv", index=False)

    # Plot B1: Stacked Area Chart for Tertile Node Density
    plt.figure(figsize=(14, 7))
    plt.stackplot(
        df_tertiles["Observation Date"],
        df_tertiles["Tertile 1 Count [0.0 - 0.33]"],
        df_tertiles["Tertile 2 Count [0.33 - 0.67]"],
        df_tertiles["Tertile 3 Count [0.67 - 1.00]"],
        labels=['Tertile 1 [0.0 - 0.333]', 'Tertile 2 [0.333 - 0.667]', 'Tertile 3 [0.667 - 1.000]'],
        colors=['#1f77b4', '#ff7f0e', '#2ca02c'],
        alpha=0.85
    )
    plt.title(f"Option B: HSDir Hash Ring Tertile Density Distribution\nSegment: {context_label}")
    plt.xlabel("Observation Date")
    plt.ylabel("HSDir Node Count")
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/option_b_tertile_density_stacked.png")
    plt.close()

    # Plot B2: Relative Shares per Tertile over Time
    plt.figure(figsize=(14, 6))
    plt.plot(df_tertiles["Observation Date"], df_tertiles["Tertile 1 Share"], label='Tertile 1 Share', color='#1f77b4', marker='o')
    plt.plot(df_tertiles["Observation Date"], df_tertiles["Tertile 2 Share"], label='Tertile 2 Share', color='#ff7f0e', marker='s')
    plt.plot(df_tertiles["Observation Date"], df_tertiles["Tertile 3 Share"], label='Tertile 3 Share', color='#2ca02c', marker='^')
    plt.axhline(1.0 / 3.0, color='gray', linestyle='--', label='Balanced Share (33.3%)')
    plt.title(f"Option B: Relative Key-Space Share per Tertile\nSegment: {context_label}")
    plt.xlabel("Observation Date")
    plt.ylabel("Proportion of Total Nodes")
    plt.ylim(0, 0.6)
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/option_b_tertile_shares.png")
    plt.close()


    # ==============================================================================
    # OPTION C: STABLE VS. HIGH-CHURN (TRANSIENT) ECDF COMPARISON ANALYSIS
    # ==============================================================================
    # Classify nodes based on total snapshot appearances across dataset
    node_appearances = df_working.groupby("fingerprint").size()
    median_appearances = node_appearances.median()

    stable_fps = node_appearances[node_appearances >= median_appearances].index
    transient_fps = node_appearances[node_appearances < median_appearances].index

    df_stable = df_working[df_working["fingerprint"].isin(stable_fps)].drop_duplicates(subset=["fingerprint"])
    df_transient = df_working[df_working["fingerprint"].isin(transient_fps)].drop_duplicates(subset=["fingerprint"])

    stable_indices = np.sort(df_stable["norm_index"].values)
    transient_indices = np.sort(df_transient["norm_index"].values)

    # Perform Two-Sample KS Test between Stable and High-Churn node sub-populations
    if len(stable_indices) > 0 and len(transient_indices) > 0:
        ks_stat_2samp, p_val_2samp = ks_2samp(stable_indices, transient_indices)
    else:
        ks_stat_2samp, p_val_2samp = np.nan, np.nan

    # Export Option C Summary
    df_option_c_summary = pd.DataFrame([{
        "Stable Node Count": len(stable_indices),
        "Transient Node Count": len(transient_indices),
        "Appearance Threshold (Median)": median_appearances,
        "Two-Sample KS Statistic": round(float(ks_stat_2samp), 4) if not np.isnan(ks_stat_2samp) else np.nan,
        "p-value": round(float(p_val_2samp), 6) if not np.isnan(p_val_2samp) else np.nan
    }])
    df_option_c_summary.to_csv(f"{output_dir}/option_c_stable_vs_transient_ks_summary.csv", index=False)

    # Plot C1: Comparative Dual-ECDF (Stable vs. High-Churn vs. Ideal Uniform)
    plt.figure(figsize=(10, 6))
    if len(stable_indices) > 0:
        ecdf_stable = np.arange(1, len(stable_indices) + 1) / len(stable_indices)
        plt.plot(stable_indices, ecdf_stable, color='#1f77b4', linewidth=2.0, label=f'Stable HSDirs (n={len(stable_indices)})')

    if len(transient_indices) > 0:
        ecdf_transient = np.arange(1, len(transient_indices) + 1) / len(transient_indices)
        plt.plot(transient_indices, ecdf_transient, color='#d62728', linestyle='-.', linewidth=2.0, label=f'Transient/High-Churn HSDirs (n={len(transient_indices)})')

    plt.plot([0, 1], [0, 1], color='gray', linestyle='--', linewidth=1.5, label='Ideal Uniform U(0,1)')
    
    plt.title(f"Option C: Dual-ECDF Comparison (Stable vs. High-Churn HSDirs)\nSegment: {context_label} | KS Stat={ks_stat_2samp:.4f} (p={p_val_2samp:.4f})")
    plt.xlabel("Normalized Ring Index [0, 1]")
    plt.ylabel("Cumulative Probability")
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/option_c_dual_ecdf_comparison.png")
    plt.close()

    print(f"[UNIFORMITY-INFO] Options A, B, and C completed successfully for context: '{context_label}'")
    return df_uniformity

def compute_hsdir_index_uniformity(df_slice, context_label):
    """
    Computes hash ring index uniformity metrics for HSDir nodes across the Tor v3 ring,
    correlating ring index dispersion with refined churn & stability metrics.
    """
    output_dir = f"analysis-results/hsdir_index_uniformity/{context_label}"
    os.makedirs(output_dir, exist_ok=True)

    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    if df_slice is None or df_slice.empty:
        print(f"[UNIFORMITY-WARNING] Empty snapshot slice received for context: {context_label}")
        return None

    if "fingerprint" not in df_slice.columns:
        print(f"[UNIFORMITY-ERROR] Missing 'fingerprint' column in context: {context_label}")
        return None

    df_working = df_slice[
        (df_slice['fingerprint'].notna()) & (df_slice['fingerprint'] != 'None')
    ].copy()

    # Filter ghost nodes
    if "consecutive_hourly_absences" in df_working.columns:
        df_working = df_working[
            df_working["consecutive_hourly_absences"].isna() | 
            (df_working["consecutive_hourly_absences"] <= 1)
        ]

    if df_working.empty:
        print(f"[UNIFORMITY-WARNING] No valid entries in context: {context_label}")
        return None

    # Normalize status column
    status_col = "status" if "status" in df_working.columns else ("state" if "state" in df_working.columns else None)
    df_working["clean_status"] = df_working[status_col].fillna("ACTIVE_IN_RING").astype(str) if status_col else "ACTIVE_IN_RING"

    # Normalize hourly ordering
    if "hour" in df_working.columns:
        if df_working["hour"].dtype == object or isinstance(df_working["hour"].iloc[0], str):
            if df_working["hour"].str.contains(":").any():
                hour_parts = df_working["hour"].str.split(":", expand=True)
                df_working["hour_num"] = hour_parts[0].astype(int) + hour_parts[1].astype(int) / 60.0
            else:
                df_working["hour_num"] = pd.to_numeric(df_working["hour"], errors='coerce').fillna(0)
        else:
            df_working["hour_num"] = df_working["hour"].astype(float)
    else:
        df_working["hour_num"] = 0.0

    # Parse normalized ring index in range [0, 1]
    TWO_POW_256 = 2**256

    if "hsdir_index_hrt_hex" in df_working.columns:
        def parse_hex_index(val):
            try:
                if pd.isna(val) or val is None or str(val).strip() in ['None', 'nan', '']:
                    return np.nan
                val_str = str(val).strip()
                if val_str.startswith("0x") or val_str.startswith("0X"):
                    val_str = val_str[2:]
                return float(int(val_str, 16)) / TWO_POW_256
            except (ValueError, TypeError):
                return np.nan

        df_working["norm_index"] = df_working["hsdir_index_hrt_hex"].apply(parse_hex_index)
    elif "hsdir_index_hrt_100" in df_working.columns:
        df_working["norm_index"] = pd.to_numeric(df_working["hsdir_index_hrt_100"], errors='coerce') / 100.0
    else:
        print(f"[UNIFORMITY-ERROR] Neither 'hsdir_index_hrt_hex' nor 'hsdir_index_hrt_100' found in {context_label}")
        return None

    if df_working["norm_index"].dropna().empty and "hsdir_index_hrt_100" in df_working.columns:
        df_working["norm_index"] = pd.to_numeric(df_working["hsdir_index_hrt_100"], errors='coerce') / 100.0

    df_working = df_working.dropna(subset=["norm_index"])

    if df_working.empty:
        print(f"[UNIFORMITY-WARNING] All normalized index values are invalid/NaN in context: {context_label}")
        return None

    unique_days = [d for d in df_working["date"].unique() if d not in ['', 'None']]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    # ==============================================================================
    # OPTION A: GLOBAL SPATIAL UNIFORMITY ANALYSIS & CHURN CORRELATION
    # ==============================================================================
    daily_uniformity_records = []

    for obs_day in unique_days_sorted:
        day_data = df_working[df_working["date"] == obs_day]

        # Deduplicate HSDir nodes for spatial distribution calculation per day
        unique_nodes_day = day_data.drop_duplicates(subset=["fingerprint"])
        indices = unique_nodes_day["norm_index"].values

        if len(indices) == 0:
            continue

        mean_idx = np.mean(indices)
        std_idx = np.std(indices) if len(indices) > 1 else 0.0
        min_idx = np.min(indices)
        max_idx = np.max(indices)
        idx_range = max_idx - min_idx

        # KS-test against Uniform distribution U(0,1)
        ks_stat, _ = kstest(indices, 'uniform') if len(indices) >= 3 else (np.nan, np.nan)
        uniformity_score = 1.0 - ks_stat if not np.isnan(ks_stat) else np.nan

        # Hourly Churn Evaluation across the daily timeline
        hours_sorted = sorted(day_data["hour_num"].unique())
        
        seen_active_fps_today = set()
        tot_new = 0
        tot_disappeared = 0
        prev_fp_status = {}  # {fingerprint: clean_status}

        for idx, hr in enumerate(hours_sorted):
            hr_slice = day_data[day_data["hour_num"] == hr]
            curr_fp_status = dict(zip(hr_slice["fingerprint"], hr_slice["clean_status"]))
            
            # Active nodes in current snapshot
            curr_active_fps = {fp for fp, st in curr_fp_status.items() if st in ["ACTIVE_IN_RING", "None"]}

            if idx == 0:
                seen_active_fps_today.update(curr_active_fps)
                tot_new += len(curr_active_fps)
            else:
                # 1. Evaluate Truly New Arrivals
                for fp in curr_active_fps:
                    was_active_prev = (fp in prev_fp_status) and (prev_fp_status[fp] in ["ACTIVE_IN_RING", "None"])
                    if not was_active_prev:
                        if fp not in seen_active_fps_today:
                            tot_new += 1
                            seen_active_fps_today.add(fp)

                # 2. Evaluate Disappearances
                for fp, prev_st in prev_fp_status.items():
                    if prev_st in ["ACTIVE_IN_RING", "None"]:
                        curr_st = curr_fp_status.get(fp, None)
                        if curr_st is None or curr_st not in ["ACTIVE_IN_RING", "None"]:
                            tot_disappeared += 1

            prev_fp_status = curr_fp_status

        total_churn = tot_new + tot_disappeared

        daily_uniformity_records.append({
            "Observation Date": obs_day,
            "Unique HSDir Count": len(indices),
            "Mean Ring Index": round(float(mean_idx), 4),
            "Std Ring Index": round(float(std_idx), 4),
            "Min Ring Index": round(float(min_idx), 4),
            "Max Ring Index": round(float(max_idx), 4),
            "Ring Index Range": round(float(idx_range), 4),
            "Uniformity Score": round(float(uniformity_score), 4) if not np.isnan(uniformity_score) else np.nan,
            "New HSDirs": tot_new,
            "Disappeared HSDirs": tot_disappeared,
            "Total Churn": total_churn
        })

    df_uniformity = pd.DataFrame(daily_uniformity_records)
    if df_uniformity.empty:
        print(f"[UNIFORMITY-ERROR] No uniformity records calculated for {context_label}")
        return None

    # Pearson Correlation Matrix Calculation
    corr_cols = [
        "Mean Ring Index", "Std Ring Index", "Ring Index Range", 
        "Uniformity Score", "New HSDirs", "Disappeared HSDirs", "Total Churn"
    ]
    df_corr = df_uniformity[corr_cols].corr(method='pearson').round(4)

    # Save CSV Data Exports
    df_uniformity.to_csv(f"{output_dir}/{context_label}_hsdir_daily_index_uniformity_matrix.csv", index=False)
    df_corr.to_csv(f"{output_dir}/{context_label}_hsdir_churn_index_uniformity_correlation_matrix.csv")

    # -------------------------------------------------------------
    # PLOTTING SPECIFICATIONS
    # -------------------------------------------------------------

    # --- Plot 1: Daily HSDir Ring Index Mean & Standard Deviation (Dispersion) ---
    plt.figure(figsize=(15, 8))
    plt.plot(df_uniformity["Observation Date"], df_uniformity["Mean Ring Index"], linestyle='-', color='#1f77b4', marker='o', linewidth=2.0, label='Mean HSDir Ring Index Position')
    plt.fill_between(
        df_uniformity["Observation Date"],
        np.maximum(0, df_uniformity["Mean Ring Index"] - df_uniformity["Std Ring Index"]),
        np.minimum(1, df_uniformity["Mean Ring Index"] + df_uniformity["Std Ring Index"]),
        color='#ff7f0e', alpha=0.25, label='±1 Std Dev Ring Index Dispersion'
    )

    for x, y in zip(df_uniformity["Observation Date"], df_uniformity["Mean Ring Index"]):
        plt.annotate(f"{y:.2f}", (x, y), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=8)

    plt.title(f"Tor v3 Daily HSDir Ring Index Uniformity & Spatial Dispersion\nSegment: {context_label.replace('_', ' ').title()}")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Normalized Ring Index Position [0, 1]")
    plt.ylim(-0.05, 1.05)
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_hsdir_index_uniformity.png")
    plt.close()

    # --- Plot 2: Total Churn vs. Index Dispersion (Scatter & Linear Trend) ---
    plt.figure(figsize=(12, 7))
    plt.scatter(df_uniformity["Total Churn"], df_uniformity["Std Ring Index"], color='#1f77b4', alpha=0.7, edgecolors='none', s=50)

    if len(df_uniformity) > 1 and df_uniformity["Total Churn"].nunique() > 1:
        z = np.polyfit(df_uniformity["Total Churn"], df_uniformity["Std Ring Index"].fillna(0), 1)
        p = np.poly1d(z)
        x_vals = np.linspace(df_uniformity["Total Churn"].min(), df_uniformity["Total Churn"].max(), 100)
        plt.plot(x_vals, p(x_vals), color='#d62728', linestyle='--', linewidth=2.0, label=f'Linear Trend (slope={z[0]:.4f})')

    plt.title(f"HSDir Daily Churn vs. Hash Ring Index Spatial Dispersion ($\sigma_i$)\nSegment: {context_label.replace('_', ' ').title()}")
    plt.xlabel("Daily Total Churn (New + Disappeared HSDirs)")
    plt.ylabel("Ring Index Standard Deviation ($\sigma_i$)")
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_hsdir_churn_vs_index_dispersion.png")
    plt.close()

    # --- Plot 3: Cumulative Distribution Function (ECDF vs Ideal Uniform) ---
    plt.figure(figsize=(10, 6))
    unique_nodes_global = df_working.drop_duplicates(subset=["fingerprint"])
    all_indices = np.sort(unique_nodes_global["norm_index"].values)
    
    if len(all_indices) > 0:
        ecdf = np.arange(1, len(all_indices) + 1) / len(all_indices)

        plt.plot(all_indices, ecdf, color='#2ca02c', linewidth=2.0, label='Empirical Cumulative Dist (ECDF)')
        plt.plot([0, 1], [0, 1], color='gray', linestyle='--', linewidth=1.5, label='Ideal Uniform Dist U(0,1)')

        plt.title(f"Empirical CDF of HSDir Hash Ring Index Position vs. Ideal Uniformity\nSegment: {context_label.replace('_', ' ').title()}")
        plt.xlabel("Normalized Ring Index [0, 1]")
        plt.ylabel("Cumulative Probability")
        plt.xlim(0, 1)
        plt.ylim(0, 1)
        plt.legend(loc="lower right")
        plt.tight_layout()
        plt.savefig(f"{output_dir}/{context_label}_hsdir_index_ecdf.png")
    plt.close()

    # ==============================================================================
    # OPTION B: TERTILE DENSITY & CHURN OVERLAY ANALYSIS
    # ==============================================================================
    tertile_records = []

    for obs_day in unique_days_sorted:
        day_data = df_working[df_working["date"] == obs_day]
        unique_nodes_day = day_data.drop_duplicates(subset=["fingerprint"])
        
        # Categorize nodes into three equal key-space tertiles
        t1_mask = (unique_nodes_day["norm_index"] >= 0.0) & (unique_nodes_day["norm_index"] <= (1.0 / 3.0))
        t2_mask = (unique_nodes_day["norm_index"] > (1.0 / 3.0)) & (unique_nodes_day["norm_index"] <= (2.0 / 3.0))
        t3_mask = (unique_nodes_day["norm_index"] > (2.0 / 3.0)) & (unique_nodes_day["norm_index"] <= 1.0)

        t1_count = int(t1_mask.sum())
        t2_count = int(t2_mask.sum())
        t3_count = int(t3_mask.sum())
        total_day_nodes = len(unique_nodes_day)

        tertile_records.append({
            "Observation Date": obs_day,
            "Tertile 1 Count [0.0 - 0.33]": t1_count,
            "Tertile 2 Count [0.33 - 0.67]": t2_count,
            "Tertile 3 Count [0.67 - 1.00]": t3_count,
            "Tertile 1 Share": round(t1_count / total_day_nodes, 4) if total_day_nodes > 0 else 0,
            "Tertile 2 Share": round(t2_count / total_day_nodes, 4) if total_day_nodes > 0 else 0,
            "Tertile 3 Share": round(t3_count / total_day_nodes, 4) if total_day_nodes > 0 else 0,
        })

    df_tertiles = pd.DataFrame(tertile_records)
    df_tertiles.to_csv(f"{output_dir}/option_b_tertile_density_matrix.csv", index=False)

    # Plot B2: Relative Shares per Tertile over Time
    plt.figure(figsize=(14, 6))
    plt.plot(df_tertiles["Observation Date"], df_tertiles["Tertile 1 Share"], label='Tertile 1 Share', color='#1f77b4', marker='o')
    plt.plot(df_tertiles["Observation Date"], df_tertiles["Tertile 2 Share"], label='Tertile 2 Share', color='#ff7f0e', marker='s')
    plt.plot(df_tertiles["Observation Date"], df_tertiles["Tertile 3 Share"], label='Tertile 3 Share', color='#2ca02c', marker='^')
    plt.axhline(1.0 / 3.0, color='gray', linestyle='--', label='Balanced Share (33.3%)')
    plt.title(f"Option B: Relative Key-Space Share per Tertile\nSegment: {context_label}")
    plt.xlabel("Observation Date")
    plt.ylabel("Proportion of Total Nodes")
    plt.ylim(0, 0.6)
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/option_b_tertile_shares.png")
    plt.close()


    # ==============================================================================
    # OPTION C: STABLE VS. HIGH-CHURN (TRANSIENT) ECDF COMPARISON ANALYSIS
    # ==============================================================================
    # Classify nodes based on total snapshot appearances across dataset
    node_appearances = df_working.groupby("fingerprint").size()
    median_appearances = node_appearances.median()

    stable_fps = node_appearances[node_appearances >= median_appearances].index
    transient_fps = node_appearances[node_appearances < median_appearances].index

    df_stable = df_working[df_working["fingerprint"].isin(stable_fps)].drop_duplicates(subset=["fingerprint"])
    df_transient = df_working[df_working["fingerprint"].isin(transient_fps)].drop_duplicates(subset=["fingerprint"])

    stable_indices = np.sort(df_stable["norm_index"].values)
    transient_indices = np.sort(df_transient["norm_index"].values)

    # Perform Two-Sample KS Test between Stable and High-Churn node sub-populations
    if len(stable_indices) > 0 and len(transient_indices) > 0:
        ks_stat_2samp, p_val_2samp = ks_2samp(stable_indices, transient_indices)
    else:
        ks_stat_2samp, p_val_2samp = np.nan, np.nan

    # Export Option C Summary
    df_option_c_summary = pd.DataFrame([{
        "Stable Node Count": len(stable_indices),
        "Transient Node Count": len(transient_indices),
        "Appearance Threshold (Median)": median_appearances,
        "Two-Sample KS Statistic": round(float(ks_stat_2samp), 4) if not np.isnan(ks_stat_2samp) else np.nan,
        "p-value": round(float(p_val_2samp), 6) if not np.isnan(p_val_2samp) else np.nan
    }])
    df_option_c_summary.to_csv(f"{output_dir}/option_c_stable_vs_transient_ks_summary.csv", index=False)

    # Plot C1: Comparative Dual-ECDF (Stable vs. High-Churn vs. Ideal Uniform)
    plt.figure(figsize=(10, 6))
    if len(stable_indices) > 0:
        ecdf_stable = np.arange(1, len(stable_indices) + 1) / len(stable_indices)
        plt.plot(stable_indices, ecdf_stable, color='#1f77b4', linewidth=2.0, label=f'Stable HSDirs (n={len(stable_indices)})')

    if len(transient_indices) > 0:
        ecdf_transient = np.arange(1, len(transient_indices) + 1) / len(transient_indices)
        plt.plot(transient_indices, ecdf_transient, color='#d62728', linestyle='-.', linewidth=2.0, label=f'Transient/High-Churn HSDirs (n={len(transient_indices)})')

    plt.plot([0, 1], [0, 1], color='gray', linestyle='--', linewidth=1.5, label='Ideal Uniform U(0,1)')
    
    plt.title(f"Option C: Dual-ECDF Comparison (Stable vs. High-Churn HSDirs)\nSegment: {context_label} | KS Stat={ks_stat_2samp:.4f} (p={p_val_2samp:.4f})")
    plt.xlabel("Normalized Ring Index [0, 1]")
    plt.ylabel("Cumulative Probability")
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/option_c_dual_ecdf_comparison.png")
    plt.close()

    print(f"[UNIFORMITY-INFO] Completed successfully for context: '{context_label}'")
    return df_uniformity