#!/usr/bin/env python3
"""
Tor v3 HSDir Network Engineering and Analytical Framework
Comprehensive Empirical Assessment: Targeted Lookup Topologies vs. Network-Wide Consensus Baselines
"""

import os
import json
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# =====================================================================
# ENVIRONMENT SETUP & GLOBAL CONFIGURATION
# =====================================================================

# Configure high-resolution visualization environments
sns.set_theme(style="whitegrid")
plt.rcParams.update({
    'figure.figsize': (12, 6),
    'axes.labelsize': 12,
    'axes.titlesize': 14,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'figure.titlesize': 16
})

# Define tracking file paths matching your local repository storage
target_files = [
    "network_hsdir_consensus_snapshots.jsonl",
    "hsdir_ring_events.jsonl",
    "tracked_hsdir_consensus_snapshots.jsonl",
    "rotated_network_hsdir_consensus_snapshots.jsonl",
    "rotated_tracked_hsdir_consensus_snapshots.jsonl"
]

print("[INIT] Environment configurations and path parameters successfully established.")


# =====================================================================
# SECTION 1: INGESTION, ADAPTIVE FLATTENING, AND CACHING PIPELINE
# =====================================================================

def extract_and_flatten_telemetry(target_filename):
    output_csv = target_filename.replace('.jsonl', '.csv')
    print(f"[PROCESS] Ingesting log arrays from source stream: {target_filename}")
    
    consolidated_records = []
    
    with open(target_filename, 'r') as source_file:
        for index, text_line in enumerate(source_file):
            if not text_line.strip():
                continue
            try:
                parsed_json = json.loads(text_line)
            except json.JSONDecodeError as err:
                print(f"[METRIC ERROR] Skipping malformed schema line entry {index}: {err}")
                continue

            base_timestamp = parsed_json.get("timestamp")
            captured_onion = parsed_json.get("onion_address", None)
            
            # Determine internal nesting structures dynamically
            nested_array_key = None
            if "relays" in parsed_json:
                nested_array_key = "relays"
            elif "nodes" in parsed_json:
                nested_array_key = "nodes"
            elif "snapshot_data" in parsed_json:
                nested_array_key = "snapshot_data"
                
            if nested_array_key:
                sub_records = parsed_json.get(nested_array_key, [])
                for entry in sub_records:
                    flattened_item = entry.copy()
                    flattened_item["timestamp"] = base_timestamp
                    if captured_onion:
                        flattened_item["onion_address"] = captured_onion
                    consolidated_records.append(flattened_item)
            else:
                # Process flat entries directly (e.g., hsdir_ring_events)
                consolidated_records.append(parsed_json)
                
    if not consolidated_records:
        print(f"[WARNING] Zero usable records extracted from {target_filename}.")
        return False
        
    df_processed = pd.DataFrame(consolidated_records)
    
    # Feature Engineering: Temporal parsing strings
    if "timestamp" in df_processed.columns:
        parsed_datetimes = pd.to_datetime(df_processed["timestamp"], errors='coerce')
        df_processed["date"] = parsed_datetimes.dt.strftime("%d-%m")
        df_processed["hour"] = parsed_datetimes.dt.strftime("%H:%M")
        
    # Drop routing ports to keep tracking focused on layer-3 identities
    if "or_port" in df_processed.columns:
        df_processed.drop(columns=["or_port"], inplace=True, errors='ignore')
        
    # Standardize and map out binary directory validation flags
    for technical_flag in ["Fast", "HSDir", "Stable", "Valid"]:
        if "flags" in df_processed.columns:
            df_processed[technical_flag] = df_processed["flags"].apply(
                lambda val: 1 if (isinstance(val, list) and technical_flag in val) or \
                                 (isinstance(val, str) and technical_flag in val) else 0
            )
        else:
            df_processed[technical_flag] = 0
            
    if "flags" in df_processed.columns:
        df_processed.drop(columns=["flags"], inplace=True, errors='ignore')
        
    # Type-safe substitution for missing data values (Fixes TypeError in newer Pandas)
    fill_values = {
        col: 0 if pd.api.types.is_numeric_dtype(df_processed[col]) else "" 
        for col in df_processed.columns
    }
    df_processed = df_processed.fillna(value=fill_values)
    
    # Export to disk cache
    df_processed.to_csv(output_csv, index=False)
    print(f"[SUCCESS] Normalized and written to disk cache: {output_csv} [Rows: {len(df_processed)}]")
    return True


# =====================================================================
# SECTION 2: VERIFICATION, SCHEMA VALIDATION, AND CHRONOLOGICAL SORT
# =====================================================================

def verify_and_load_cached_matrix(csv_path):
    if not os.path.exists(csv_path):
        print(f"[CRITICAL] Operational vector file unavailable on path: {csv_path}")
        return None
    
    df = pd.read_csv(csv_path)
    
    # Define primary sorting layout keys
    sort_columns = []
    if "date" in df.columns:
        sort_columns.append("date")
    if "hour" in df.columns:
        sort_columns.append("hour")
    if "fingerprint" in df.columns:
        sort_columns.append("fingerprint")
        
    if sort_columns:
        df.sort_values(by=sort_columns, inplace=True)
        df.reset_index(drop=True, inplace=True)
        
    print(f"[VERIFIED] Structural table loaded: {csv_path} | Dimension Profile: {df.shape}")
    return df


# =====================================================================
# SECTION 3: GLOBAL NETWORK-WIDE HSDIR UPTIME AND ATTRITION MATRIX
# =====================================================================

def calculate_network_stability_matrices(df):
    if df is None or df.empty:
        print("[ERROR] High-level consensus dataframe empty or missing.")
        return None
        
    computed_metrics = []
    grouped_epochs = df.groupby("date")
    
    for observation_day, data_slice in grouped_epochs:
        total_unique_identities = data_slice["fingerprint"].nunique()
        
        # Isolate entries showing structural drop-offs or consecutive baseline absences
        offline_indicators = (data_slice["status"] == "offline") | (data_slice["consecutive_hourly_absences"] > 0)
        total_offline_identities = data_slice[offline_indicators]["fingerprint"].nunique()
        
        total_active_identities = total_unique_identities - total_offline_identities
        
        ratio_active = (total_active_identities / total_unique_identities * 100) if total_unique_identities > 0 else 0
        ratio_offline = 100.0 - ratio_active
        
        computed_metrics.append({
            "Observation Date": observation_day,
            "Total Unique HSDirs": total_unique_identities,
            "Active Directories": total_active_identities,
            "Active Ratio (%)": round(ratio_active, 2),
            "Offline Attrition": total_offline_identities,
            "Offline Ratio (%)": round(ratio_offline, 2)
        })
        
    df_summary_matrix = pd.DataFrame(computed_metrics)
    
    print(f"\n=== GLOBAL NET-WIDE CONSENSUS RESILIENCE SUMMARY ===")
    print(f"Total Unique Directory Signatures Discovered Across Scope: {df['fingerprint'].nunique()}")
    
    return df_summary_matrix


# =====================================================================
# SECTION 4: SYBIL INFRASTRUCTURE CLUSTERING & AS BLOCK ANALYSIS
# =====================================================================

def analyze_sybil_and_infrastructure_risk(df):
    if df is None or "ip" not in df.columns:
        print("[ERROR] Subnet tracking attributes are missing or unreadable.")
        return
        
    # Extract subnet strings safely
    df["ip_str"] = df["ip"].astype(str)
    df["/24_block"] = df["ip_str"].apply(lambda coord: ".".join(coord.split(".")[:3]))
    df["/16_block"] = df["ip_str"].apply(lambda coord: ".".join(coord.split(".")[:2]))
    
    # Isolate missing nodes
    offline_subset = df[(df["status"] == "offline") | (df["consecutive_hourly_absences"] > 0)].copy()
    
    print("\n=== TOP 5 NETWORK /24 SUBNET OUTAGE CONCENTRATIONS ===")
    block_24_ranking = offline_subset.groupby(["date", "/24_block"])["fingerprint"].count().sort_values(ascending=False)
    print(block_24_ranking.head(5).to_frame(name="Coordinated Absences Tally"))
    
    print("\n=== COOPERATIVE OPERATOR IDENTITY DISPLACEMENTS (RELAY FAMILIES) ===")
    if "family_ids" in offline_subset.columns:
        family_clustering = offline_subset.groupby(["date", "hour", "family_ids"])["fingerprint"].count()
        significant_operator_shifts = family_clustering[family_clustering > 1].sort_values(ascending=False)
        print(significant_operator_shifts.head(5).to_frame(name="Simultaneous Drops Count"))
    else:
        print("[INFO] Family cryptographic group definitions not active inside source file features.")


# =====================================================================
# SECTION 5: HASH RING TABLE (HRT) SPATIAL MAPPINGS & DISTRIBUTIONS
# =====================================================================

def generate_spatial_hrt_plots(df_tracked_source, df_network_source):
    fig, spatial_axes = plt.subplots(1, 2, figsize=(16, 6))
    
    # Subplot 1: Targeted Proximity Allocation Spectrum
    if df_tracked_source is not None and "hsdir_to_onion_ring_position" in df_tracked_source.columns:
        sns.histplot(
            data=df_tracked_source,
            x="hsdir_to_onion_ring_position",
            bins=40,
            color="darkred",
            kde=True,
            ax=spatial_axes[0]
        )
        spatial_axes[0].set_title("Targeted HSDir Proximity Position to Onion Vectors")
        spatial_axes[0].set_xlabel("Ring Arc Distance Offset Percentage")
        spatial_axes[0].set_ylabel("Observed Target Hits")
    else:
        spatial_axes[0].text(0.5, 0.5, "Targeted HRT Telemetry Metric Omitted", ha='center', va='center')
        
    # Subplot 2: Global Background Network-Wide Layout Density
    if df_network_source is not None and "hsdir_index_hrt_100" in df_network_source.columns:
        sns.histplot(
            data=df_network_source,
            x="hsdir_index_hrt_100",
            bins=40,
            color="teal",
            kde=True,
            ax=spatial_axes[1]
        )
        spatial_axes[1].set_title("Global Network-Wide Baseline HSDir Ring Layout")
        spatial_axes[1].set_xlabel("Consensus Ring Circumference Percentage [0-100]")
        spatial_axes[1].set_ylabel("Density Spectrum Magnitude")
    else:
        spatial_axes[1].text(0.5, 0.5, "Global Baseline HRT Telemetry Metric Omitted", ha='center', va='center')
        
    plt.suptitle("Tor v3 Hash Ring Table (HRT) Spatial Mapping Analysis Framework", fontsize=15)
    plt.tight_layout()
    plt.show()


# =====================================================================
# SECTION 6: STATISTICAL COMPARISON (TWO-SAMPLE K-S TEST)
# =====================================================================

def execute_comparative_distribution_audit(df_tracked, df_network):
    print("\n=== KOLMOGOROV-SMIRNOV (K-S) TOPOLOGICAL DISCREPANCY AUDIT ===")
    
    target_field = "hsdir_to_onion_ring_position"
    background_field = "hsdir_index_hrt_100"
    
    if df_tracked is None or df_network is None:
        print("[ERROR] Base matrices required for statistical comparison are unavailable.")
        return
        
    if target_field not in df_tracked.columns or background_field not in df_network.columns:
        print("[WARNING] Positional variables are absent from parameters. Skipping K-S test computation.")
        return
        
    sample_targeted = df_tracked[target_field].dropna().values
    sample_background = df_network[background_field].dropna().values
    
    print(f"Targeted Observation Footprint (Sample Size): {len(sample_targeted)}")
    print(f"Network-Wide Baseline Consensus (Sample Size): {len(sample_background)}")
    
    # Execute non-parametric testing configuration
    ks_statistic, calculated_p_value = stats.ks_2samp(sample_targeted, sample_background)
    
    print(f"Calculated K-S Statistic Divergence Factor: {ks_statistic:.5f}")
    print(f"Asymptotic Significance Probability (P-Value): {calculated_p_value:.7e}")
    
    # Statistical significance verdict evaluation
    if calculated_p_value < 0.05:
        print("[VERDICT] Reject H0. The spatial distribution of targeted HSDirs diverges significantly from the global consensus background.")
    else:
        print("[VERDICT] Fail to reject H0. Targeted directory coordinates conform to the baseline uniform network distribution layout.")


# =====================================================================
# SECTION 7: SHARED RANDOM VALUE (SRV) POST-ROTATION BREAKDOWN
# =====================================================================

def analyze_srv_rotation_impact(df_standard, df_rotated):
    print("\n=== TOPOLOGICAL SHIFT ANALYSIS ACROSS SRV ROTATION BOUNDARIES ===")
    if df_standard is None or df_rotated is None:
        print("[INFO] Post-rotation telemetry metrics omitted or absent in working path.")
        return
        
    standard_set = set(df_standard["fingerprint"].unique())
    rotated_set = set(df_rotated["fingerprint"].unique())
    
    persistent_nodes = standard_set.intersection(rotated_set)
    displaced_nodes = standard_set.difference(rotated_set)
    introduced_nodes = rotated_set.difference(standard_set)
    
    print(f"Pre-Rotation Active HSDir Node Base: {len(standard_set)}")
    print(f"Post-Rotation Active HSDir Node Base: {len(rotated_set)}")
    print(f"Persistent Directories (Survived Post-Rotation): {len(persistent_nodes)}")
    print(f"Displaced Registrations (Dropped Post-Rotation): {len(displaced_nodes)}")
    print(f"Newly Introduced Directory Registrations: {len(introduced_nodes)}")
    
    if len(standard_set) > 0:
        persistence_ratio = (len(persistent_nodes) / len(standard_set)) * 100
        print(f"Network Structural Persistence Ratio: {persistence_ratio:.2f}%")


# =====================================================================
# SECTION 8: LIVE RING EVENT TELEMETRY LOG DIAGNOSTICS
# =====================================================================

def process_live_event_telemetry(df_events_source):
    print("\n=== LIVE TARGETED HSDIR EVENT TELEMETRY DIAGNOSTICS ===")
    if df_events_source is None or df_events_source.empty:
        print("[ERROR] Targeted live transaction event logs empty or missing.")
        return
        
    print("\n--- TRANSACTION VOLUME DISTRIBUTIONS ---")
    if "action" in df_events_source.columns:
        print(df_events_source["action"].value_counts().to_frame(name="Transaction Count"))
        
    print("\n--- PERFORMANCE STATE DIAGNOSES ---")
    if "reason" in df_events_source.columns:
        print(df_events_source["reason"].value_counts().to_frame(name="Occurrence Count"))
        
    # Generate structural cross-tabulation metrics
    if "action" in df_events_source.columns and "reason" in df_events_source.columns:
        print("\n--- TRANSACTION FAILURE FREQUENCY MATRIX ---")
        cross_tabulation = pd.crosstab(df_events_source["action"], df_events_source["reason"], margins=True)
        print(cross_tabulation)


# =====================================================================
# ORCHESTRATION PIPELINE EXECUTION
# =====================================================================

if __name__ == "__main__":
    print("=== STARTING TOR V3 DATA EXTRACTION AND PROCESSING RUN ===")
    
    # Run data ingestion across log profiles
    for filename in target_files:
        if os.path.exists(filename):
            extract_and_flatten_telemetry(filename)
        else:
            print(f"[SKIPPED] Target telemetry log not found in working path: {filename}")
            
    print("\n=== STARTING ANALYSIS PHASE ===")
    
    # Reload cleaned frames safely with index checking and multi-index sorting
    df_net_consensus = verify_and_load_cached_matrix("network_hsdir_consensus_snapshots.csv")
    df_ring_events   = verify_and_load_cached_matrix("hsdir_ring_events.csv")
    df_track_consensus = verify_and_load_cached_matrix("tracked_hsdir_consensus_snapshots.csv")
    df_rot_net       = verify_and_load_cached_matrix("rotated_network_hsdir_consensus_snapshots.csv")
    df_rot_track     = verify_and_load_cached_matrix("rotated_tracked_hsdir_consensus_snapshots.csv")
    
    # Execute analytical calculations
    if df_net_consensus is not None:
        stability_report = calculate_network_stability_matrices(df_net_consensus)
        if stability_report is not None:
            print(stability_report)
            
        analyze_sybil_and_infrastructure_risk(df_net_consensus)
        
    if df_track_consensus is not None or df_net_consensus is not None:
        execute_comparative_distribution_audit(df_track_consensus, df_net_consensus)
        generate_spatial_hrt_plots(df_track_consensus, df_net_consensus)
        
    analyze_srv_rotation_impact(df_net_consensus, df_rot_net)
    
    if df_ring_events is not None:
        process_live_event_telemetry(df_ring_events)
        
    print("\n=== ANALYSIS COMPLETE ===")