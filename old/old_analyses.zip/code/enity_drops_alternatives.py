def compute_entity_drop_analysis(df_slice, context_label):
    """
    Computes daily entity drop metrics (Total and Partial drops) evaluated at hourly granularity 
    across three entity groupings: Family ID, Complete IP, and /24 Subnet.
    """
    output_dir = "analysis-results/entity_drop_analysis"
    os.makedirs(output_dir, exist_ok=True)

    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    if df_slice.empty:
        print(f"[ENTITY-DROP-WARNING] Empty snapshot data slice received for context: {context_label}")
        return None

    df_working = df_slice.copy()

    # Automatically derive /24 Subnet if not explicitly pre-computed
    if "subnet_24" not in df_working.columns and "ip_address" in df_working.columns:
        def get_subnet(ip):
            if isinstance(ip, str) and "." in ip:
                return ".".join(ip.split(".")[:3]) + ".0/24"
            return None
        df_working["subnet_24"] = df_working["ip_address"].apply(get_subnet)

    unique_days = [d for d in df_working["date"].unique() if d not in ['', 'None', None] and pd.notna(d)]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    computed_daily_metrics = []

    entity_configs = [
        ("declared_family_id", "Family ID"),
        ("ip_address", "Complete IP"),
        ("subnet_24", "/24 Subnet")
    ]

    for observation_day in unique_days_sorted:
        day_snapshots = df_working[df_working["date"] == observation_day]
        unique_hours = day_snapshots["hour"].unique() if "hour" in day_snapshots.columns else [0]

        for col_name, entity_label in entity_configs:
            if col_name not in day_snapshots.columns:
                continue

            # Filter out invalid or missing entity keys
            valid_day_snaps = day_snapshots[
                day_snapshots[col_name].notna() & 
                (~day_snapshots[col_name].isin(['', 'None', 'nan', None]))
            ]

            if valid_day_snaps.empty:
                continue

            total_unique_day_entities = valid_day_snaps[col_name].nunique()

            # Track unique entities experiencing total or partial drops on this observation day
            total_drop_entities_day = set()
            partial_drop_entities_day = set()

            # Measure drop conditions hour by hour for maximum precision
            for h in unique_hours:
                hour_snaps = valid_day_snaps[valid_day_snaps["hour"] == h] if "hour" in valid_day_snaps.columns else valid_day_snaps

                if hour_snaps.empty:
                    continue

                # Group by entity key and count active vs inactive node statuses
                grouped = hour_snaps.groupby(col_name)["status"].agg(
                    active=lambda s: (s == "ACTIVE_IN_RING").sum(),
                    dropped=lambda s: (s != "ACTIVE_IN_RING").sum()
                )

                for entity_key, row in grouped.iterrows():
                    active = row["active"]
                    dropped = row["dropped"]

                    # Total Drop: All nodes dropped, zero active
                    if active == 0 and dropped > 0:
                        total_drop_entities_day.add(entity_key)
                    # Partial Drop: Strictly > 2 nodes dropped, and at least 1 node active
                    elif dropped >= 2 and active > 0:
                        partial_drop_entities_day.add(entity_key)

            total_drops_cnt = len(total_drop_entities_day)
            partial_drops_cnt = len(partial_drop_entities_day)

            pct_total_drops = (total_drops_cnt / total_unique_day_entities * 100.0) if total_unique_day_entities > 0 else 0.0
            pct_partial_drops = (partial_drops_cnt / total_unique_day_entities * 100.0) if total_unique_day_entities > 0 else 0.0

            computed_daily_metrics.append({
                "Observation Date": observation_day,
                "Entity Type": entity_label,
                "Total Unique Entities": total_unique_day_entities,
                "Total Drops Count": total_drops_cnt,
                "Total Drops %": round(pct_total_drops, 2),
                "Partial Drops Count": partial_drops_cnt,
                "Partial Drops %": round(pct_partial_drops, 2)
            })

    df_daily_matrix = pd.DataFrame(computed_daily_metrics)
    if df_daily_matrix.empty:
        print(f"[ENTITY-DROP-ERROR] Core metric matrix is empty for context: {context_label}")
        return None

    color_palette = {
        "Family ID": {"total": "#d90429", "partial": "#f77f00"},
        "Complete IP": {"total": "#003049", "partial": "#669bbc"},
        "/24 Subnet": {"total": "#2a9d8f", "partial": "#e9c46a"}
    }
    entity_types = df_daily_matrix["Entity Type"].unique()

    # -------------------------------------------------------------------------
    # PLOT 1: DAILY ABSOLUTE COUNTS PROGRESSION
    # -------------------------------------------------------------------------
    plt.figure(figsize=(14, 7))

    for ent_type in entity_types:
        sub_df = df_daily_matrix[df_daily_matrix["Entity Type"] == ent_type]
        c_tot = color_palette.get(ent_type, {}).get("total", "red")
        c_part = color_palette.get(ent_type, {}).get("partial", "orange")

        plt.plot(sub_df["Observation Date"], sub_df["Total Drops Count"],
                 marker='o', linewidth=2.2, color=c_tot, label=f'{ent_type} - Total Drops')
        plt.plot(sub_df["Observation Date"], sub_df["Partial Drops Count"],
                 marker='x', linestyle='--', linewidth=1.8, color=c_part, label=f'{ent_type} - Partial Drops')

        for x, y in zip(sub_df["Observation Date"], sub_df["Total Drops Count"]):
            if y > 0:
                plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, 6), ha='center', fontsize=8, fontweight='bold')
        for x, y in zip(sub_df["Observation Date"], sub_df["Partial Drops Count"]):
            if y > 0:
                plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, -10), ha='center', fontsize=8)

    plt.title(f"Tor v3 HSDir Daily Entity Drop Absolute Counts ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Number of Dropped Entities (Daily)")
    plt.xticks(rotation=45)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_entity_drops_daily_progression.png")
    plt.close()

    # -------------------------------------------------------------------------
    # PLOT 2: DAILY PERCENTAGE PROGRESSION
    # -------------------------------------------------------------------------
    plt.figure(figsize=(14, 7))

    for ent_type in entity_types:
        sub_df = df_daily_matrix[df_daily_matrix["Entity Type"] == ent_type]
        c_tot = color_palette.get(ent_type, {}).get("total", "red")
        c_part = color_palette.get(ent_type, {}).get("partial", "orange")

        plt.plot(sub_df["Observation Date"], sub_df["Total Drops %"],
                 marker='o', linewidth=2.2, color=c_tot, label=f'{ent_type} - Total Drops (%)')
        plt.plot(sub_df["Observation Date"], sub_df["Partial Drops %"],
                 marker='x', linestyle='--', linewidth=1.8, color=c_part, label=f'{ent_type} - Partial Drops (%)')

        for x, y in zip(sub_df["Observation Date"], sub_df["Total Drops %"]):
            if y > 0:
                plt.annotate(f"{y:.2f}%", (x, y), textcoords="offset points", xytext=(0, 6), ha='center', fontsize=8, fontweight='bold')
        for x, y in zip(sub_df["Observation Date"], sub_df["Partial Drops %"]):
            if y > 0:
                plt.annotate(f"{y:.2f}%", (x, y), textcoords="offset points", xytext=(0, -10), ha='center', fontsize=8)

    max_pct = max(df_daily_matrix["Total Drops %"].max(), df_daily_matrix["Partial Drops %"].max())
    plt.ylim(0, max(max_pct * 1.15 + 1, 5))

    plt.title(f"Tor v3 HSDir Daily Entity Drop Percentage Progression ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Percentage of Total Entities (%)")
    plt.xticks(rotation=45)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_entity_drops_daily_percentage_progression.png")
    plt.close()

    # Save Clean Daily Entity Matrix
    df_daily_matrix.to_csv(f"{output_dir}/{context_label}_entity_drops_daily_matrix.csv", index=False)

    print(f"[ENTITY-DROP-INFO] Entity drop analysis successfully executed for context: '{context_label}'")
    return df_daily_matrix


def entity_drop_analysis(df, context_label):
    """
    Wrapper function matching hsdir-analysis-v3.py standard. Handles sub-population segmentation if applicable.
    """
    print(f"=== PROCESSING {context_label.upper()} ENTITY DROP ANALYSIS ===")
    if df is None or df.empty:
        print(f"[ENTITY-DROP-ERROR] Missing input data layout for context '{context_label}'.")
        return None

    global_reporting_matrix = compute_entity_drop_analysis(df, context_label)

    if context_label in ["tracked_targets", "rotated_tracked_targets"] and "service_type" in df.columns:
        unique_services = df["service_type"].dropna().unique()
        unique_services = [s for s in unique_services if s not in ['', 'nan', 'None', None]]

        for service in unique_services:
            print(f"    --> Isolating entity drop analysis for hidden service type: {service}")
            sub_population_df = df[df["service_type"] == service]
            if not sub_population_df.empty:
                segmented_label = f"{context_label}_{str(service).lower()}"
                compute_entity_drop_analysis(sub_population_df, segmented_label)

    return global_reporting_matrix

def compute_entity_drop_analysis_accumulated(df_slice, context_label):
    """
    Computes daily accumulated entity drop metrics (Total and Partial drops) by 
    summing hourly drop occurrences across three entity groupings: 
    Family ID, Complete IP, and /24 Subnet (allowing multi-hour double-counting).
    """
    output_dir = "analysis-results/entity_drop_analysis_accumulated"
    os.makedirs(output_dir, exist_ok=True)

    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    if df_slice.empty:
        print(f"[ENTITY-DROP-WARNING] Empty snapshot data slice received for context: {context_label}")
        return None

    df_working = df_slice.copy()

    # Derive /24 Subnet if missing
    if "subnet_24" not in df_working.columns and "ip_address" in df_working.columns:
        def get_subnet(ip):
            if isinstance(ip, str) and "." in ip:
                return ".".join(ip.split(".")[:3]) + ".0/24"
            return None
        df_working["subnet_24"] = df_working["ip_address"].apply(get_subnet)

    unique_days = [d for d in df_working["date"].unique() if d not in ['', 'None', None] and pd.notna(d)]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    computed_daily_metrics = []

    entity_configs = [
        ("declared_family_id", "Family ID"),
        ("ip_address", "Complete IP"),
        ("subnet_24", "/24 Subnet")
    ]

    for observation_day in unique_days_sorted:
        day_snapshots = df_working[df_working["date"] == observation_day]
        unique_hours = day_snapshots["hour"].unique() if "hour" in day_snapshots.columns else [0]

        for col_name, entity_label in entity_configs:
            if col_name not in day_snapshots.columns:
                continue

            # Filter valid entity values
            valid_day_snaps = day_snapshots[
                day_snapshots[col_name].notna() & 
                (~day_snapshots[col_name].isin(['', 'None', 'nan', None]))
            ]

            if valid_day_snaps.empty:
                continue

            day_total_drops_acc = 0
            day_partial_drops_acc = 0
            day_entity_hours_acc = 0

            # Sum drop occurrences hour by hour across the day (double-counting prolonged drops)
            for h in unique_hours:
                hour_snaps = valid_day_snaps[valid_day_snaps["hour"] == h] if "hour" in valid_day_snaps.columns else valid_day_snaps

                if hour_snaps.empty:
                    continue

                grouped = hour_snaps.groupby(col_name)["status"].agg(
                    active=lambda s: (s == "ACTIVE_IN_RING").sum(),
                    dropped=lambda s: (s != "ACTIVE_IN_RING").sum()
                )

                hour_total_entities = len(grouped)
                day_entity_hours_acc += hour_total_entities

                for entity_key, row in grouped.iterrows():
                    active = row["active"]
                    dropped = row["dropped"]

                    # Total Drop: All nodes in this hour dropped
                    if active == 0 and dropped > 0:
                        day_total_drops_acc += 1
                    # Partial Drop: >2 nodes dropped, but at least 1 active
                    elif dropped > 2 and active > 0:
                        day_partial_drops_acc += 1

            pct_total_drops = (day_total_drops_acc / day_entity_hours_acc * 100.0) if day_entity_hours_acc > 0 else 0.0
            pct_partial_drops = (day_partial_drops_acc / day_entity_hours_acc * 100.0) if day_entity_hours_acc > 0 else 0.0

            computed_daily_metrics.append({
                "Observation Date": observation_day,
                "Entity Type": entity_label,
                "Total Entity-Hours Evaluated": day_entity_hours_acc,
                "Accumulated Total Drops Count": day_total_drops_acc,
                "Accumulated Total Drops %": round(pct_total_drops, 2),
                "Accumulated Partial Drops Count": day_partial_drops_acc,
                "Accumulated Partial Drops %": round(pct_partial_drops, 2)
            })

    df_daily_matrix = pd.DataFrame(computed_daily_metrics)
    if df_daily_matrix.empty:
        print(f"[ENTITY-DROP-ERROR] Core metric matrix is empty for context: {context_label}")
        return None

    color_palette = {
        "Family ID": {"total": "#d90429", "partial": "#f77f00"},
        "Complete IP": {"total": "#003049", "partial": "#669bbc"},
        "/24 Subnet": {"total": "#2a9d8f", "partial": "#e9c46a"}
    }
    entity_types = df_daily_matrix["Entity Type"].unique()

    # -------------------------------------------------------------------------
    # PLOT 1: DAILY ACCUMULATED ABSOLUTE COUNTS PROGRESSION
    # -------------------------------------------------------------------------
    plt.figure(figsize=(14, 7))

    for ent_type in entity_types:
        sub_df = df_daily_matrix[df_daily_matrix["Entity Type"] == ent_type]
        c_tot = color_palette.get(ent_type, {}).get("total", "red")
        c_part = color_palette.get(ent_type, {}).get("partial", "orange")

        plt.plot(sub_df["Observation Date"], sub_df["Accumulated Total Drops Count"],
                 marker='o', linewidth=2.2, color=c_tot, label=f'{ent_type} - Total Drops (Hourly Sum)')
        plt.plot(sub_df["Observation Date"], sub_df["Accumulated Partial Drops Count"],
                 marker='x', linestyle='--', linewidth=1.8, color=c_part, label=f'{ent_type} - Partial Drops (Hourly Sum)')

        for x, y in zip(sub_df["Observation Date"], sub_df["Accumulated Total Drops Count"]):
            if y > 0:
                plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, 6), ha='center', fontsize=8, fontweight='bold')
        for x, y in zip(sub_df["Observation Date"], sub_df["Accumulated Partial Drops Count"]):
            if y > 0:
                plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, -10), ha='center', fontsize=8)

    plt.title(f"Tor v3 HSDir Daily Accumulated Entity Drops - Hourly Summed ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Accumulated Dropped Entity-Hours (Daily)")
    plt.xticks(rotation=45)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_entity_drops_daily_accumulated_counts.png")
    plt.close()

    # -------------------------------------------------------------------------
    # PLOT 2: DAILY ACCUMULATED PERCENTAGE PROGRESSION
    # -------------------------------------------------------------------------
    plt.figure(figsize=(14, 7))

    for ent_type in entity_types:
        sub_df = df_daily_matrix[df_daily_matrix["Entity Type"] == ent_type]
        c_tot = color_palette.get(ent_type, {}).get("total", "red")
        c_part = color_palette.get(ent_type, {}).get("partial", "orange")

        plt.plot(sub_df["Observation Date"], sub_df["Accumulated Total Drops %"],
                 marker='o', linewidth=2.2, color=c_tot, label=f'{ent_type} - Total Drops %')
        plt.plot(sub_df["Observation Date"], sub_df["Accumulated Partial Drops %"],
                 marker='x', linestyle='--', linewidth=1.8, color=c_part, label=f'{ent_type} - Partial Drops %')

        for x, y in zip(sub_df["Observation Date"], sub_df["Accumulated Total Drops %"]):
            if y > 0:
                plt.annotate(f"{y:.2f}%", (x, y), textcoords="offset points", xytext=(0, 6), ha='center', fontsize=8, fontweight='bold')
        for x, y in zip(sub_df["Observation Date"], sub_df["Accumulated Partial Drops %"]):
            if y > 0:
                plt.annotate(f"{y:.2f}%", (x, y), textcoords="offset points", xytext=(0, -10), ha='center', fontsize=8)

    max_pct = max(df_daily_matrix["Accumulated Total Drops %"].max(), df_daily_matrix["Accumulated Partial Drops %"].max())
    plt.ylim(0, max(max_pct * 1.15 + 1, 5))

    plt.title(f"Tor v3 HSDir Daily Entity Drop Percentage Progression - Hourly Weighted ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Percentage of Total Entity Observations (%)")
    plt.xticks(rotation=45)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_entity_drops_daily_accumulated_percentage.png")
    plt.close()

    # Save Clean Daily Matrix
    df_daily_matrix.to_csv(f"{output_dir}/{context_label}_entity_drops_daily_accumulated_matrix.csv", index=False)

    print(f"[ENTITY-DROP-INFO] Accumulated entity drop analysis successfully executed for context: '{context_label}'")
    return df_daily_matrix


def entity_drop_analysis_accumulated(df, context_label):
    """
    Wrapper function matching hsdir-analysis-v3.py standard. Handles sub-population segmentation if applicable.
    """
    print(f"=== PROCESSING {context_label.upper()} ACCUMULATED ENTITY DROP ANALYSIS ===")
    if df is None or df.empty:
        print(f"[ENTITY-DROP-ERROR] Missing input data layout for context '{context_label}'.")
        return None

    global_reporting_matrix = compute_entity_drop_analysis_accumulated(df, context_label)

    if context_label in ["tracked_targets", "rotated_tracked_targets"] and "service_type" in df.columns:
        unique_services = df["service_type"].dropna().unique()
        unique_services = [s for s in unique_services if s not in ['', 'nan', 'None', None]]

        for service in unique_services:
            print(f"    --> Isolating accumulated entity drop analysis for hidden service type: {service}")
            sub_population_df = df[df["service_type"] == service]
            if not sub_population_df.empty:
                segmented_label = f"{context_label}_{str(service).lower()}"
                compute_entity_drop_analysis_accumulated(sub_population_df, segmented_label)

    return global_reporting_matrix

def compute_entity_drop_analysis_per_entity(df_slice, context_label):
    """
    Computes daily entity drop metrics by evaluating drop events per individual entity 
    across the 24-hour timeline, summing them for absolute counts, and scaling against 
    total known entities for percentages.
    """
    output_dir = "analysis-results/entity_drop_analysis_per_entity"
    os.makedirs(output_dir, exist_ok=True)

    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    if df_slice.empty:
        print(f"[ENTITY-DROP-WARNING] Empty snapshot data slice received for context: {context_label}")
        return None

    df_working = df_slice.copy()

    # Derive /24 Subnet if missing
    if "subnet_24" not in df_working.columns and "ip_address" in df_working.columns:
        def get_subnet(ip):
            if isinstance(ip, str) and "." in ip:
                return ".".join(ip.split(".")[:3]) + ".0/24"
            return None
        df_working["subnet_24"] = df_working["ip_address"].apply(get_subnet)

    unique_days = [d for d in df_working["date"].unique() if d not in ['', 'None', None] and pd.notna(d)]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    computed_daily_metrics = []

    entity_configs = [
        ("declared_family_id", "Family ID"),
        ("ip_address", "Complete IP"),
        ("subnet_24", "/24 Subnet")
    ]

    for observation_day in unique_days_sorted:
        day_snapshots = df_working[df_working["date"] == observation_day]
        unique_hours = sorted(day_snapshots["hour"].unique()) if "hour" in day_snapshots.columns else [0]

        for col_name, entity_label in entity_configs:
            if col_name not in day_snapshots.columns:
                continue

            # Filter valid entity values
            valid_day_snaps = day_snapshots[
                day_snapshots[col_name].notna() & 
                (~day_snapshots[col_name].isin(['', 'None', 'nan', None]))
            ]

            if valid_day_snaps.empty:
                continue

            # Total unique entities known for this type on this day (N_total)
            all_known_entities = valid_day_snaps[col_name].unique()
            n_total_entities = len(all_known_entities)

            if n_total_entities == 0:
                continue

            # Track drop events per individual entity across the day
            entity_drop_records = {ent: {'total_drops': 0, 'partial_drops': 0} for ent in all_known_entities}

            for h in unique_hours:
                hour_snaps = valid_day_snaps[valid_day_snaps["hour"] == h] if "hour" in valid_day_snaps.columns else valid_day_snaps
                if hour_snaps.empty:
                    continue

                grouped = hour_snaps.groupby(col_name)["status"].agg(
                    active=lambda s: (s == "ACTIVE_IN_RING").sum(),
                    dropped=lambda s: (s != "ACTIVE_IN_RING").sum()
                )

                for entity_key, row in grouped.iterrows():
                    if entity_key in entity_drop_records:
                        active = row["active"]
                        dropped = row["dropped"]

                        # Total Drop: Active == 0 and Dropped > 0
                        if active == 0 and dropped > 0:
                            entity_drop_records[entity_key]['total_drops'] += 1
                        # Partial Drop: Dropped > 2 and Active > 0
                        elif dropped > 2 and active > 0:
                            entity_drop_records[entity_key]['partial_drops'] += 1

            # Sum absolute counts across all entities
            absolute_total_drops = sum(rec['total_drops'] for rec in entity_drop_records.values())
            absolute_partial_drops = sum(rec['partial_drops'] for rec in entity_drop_records.values())

            # Calculate percentages: Sum of entity drop ratios / All known entities
            pct_total_drops = (absolute_total_drops / n_total_entities) * 100.0
            pct_partial_drops = (absolute_partial_drops / n_total_entities) * 100.0

            computed_daily_metrics.append({
                "Observation Date": observation_day,
                "Entity Type": entity_label,
                "Total Known Entities": n_total_entities,
                "Absolute Total Drops": absolute_total_drops,
                "Total Drops %": round(pct_total_drops, 2),
                "Absolute Partial Drops": absolute_partial_drops,
                "Partial Drops %": round(pct_partial_drops, 2)
            })

    df_daily_matrix = pd.DataFrame(computed_daily_metrics)
    if df_daily_matrix.empty:
        print(f"[ENTITY-DROP-ERROR] Core metric matrix is empty for context: {context_label}")
        return None

    color_palette = {
        "Family ID": {"total": "#d90429", "partial": "#f77f00"},
        "Complete IP": {"total": "#003049", "partial": "#669bbc"},
        "/24 Subnet": {"total": "#2a9d8f", "partial": "#e9c46a"}
    }
    entity_types = df_daily_matrix["Entity Type"].unique()

    # -------------------------------------------------------------------------
    # PLOT 1: ABSOLUTE COUNTS PROGRESSION
    # -------------------------------------------------------------------------
    plt.figure(figsize=(14, 7))

    for ent_type in entity_types:
        sub_df = df_daily_matrix[df_daily_matrix["Entity Type"] == ent_type]
        c_tot = color_palette.get(ent_type, {}).get("total", "red")
        c_part = color_palette.get(ent_type, {}).get("partial", "orange")

        plt.plot(sub_df["Observation Date"], sub_df["Absolute Total Drops"],
                 marker='o', linewidth=2.2, color=c_tot, label=f'{ent_type} - Absolute Total Drops')
        plt.plot(sub_df["Observation Date"], sub_df["Absolute Partial Drops"],
                 marker='x', linestyle='--', linewidth=1.8, color=c_part, label=f'{ent_type} - Absolute Partial Drops')

        for x, y in zip(sub_df["Observation Date"], sub_df["Absolute Total Drops"]):
            if y > 0:
                plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, 6), ha='center', fontsize=8, fontweight='bold')
        for x, y in zip(sub_df["Observation Date"], sub_df["Absolute Partial Drops"]):
            if y > 0:
                plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, -10), ha='center', fontsize=8)

    plt.title(f"Tor v3 HSDir Per-Entity Accumulated Absolute Drops ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Absolute Drop Event Count (Daily Sum)")
    plt.xticks(rotation=45)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_per_entity_absolute_drops.png")
    plt.close()

    # -------------------------------------------------------------------------
    # PLOT 2: PERCENTAGE PROGRESSION
    # -------------------------------------------------------------------------
    plt.figure(figsize=(14, 7))

    for ent_type in entity_types:
        sub_df = df_daily_matrix[df_daily_matrix["Entity Type"] == ent_type]
        c_tot = color_palette.get(ent_type, {}).get("total", "red")
        c_part = color_palette.get(ent_type, {}).get("partial", "orange")

        plt.plot(sub_df["Observation Date"], sub_df["Total Drops %"],
                 marker='o', linewidth=2.2, color=c_tot, label=f'{ent_type} - Total Drops %')
        plt.plot(sub_df["Observation Date"], sub_df["Partial Drops %"],
                 marker='x', linestyle='--', linewidth=1.8, color=c_part, label=f'{ent_type} - Partial Drops %')

        for x, y in zip(sub_df["Observation Date"], sub_df["Total Drops %"]):
            if y > 0:
                plt.annotate(f"{y:.2f}%", (x, y), textcoords="offset points", xytext=(0, 6), ha='center', fontsize=8, fontweight='bold')
        for x, y in zip(sub_df["Observation Date"], sub_df["Partial Drops %"]):
            if y > 0:
                plt.annotate(f"{y:.2f}%", (x, y), textcoords="offset points", xytext=(0, -10), ha='center', fontsize=8)

    max_pct = max(df_daily_matrix["Total Drops %"].max(), df_daily_matrix["Partial Drops %"].max())
    plt.ylim(0, max(max_pct * 1.15 + 1, 5))

    plt.title(f"Tor v3 HSDir Per-Entity Accumulated Percentage Progression ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Percentage of Known Entities (%)")
    plt.xticks(rotation=45)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_per_entity_percentage_progression.png")
    plt.close()

    # Save Clean Daily Matrix
    df_daily_matrix.to_csv(f"{output_dir}/{context_label}_per_entity_drop_matrix.csv", index=False)

    print(f"[ENTITY-DROP-INFO] Per-entity drop analysis successfully executed for context: '{context_label}'")
    return df_daily_matrix


def entity_drop_analysis_per_entity_wrapper(df, context_label):
    """
    Wrapper function matching hsdir-analysis-v3.py standard. Handles sub-population segmentation if applicable.
    """
    print(f"=== PROCESSING {context_label.upper()} PER-ENTITY DROP ANALYSIS ===")
    if df is None or df.empty:
        print(f"[ENTITY-DROP-ERROR] Missing input data layout for context '{context_label}'.")
        return None

    global_reporting_matrix = compute_entity_drop_analysis_per_entity(df, context_label)

    if context_label in ["tracked_targets", "rotated_tracked_targets"] and "service_type" in df.columns:
        unique_services = df["service_type"].dropna().unique()
        unique_services = [s for s in unique_services if s not in ['', 'nan', 'None', None]]

        for service in unique_services:
            print(f"    --> Isolating per-entity drop analysis for hidden service type: {service}")
            sub_population_df = df[df["service_type"] == service]
            if not sub_population_df.empty:
                segmented_label = f"{context_label}_{str(service).lower()}"
                compute_entity_drop_analysis_per_entity(sub_population_df, segmented_label)

    return global_reporting_matrix

def compute_entity_drop_analysis_per_entity(df_slice, context_label):
    """
    Computes daily entity drop metrics by taking the average entity drop percentages 
    according to updated average-based scaling rules.
    """
    output_dir = "analysis-results/entity_drop_analysis_averaged"
    os.makedirs(output_dir, exist_ok=True)

    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    if df_slice.empty:
        print(f"[ENTITY-DROP-WARNING] Empty snapshot data slice received for context: {context_label}")
        return None

    df_working = df_slice.copy()

    # Derive /24 Subnet if missing
    if "subnet_24" not in df_working.columns and "ip_address" in df_working.columns:
        def get_subnet(ip):
            if isinstance(ip, str) and "." in ip:
                return ".".join(ip.split(".")[:3]) + ".0/24"
            return None
        df_working["subnet_24"] = df_working["ip_address"].apply(get_subnet)

    unique_days = [d for d in df_working["date"].unique() if d not in ['', 'None', None] and pd.notna(d)]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    computed_daily_metrics = []

    entity_configs = [
        ("declared_family_id", "Family ID"),
        ("ip_address", "Complete IP"),
        ("subnet_24", "/24 Subnet")
    ]

    for observation_day in unique_days_sorted:
        day_snapshots = df_working[df_working["date"] == observation_day]
        unique_hours = sorted(day_snapshots["hour"].unique()) if "hour" in day_snapshots.columns else [0]
        total_hours = len(unique_hours) if len(unique_hours) > 0 else 1

        for col_name, entity_label in entity_configs:
            if col_name not in day_snapshots.columns:
                continue

            valid_day_snaps = day_snapshots[
                day_snapshots[col_name].notna() & 
                (~day_snapshots[col_name].isin(['', 'None', 'nan', None]))
            ]

            if valid_day_snaps.empty:
                continue

            all_known_entities = valid_day_snaps[col_name].unique()
            n_total_entities = len(all_known_entities)

            if n_total_entities == 0:
                continue

            # Record drop counts per individual entity
            entity_drop_records = {ent: {'total_drops': 0, 'partial_drops': 0} for ent in all_known_entities}

            for h in unique_hours:
                hour_snaps = valid_day_snaps[valid_day_snaps["hour"] == h] if "hour" in valid_day_snaps.columns else valid_day_snaps
                if hour_snaps.empty:
                    continue

                grouped = hour_snaps.groupby(col_name)["status"].agg(
                    active=lambda s: (s == "ACTIVE_IN_RING").sum(),
                    dropped=lambda s: (s != "ACTIVE_IN_RING").sum()
                )

                for entity_key, row in grouped.iterrows():
                    if entity_key in entity_drop_records:
                        active = row["active"]
                        dropped = row["dropped"]

                        if active == 0 and dropped > 0:
                            entity_drop_records[entity_key]['total_drops'] += 1
                        elif dropped > 2 and active > 0:
                            entity_drop_records[entity_key]['partial_drops'] += 1

            # Absolute counts
            absolute_total_drops = sum(rec['total_drops'] for rec in entity_drop_records.values())
            absolute_partial_drops = sum(rec['partial_drops'] for rec in entity_drop_records.values())

            # Individual entity drop percentages relative to total monitored hours
            entity_total_pcts = [(rec['total_drops'] / total_hours) * 100.0 for rec in entity_drop_records.values()]
            entity_partial_pcts = [(rec['partial_drops'] / total_hours) * 100.0 for rec in entity_drop_records.values()]

            # NEW LOGIC FORMULAS:
            # Total Drop % = Average of all entity Total Drop %
            pct_total_drops = float(np.mean(entity_total_pcts)) if entity_total_pcts else 0.0

            # Partial Drop % = Average of entity Partial Drop % / All known entities
            avg_partial_pct = float(np.mean(entity_partial_pcts)) if entity_partial_pcts else 0.0
            pct_partial_drops = (avg_partial_pct / n_total_entities) if n_total_entities > 0 else 0.0

            computed_daily_metrics.append({
                "Observation Date": observation_day,
                "Entity Type": entity_label,
                "Total Known Entities": n_total_entities,
                "Absolute Total Drops": absolute_total_drops,
                "Total Drops %": round(pct_total_drops, 2),
                "Absolute Partial Drops": absolute_partial_drops,
                "Partial Drops %": round(pct_partial_drops, 4)  # Kept 4 decimals as double division scales down values significantly
            })

    df_daily_matrix = pd.DataFrame(computed_daily_metrics)
    if df_daily_matrix.empty:
        print(f"[ENTITY-DROP-ERROR] Core metric matrix is empty for context: {context_label}")
        return None

    color_palette = {
        "Family ID": {"total": "#d90429", "partial": "#f77f00"},
        "Complete IP": {"total": "#003049", "partial": "#669bbc"},
        "/24 Subnet": {"total": "#2a9d8f", "partial": "#e9c46a"}
    }
    entity_types = df_daily_matrix["Entity Type"].unique()

    # -------------------------------------------------------------------------
    # PLOT 1: ABSOLUTE COUNTS PROGRESSION
    # -------------------------------------------------------------------------
    plt.figure(figsize=(14, 7))

    for ent_type in entity_types:
        sub_df = df_daily_matrix[df_daily_matrix["Entity Type"] == ent_type]
        c_tot = color_palette.get(ent_type, {}).get("total", "red")
        c_part = color_palette.get(ent_type, {}).get("partial", "orange")

        plt.plot(sub_df["Observation Date"], sub_df["Absolute Total Drops"],
                 marker='o', linewidth=2.2, color=c_tot, label=f'{ent_type} - Absolute Total Drops')
        plt.plot(sub_df["Observation Date"], sub_df["Absolute Partial Drops"],
                 marker='x', linestyle='--', linewidth=1.8, color=c_part, label=f'{ent_type} - Absolute Partial Drops')

        for x, y in zip(sub_df["Observation Date"], sub_df["Absolute Total Drops"]):
            if y > 0:
                plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, 6), ha='center', fontsize=8, fontweight='bold')
        for x, y in zip(sub_df["Observation Date"], sub_df["Absolute Partial Drops"]):
            if y > 0:
                plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, -10), ha='center', fontsize=8)

    plt.title(f"Tor v3 HSDir Per-Entity Accumulated Absolute Drops ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Absolute Drop Event Count (Daily Sum)")
    plt.xticks(rotation=45)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_per_entity_absolute_drops.png")
    plt.close()

    # -------------------------------------------------------------------------
    # PLOT 2: PERCENTAGE PROGRESSION
    # -------------------------------------------------------------------------
    plt.figure(figsize=(14, 7))

    for ent_type in entity_types:
        sub_df = df_daily_matrix[df_daily_matrix["Entity Type"] == ent_type]
        c_tot = color_palette.get(ent_type, {}).get("total", "red")
        c_part = color_palette.get(ent_type, {}).get("partial", "orange")

        plt.plot(sub_df["Observation Date"], sub_df["Total Drops %"],
                 marker='o', linewidth=2.2, color=c_tot, label=f'{ent_type} - Total Drops %')
        plt.plot(sub_df["Observation Date"], sub_df["Partial Drops %"],
                 marker='x', linestyle='--', linewidth=1.8, color=c_part, label=f'{ent_type} - Partial Drops %')

        for x, y in zip(sub_df["Observation Date"], sub_df["Total Drops %"]):
            if y > 0:
                plt.annotate(f"{y:.2f}%", (x, y), textcoords="offset points", xytext=(0, 6), ha='center', fontsize=8, fontweight='bold')
        for x, y in zip(sub_df["Observation Date"], sub_df["Partial Drops %"]):
            if y > 0:
                plt.annotate(f"{y:.2f}%", (x, y), textcoords="offset points", xytext=(0, -10), ha='center', fontsize=8)

    max_pct = max(df_daily_matrix["Total Drops %"].max(), df_daily_matrix["Partial Drops %"].max())
    plt.ylim(0, max(max_pct * 1.15 + 1, 5))

    plt.title(f"Tor v3 HSDir Per-Entity Accumulated Percentage Progression ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Percentage of Known Entities (%)")
    plt.xticks(rotation=45)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_per_entity_percentage_progression.png")
    plt.close()

    df_daily_matrix.to_csv(f"{output_dir}/{context_label}_per_entity_averaged_drop_matrix.csv", index=False)

    print(f"[ENTITY-DROP-INFO] Per-entity drop analysis successfully executed for context: '{context_label}'")
    return df_daily_matrix

def entity_drop_analysis_per_entity(df, context_label):
    """
    Wrapper function matching hsdir-analysis-v3.py standard. Handles sub-population segmentation if applicable.
    """
    print(f"=== PROCESSING {context_label.upper()} PER-ENTITY DROP ANALYSIS ===")
    if df is None or df.empty:
        print(f"[ENTITY-DROP-ERROR] Missing input data layout for context '{context_label}'.")
        return None

    global_reporting_matrix = compute_entity_drop_analysis_per_entity(df, context_label)

    if context_label in ["tracked_targets", "rotated_tracked_targets"] and "service_type" in df.columns:
        unique_services = df["service_type"].dropna().unique()
        unique_services = [s for s in unique_services if s not in ['', 'nan', 'None', None]]

        for service in unique_services:
            print(f"    --> Isolating per-entity drop analysis for hidden service type: {service}")
            sub_population_df = df[df["service_type"] == service]
            if not sub_population_df.empty:
                segmented_label = f"{context_label}_{str(service).lower()}"
                compute_entity_drop_analysis_per_entity(sub_population_df, segmented_label)

    return global_reporting_matrix
