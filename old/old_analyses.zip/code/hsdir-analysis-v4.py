"""
hsdir-analysis-v4.py
====================
Advanced Statistical & Topological Pipeline for Tor HSDir Analysis.
Includes circular statistics, graph-based effective family resolution, 
Kaplan-Meier survival estimation, Markov churn modeling, spatial entropy, 
Rayleigh uniformity testing, KS-tests, and publication-ready plots.
"""

import json
import math
import os
import ipaddress
from collections import defaultdict

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as stats
import networkx as nx


# ----------------------------------------------------------------------
# 1. Extraction and Validation Functions
# ----------------------------------------------------------------------

def extract_telemetry(target_filename):
    output_csv = target_filename.replace('.jsonl', '.csv')    
    consolidated_records = []
    
    with open(target_filename, 'r') as source_file:
        for index, text_line in enumerate(source_file):
            if not text_line.strip():
                continue
            try:
                parsed_json = json.loads(text_line)
            except json.JSONDecodeError as err:
                print(f"[EXTRACT-ERROR] Malformed line entry skipped {index}: {err}")
                continue

            base_timestamp = parsed_json.get("timestamp")
            captured_onion = parsed_json.get("onion_address", None)
            
            nested_array_key = None
            if "relays" in parsed_json:
                nested_array_key = "relays"
                
            if nested_array_key:
                sub_records = parsed_json.get(nested_array_key, [])
                for entry in sub_records:
                    flattened_item = entry.copy()
                    flattened_item["timestamp"] = base_timestamp
                    if captured_onion:
                        flattened_item["onion_address"] = captured_onion
                    consolidated_records.append(flattened_item)
            else:
                consolidated_records.append(parsed_json)
                
    if not consolidated_records:
        print(f"[EXTRACT-WARNING] No usable records extracted from {target_filename}.")
        return False
        
    df_processed = pd.DataFrame(consolidated_records)
    
    if "timestamp" in df_processed.columns:
        parsed_datetimes = pd.to_datetime(df_processed["timestamp"], errors='coerce')
        df_processed["date"] = parsed_datetimes.dt.strftime("%m-%d")
        df_processed["hour"] = parsed_datetimes.dt.strftime("%H:%M")
        
    if "or_port" in df_processed.columns:
        df_processed.drop(columns=["or_port"], inplace=True, errors='ignore')
        
    for technical_flag in ["Fast", "HSDir", "Stable", "Valid"]:
        if "flags" in df_processed.columns:
            df_processed[technical_flag] = df_processed["flags"].apply(lambda val: 1 if (isinstance(val, list) and technical_flag in val) or (isinstance(val, str) and technical_flag in val) else 0)
        else:
            df_processed[technical_flag] = 0
            
    if "flags" in df_processed.columns:
        df_processed.drop(columns=["flags"], inplace=True, errors='ignore')

    if "declared_family_id" in df_processed.columns:
        df_processed["declared_family_id"] = df_processed["declared_family_id"].astype(str).replace(['nan', 'NaN', 'None', '0', '0.0', '', ' '], 'None')
        df_processed["declared_family_id"] = df_processed["declared_family_id"].fillna('None')
    else:
        df_processed["declared_family_id"] = 'None'

    if "declared_family" in df_processed.columns:
        def clean_initial_family(val):
            if isinstance(val, (list, tuple, np.ndarray)):
                return list(val)
                
            if pd.isna(val) or val is None or val in ['None', 'nan', 'NaN', '[]', '', ' ']:
                return []
                
            if isinstance(val, str):
                val_stripped = val.strip()
                if val_stripped.startswith('[') and val_stripped.endswith(']'):
                    try:
                        parsed = ast.literal_eval(val_stripped)
                        if isinstance(parsed, list):
                            return parsed
                    except Exception:
                        pass
                return [val_stripped]
            return []
            
        df_processed["declared_family"] = df_processed["declared_family"].apply(clean_initial_family)
    else:
        df_processed["declared_family"] = [[] for _ in range(len(df_processed))]
        
    for col in df_processed.columns:
        if col == "declared_family":
            continue
        if df_processed[col].dtype == 'object':
            df_processed[col] = df_processed[col].astype(str).replace(['nan', '0', '0.0', '', ' '], 'None')
        elif pd.api.types.is_numeric_dtype(df_processed[col]):
            df_processed[col] = df_processed[col].fillna(0)
        else:
            df_processed[col] = df_processed[col].fillna('None')
    
    df_processed.to_csv(output_csv, index=False)
    return True


def validate_sort_data(csv_path):
    """
    Validates timestamps, sorts chronologically, and computes circular distance metrics.
    Creates 'hsdir_angle_rad', 'hsdir_norm_pos', and circular distance features.
    """

    if not os.path.exists(csv_path):
        print(f"[VERIFY-ERROR] Target file unavailable: {csv_path}")
        return None
    
    df = pd.read_csv(csv_path, low_memory=False)
    
    for col in df.columns:
        if col in ['ip_address', 'fingerprint', 'status', 'onion_address', 'action', 'reason', 'declared_family_id', 'timestamp_dropped', 'service_type']:
            df[col] = df[col].fillna('None').astype(str)
            df[col] = df[col].replace(['nan', 'NaN', 'None', ''], 'None')
            
    if "declared_family" in df.columns:
        def parse_csv_family_list(val):
            if isinstance(val, (list, tuple, np.ndarray)):
                return list(val)
            if pd.isna(val) or val is None:
                return []
            val_str = str(val).strip()
            if val_str in ['None', 'nan', 'NaN', '', '[]']:
                return []
            if val_str.startswith('[') and val_str.endswith(']'):
                try:
                    parsed = ast.literal_eval(val_str)
                    if isinstance(parsed, list):
                        return parsed
                except Exception:
                    pass
            return [val_str]
        df["declared_family"] = df["declared_family"].apply(parse_csv_family_list)
    else:
        df["declared_family"] = [[] for _ in range(len(df))]

    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df = df.sort_values('timestamp').reset_index(drop=True)
        
    if 'hsdir_index_hrt_100' in df.columns:
        df['hsdir_index_hrt_100'] = pd.to_numeric(df['hsdir_index_hrt_100'], errors='coerce')
        df['hsdir_norm_pos'] = df['hsdir_index_hrt_100'] / 100.0
        df['hsdir_angle_rad'] = df['hsdir_norm_pos'] * 2.0 * math.pi
        # Circular distance from ring origin (0.0 / 100%)
        df['hsdir_circ_dist_origin'] = df['hsdir_norm_pos'].apply(
            lambda p: min(p, 1.0 - p) if pd.notnull(p) else np.nan
        )
    
    sort_columns = []
    if "date" in df.columns:
        sort_columns.append("date")
    if "hour" in df.columns:
        sort_columns.append("hour")
    if "fingerprint" in df.columns:
        sort_columns.append("fingerprint")
        
    if sort_columns:
        df.sort_values(by=sort_columns, inplace=True)
        df.reset_index(drop=True, inplace=True)
        
    if "date" in df.columns and not df.empty:
        unique_calendar_dates = df["date"].unique()
        unique_calendar_dates = [d for d in unique_calendar_dates if d not in ['', 'nan', 'None']]
        
        date_normalization_map = {date_str: f"Day {idx + 1}" for idx, date_str in enumerate(unique_calendar_dates)}
        df["date"] = df["date"].map(date_normalization_map).fillna(df["date"])
        
    return df

# ----------------------------------------------------------------------
# 2. Visual & Geometric Analyses
# ----------------------------------------------------------------------

def plot_circular_polar_scatter(df_events: pd.DataFrame, df_snapshots: pd.DataFrame, output_path: str = 'polar_scatter.png'):
    """
    Generates a Circular / Polar Scatter Plot showing the spatial distribution
    of HSDir nodes and ring events on the modulo 2^256 circular ring table.
    """
    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection='polar')

    if not df_snapshots.empty and 'hsdir_angle_rad' in df_snapshots.columns:
        angles_snap = df_snapshots['hsdir_angle_rad'].dropna().values
        r_snap = np.ones_like(angles_snap)
        ax.scatter(angles_snap, r_snap, c='blue', alpha=0.3, s=20, label='Consensus HSDirs')

    if not df_events.empty and 'hsdir_angle_rad' in df_events.columns:
        angles_ev = df_events['hsdir_angle_rad'].dropna().values
        r_ev = np.full_like(angles_ev, 0.7)
        ax.scatter(angles_ev, r_ev, c='red', alpha=0.6, s=35, marker='^', label='Event Probes')

    ax.set_theta_zero_location('N')
    ax.set_theta_direction(-1)
    ax.set_title('Tor Hash Ring Table (HRT) Spatial Distribution (Polar)', va='bottom', fontsize=14)
    ax.legend(loc='lower right')
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    return output_path


# ----------------------------------------------------------------------
# 3. Topology & Family Resolution
# ----------------------------------------------------------------------

def analyze_effective_families(df_snapshots: pd.DataFrame):
    """
    Computes Effective Families using mutual declaration graph connectivity.
    Enforces Tor specification rule: edge exists iff B in family(A) and A in family(B).
    Annotates df_snapshots with 'effective_family_id'.
    """
    if df_snapshots.empty or 'fingerprint' not in df_snapshots.columns:
        return df_snapshots, {}

    family_map = {}
    for _, row in df_snapshots.iterrows():
        fp = row.get('fingerprint')
        raw_fam = row.get('declared_family')
        if pd.isna(fp):
            continue
        if isinstance(raw_fam, list):
            family_map[fp] = set(raw_fam)
        elif isinstance(raw_fam, str):
            family_map[fp] = set(raw_fam.replace('$', '').split(','))
        else:
            family_map[fp] = set()

    G = nx.Graph()
    for fp in family_map:
        G.add_node(fp)

    for fp_a, declared_set in family_map.items():
        for fp_b in declared_set:
            if fp_b in family_map and fp_a in family_map[fp_b]:
                G.add_edge(fp_a, fp_b)

    components = list(nx.connected_components(G))
    effective_fam_mapping = {}
    for idx, comp in enumerate(components):
        fam_id = f"EFF_FAM_{idx:04d}"
        for fp in comp:
            effective_fam_mapping[fp] = fam_id

    df_snapshots['declared_family_id'] = df_snapshots['fingerprint'].map(effective_fam_mapping)
    return df_snapshots, effective_fam_mapping


# ----------------------------------------------------------------------
# 4. Lifecycle & Churn Modeling
# ----------------------------------------------------------------------

def analyze_lifecycle_state_machine(df_snapshots: pd.DataFrame):
    """
    Tracks state transitions (ACTIVE_IN_RING -> ABSENT -> DROPPED) for each relay,
    accounting for observation time boundaries and right-censoring.
    """
    if df_snapshots.empty or 'fingerprint' not in df_snapshots.columns:
        return {}

    timestamps = sorted(df_snapshots['timestamp'].unique())
    max_time = max(timestamps) if timestamps else None
    
    relay_lifecycles = {}
    grouped = df_snapshots.groupby('fingerprint')

    for fp, group in grouped:
        times = group['timestamp'].sort_values().tolist()
        first_seen = min(times)
        last_seen = max(times)
        total_appearances = len(times)
        
        is_censored = (last_seen == max_time)
        
        if len(times) > 1:
            gaps = [(times[i+1] - times[i]).total_seconds() / 3600.0 for i in range(len(times)-1)]
            max_gap_hours = max(gaps)
        else:
            max_gap_hours = 0.0

        state = "ACTIVE_CENSORED" if is_censored else "DROPPED"

        relay_lifecycles[fp] = {
            'first_seen': first_seen,
            'last_seen': last_seen,
            'total_hours_active': total_appearances,
            'max_absence_gap_hours': max_gap_hours,
            'is_censored': is_censored,
            'final_state': state
        }

    return relay_lifecycles


def plot_kaplan_meier_survival(df_snapshots: pd.DataFrame, output_path: str = 'survival_curves.png'):
    """
    Calculates non-parametric Kaplan-Meier survival probabilities S(t) for HSDir relay tenure,
    handling right-censored data accurately.
    """
    lifecycles = analyze_lifecycle_state_machine(df_snapshots)
    if not lifecycles:
        return output_path

    durations = []
    events = []

    for fp, metrics in lifecycles.items():
        dur = metrics['total_hours_active']
        is_censored = metrics['is_censored']
        durations.append(dur)
        events.append(0 if is_censored else 1)

    durations = np.array(durations)
    events = np.array(events)

    unique_times = np.sort(np.unique(durations))
    survival_prob = 1.0
    km_times = [0]
    km_probs = [1.0]

    for t in unique_times:
        if t == 0:
            continue
        d_i = np.sum((durations == t) & (events == 1))
        n_i = np.sum(durations >= t)

        if n_i > 0:
            survival_prob *= (1.0 - d_i / n_i)
        
        km_times.append(t)
        km_probs.append(survival_prob)

    plt.figure(figsize=(9, 6))
    plt.step(km_times, km_probs, where='post', color='darkblue', linewidth=2, label='HSDir Uptime Survival S(t)')
    plt.title('Kaplan-Meier Survival Function for HSDir Uptime Tenure', fontsize=14)
    plt.xlabel('Active Hours (t)', fontsize=12)
    plt.ylabel('Survival Probability S(t)', fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    return output_path


def analyze_markov_churn(df_snapshots: pd.DataFrame):
    """
    Constructs a 2-State Discrete Time Markov Chain (Active, Absent) transition matrix
    to estimate consensus state transition probabilities.
    """
    if df_snapshots.empty or 'fingerprint' not in df_snapshots.columns:
        return np.zeros((2, 2))

    timestamps = sorted(df_snapshots['timestamp'].unique())
    if len(timestamps) < 2:
        return np.zeros((2, 2))

    df_snapshots['present'] = 1
    presence_matrix = df_snapshots.pivot_table(
        index='timestamp', columns='fingerprint', values='present', fill_value=0
    )

    trans_counts = np.zeros((2, 2))
    mat = presence_matrix.values
    for t in range(mat.shape[0] - 1):
        s_curr = mat[t, :]
        s_next = mat[t+1, :]
        s_curr = s_curr.astype(int)
        s_next = s_next.astype(int)
        for i in range(len(s_curr)):
            trans_counts[s_curr[i], s_next[i]] += 1

    row_sums = trans_counts.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1.0
    transition_matrix = trans_counts / row_sums

    return transition_matrix


# ----------------------------------------------------------------------
# 5. Infrastructure & Entropy Analysis
# ----------------------------------------------------------------------

def analyze_spatial_entropy_subnets(df_snapshots: pd.DataFrame):
    """
    Calculates Shannon Spatial Entropy across /24 and /16 IP subnets
    to evaluate operator infrastructure concentration.
    H(X) = -sum(p_i * log2(p_i))
    """
    if df_snapshots.empty or 'ip_address' not in df_snapshots.columns:
        return {'entropy_subnet_24': 0.0, 'entropy_subnet_16': 0.0, 'unique_subnets_24': 0, 'unique_subnets_16': 0}

    subnets_24 = []
    subnets_16 = []

    for ip in df_snapshots['ip_address'].dropna():
        try:
            net24 = str(ipaddress.ip_network(f"{ip}/24", strict=False))
            net16 = str(ipaddress.ip_network(f"{ip}/16", strict=False))
            subnets_24.append(net24)
            subnets_16.append(net16)
        except ValueError:
            continue

    def calculate_shannon_entropy(labels):
        if not labels:
            return 0.0
        counts = pd.Series(labels).value_counts()
        probs = counts / len(labels)
        return -np.sum(probs * np.log2(probs))

    return {
        'entropy_subnet_24': calculate_shannon_entropy(subnets_24),
        'entropy_subnet_16': calculate_shannon_entropy(subnets_16),
        'unique_subnets_24': len(set(subnets_24)),
        'unique_subnets_16': len(set(subnets_16))
    }


def calculate_gini_coefficient(df_snapshots: pd.DataFrame, df_events: pd.DataFrame = None):
    """
    Calculates Gini Coefficient (G) of ring control inequality across effective families.
    G = sum_i sum_j |x_i - x_j| / (2 * n^2 * mean(x))
    """
    if df_snapshots.empty:
        return 0.0

    if 'declared_family_id' not in df_snapshots.columns:
        df_snapshots, _ = analyze_effective_families(df_snapshots)

    family_counts = df_snapshots['declared_family_id'].value_counts().values
    if len(family_counts) == 0:
        return 0.0

    x = np.sort(family_counts)
    n = len(x)
    mean_x = np.mean(x)
    if mean_x == 0:
        return 0.0

    gini = (2.0 * np.sum(np.arange(1, n + 1) * x)) / (n * np.sum(x)) - (n + 1.0) / n
    return float(gini)


# ----------------------------------------------------------------------
# 6. Sybil Detection & Clustering
# ----------------------------------------------------------------------

def analyze_cooccurrence_clustering(df_snapshots: pd.DataFrame):
    """
    Detects undeclared Sybil clusters using Network Community Detection
    based on co-located subnets (/24) and synchronized churn patterns.
    """
    if df_snapshots.empty or 'ip_address' not in df_snapshots.columns:
        return []

    fp_subnet = {}
    for _, row in df_snapshots.iterrows():
        fp = row.get('fingerprint')
        ip = row.get('ip_address')
        if pd.notnull(fp) and pd.notnull(ip):
            try:
                fp_subnet[fp] = str(ipaddress.ip_network(f"{ip}/24", strict=False))
            except ValueError:
                pass

    G = nx.Graph()
    for fp in fp_subnet:
        G.add_node(fp)

    subnet_groups = defaultdict(list)
    for fp, subnet in fp_subnet.items():
        subnet_groups[subnet].append(fp)

    for subnet, fps in subnet_groups.items():
        if len(fps) > 1:
            for i in range(len(fps)):
                for j in range(i + 1, len(fps)):
                    G.add_edge(fps[i], fps[j], weight=1.0)

    communities = list(nx.community.greedy_modularity_communities(G))
    clusters = [list(c) for c in communities if len(c) > 1]
    return clusters


# ----------------------------------------------------------------------
# 7. Spatial Point Process & Uniformity Tests
# ----------------------------------------------------------------------

def analyze_rayleigh_uniformity(df_snapshots: pd.DataFrame):
    """
    Conducts Rayleigh Test for Uniformity on circular ring positions (angles in radians).
    H0: HSDirs are uniformly distributed around the ring.
    H1: HSDirs exhibit non-uniform clustering.
    """
    if df_snapshots.empty or 'hsdir_angle_rad' not in df_snapshots.columns:
        return {'n': 0, 'R_bar': 0.0, 'z_stat': 0.0, 'p_value': 1.0, 'is_uniform': True}

    angles = df_snapshots['hsdir_angle_rad'].dropna().values
    n = len(angles)
    if n == 0:
        return {'n': 0, 'R_bar': 0.0, 'z_stat': 0.0, 'p_value': 1.0, 'is_uniform': True}

    C = np.sum(np.cos(angles))
    S = np.sum(np.sin(angles))
    R = math.sqrt(C**2 + S**2)
    R_bar = R / n
    z = n * (R_bar**2)

    p_value = math.exp(-z) * (1.0 + (2.0 * z - z**2) / (4.0 * n))
    p_value = min(max(p_value, 0.0), 1.0)

    return {
        'n': int(n),
        'R_bar': float(R_bar),
        'z_stat': float(z),
        'p_value': float(p_value),
        'is_uniform': bool(p_value > 0.05)
    }


def analyze_nearest_neighbor_spacing(df_snapshots: pd.DataFrame):
    """
    Computes Nearest-Neighbor Ring Spacings on S^1 modulo 2pi
    and compares observed spacing variance against Poisson point process expectation.
    """
    if df_snapshots.empty or 'hsdir_angle_rad' not in df_snapshots.columns:
        return {}

    angles = np.sort(df_snapshots['hsdir_angle_rad'].dropna().unique())
    n = len(angles)
    if n < 2:
        return {}

    spacings = []
    for i in range(n - 1):
        spacings.append(angles[i+1] - angles[i])
    spacings.append((2.0 * math.pi + angles[0]) - angles[-1])

    spacings = np.array(spacings)
    mean_spacing = np.mean(spacings)
    var_spacing = np.var(spacings)
    expected_var = (2.0 * math.pi / n)**2

    return {
        'num_nodes': int(n),
        'mean_spacing_rad': float(mean_spacing),
        'observed_variance': float(var_spacing),
        'poisson_expected_variance': float(expected_var),
        'clustering_index': float(var_spacing / expected_var) if expected_var > 0 else 1.0
    }


# ----------------------------------------------------------------------
# 8. Distributional Comparison & Visualization
# ----------------------------------------------------------------------

def analyze_ks_test(df_events: pd.DataFrame, df_snapshots: pd.DataFrame):
    """
    Conducts Two-Sample Kolmogorov-Smirnov Test comparing ring position distributions
    between probed event targets and the global consensus population.
    """
    if df_events.empty or df_snapshots.empty:
        return {'ks_statistic': 0.0, 'p_value': 1.0, 'significant_difference': False}

    if 'hsdir_norm_pos' not in df_events.columns or 'hsdir_norm_pos' not in df_snapshots.columns:
        return {'ks_statistic': 0.0, 'p_value': 1.0, 'significant_difference': False}

    s1 = df_events['hsdir_norm_pos'].dropna().values
    s2 = df_snapshots['hsdir_norm_pos'].dropna().values

    if len(s1) == 0 or len(s2) == 0:
        return {'ks_statistic': 0.0, 'p_value': 1.0, 'significant_difference': False}

    ks_stat, p_val = stats.ks_2samp(s1, s2)
    return {
        'ks_statistic': float(ks_stat),
        'p_value': float(p_val),
        'significant_difference': bool(p_val < 0.05)
    }


def plot_empirical_cdf(df_events: pd.DataFrame, df_snapshots: pd.DataFrame, output_path: str = 'ecdf_plot.png'):
    """
    Generates Empirical Cumulative Distribution Function (ECDF) curves
    comparing target distance/position distributions.
    """
    plt.figure(figsize=(9, 6))

    if not df_snapshots.empty and 'hsdir_norm_pos' in df_snapshots.columns:
        snap_data = np.sort(df_snapshots['hsdir_norm_pos'].dropna().values)
        if len(snap_data) > 0:
            y_snap = np.arange(1, len(snap_data) + 1) / len(snap_data)
            plt.plot(snap_data, y_snap, label='Consensus HSDirs ECDF', color='blue', linewidth=2)

    if not df_events.empty and 'hsdir_norm_pos' in df_events.columns:
        ev_data = np.sort(df_events['hsdir_norm_pos'].dropna().values)
        if len(ev_data) > 0:
            y_ev = np.arange(1, len(ev_data) + 1) / len(ev_data)
            plt.plot(ev_data, y_ev, label='Event Probes ECDF', color='red', linestyle='--', linewidth=2)

    plt.title('Empirical Cumulative Distribution Function (ECDF) Comparison', fontsize=14)
    plt.xlabel('Normalized Ring Position [0.0, 1.0]', fontsize=12)
    plt.ylabel('Empirical Cumulative Probability', fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    return output_path


def plot_operator_network_graph(df_snapshots: pd.DataFrame, output_path: str = 'operator_network.png'):
    """
    Renders an Operator Network Graph showing effective family connections
    and shared infrastructure subnets across relays.
    """
    if df_snapshots.empty:
        return output_path

    if 'declared_family_id' not in df_snapshots.columns:
        df_snapshots, _ = analyze_effective_families(df_snapshots)

    G = nx.Graph()

    fam_groups = df_snapshots.groupby('declared_family_id')
    for fam_id, group in fam_groups:
        fps = group['fingerprint'].dropna().unique().tolist()
        if len(fps) > 1:
            for i in range(len(fps)):
                G.add_node(fps[i], family=fam_id)
                for j in range(i + 1, len(fps)):
                    G.add_edge(fps[i], fps[j])

    plt.figure(figsize=(10, 10))
    if G.number_of_nodes() > 0:
        pos = nx.spring_layout(G, k=0.15, iterations=20)
        nx.draw_networkx_nodes(G, pos, node_size=40, node_color='skyblue', alpha=0.8)
        nx.draw_networkx_edges(G, pos, alpha=0.3, edge_color='gray')
        plt.title('HSDir Effective Family & Infrastructure Network Topology', fontsize=14)
    else:
        plt.text(0.5, 0.5, 'No Multi-Node Families Detected', horizontalalignment='center', verticalalignment='center')
        plt.title('HSDir Network Topology', fontsize=14)

    plt.axis('off')
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    return output_path


# ----------------------------------------------------------------------
# Full Orchestrator Pipeline
# ----------------------------------------------------------------------

def run_full_pipeline(events_file: str, snapshots_file: str, output_dir: str = './results'):
    """
    Executes the entire end-to-end HSDir analysis pipeline and outputs summaries.
    """
    os.makedirs(output_dir, exist_ok=True)
    
    print("[+] Extracting telemetry data...")
    # df_events = extract_telemetry(events_file)
    # df_snapshots = extract_telemetry(snapshots_file)

    print("[+] Validating, sorting, and computing circular distance fields...")
    df_snapshots = validate_sort_data("rotated_tracked_hsdir_consensus_snapshots.csv")
    df_events = validate_sort_data("hsdir_ring_events.csv")

    print("[+] Resolving mutual effective family graph...")
    df_snapshots, fam_map = analyze_effective_families(df_snapshots)

    print("[+] Generating polar spatial scatter plot...")
    plot_circular_polar_scatter(df_events, df_snapshots, os.path.join(output_dir, 'polar_scatter.png'))

    print("[+] Executing lifecycle state machine analysis...")
    lifecycles = analyze_lifecycle_state_machine(df_snapshots)

    print("[+] Plotting Kaplan-Meier uptime survival curves...")
    plot_kaplan_meier_survival(df_snapshots, os.path.join(output_dir, 'survival_curves.png'))

    print("[+] Modeling Markov chain churn transition matrix...")
    markov_mat = analyze_markov_churn(df_snapshots)

    print("[+] Computing spatial entropy across IP subnets...")
    entropy_results = analyze_spatial_entropy_subnets(df_snapshots)

    print("[+] Calculating Gini coefficient of ring control...")
    gini_score = calculate_gini_coefficient(df_snapshots, df_events)

    print("[+] Running co-occurrence community clustering...")
    clusters = analyze_cooccurrence_clustering(df_snapshots)

    print("[+] Performing Rayleigh test for circular uniformity...")
    rayleigh_res = analyze_rayleigh_uniformity(df_snapshots)

    print("[+] Calculating nearest-neighbor ring spacing statistics...")
    spacing_res = analyze_nearest_neighbor_spacing(df_snapshots)

    print("[+] Conducting Two-Sample Kolmogorov-Smirnov test...")
    ks_res = analyze_ks_test(df_events, df_snapshots)

    print("[+] Plotting Empirical CDF curves...")
    plot_empirical_cdf(df_events, df_snapshots, os.path.join(output_dir, 'ecdf_plot.png'))

    print("[+] Rendering operator network graph...")
    plot_operator_network_graph(df_snapshots, os.path.join(output_dir, 'operator_network.png'))

    print("\n================ PIPELINE SUMMARY RESULTS ================")
    print(f"Total Events Parsed:              {len(df_events)}")
    print(f"Total Snapshot Records Parsed:    {len(df_snapshots)}")
    print(f"Effective Families Resolved:       {len(set(fam_map.values()))}")
    print(f"Subnet /24 Shannon Entropy:        {entropy_results.get('entropy_subnet_24', 0.0):.4f}")
    print(f"Gini Control Inequality Index:     {gini_score:.4f}")
    print(f"Rayleigh Uniformity p-value:       {rayleigh_res.get('p_value', 1.0):.4e}")
    print(f"KS-Test Statistic (p-value):       {ks_res.get('ks_statistic', 0.0):.4f} (p={ks_res.get('p_value', 1.0):.4e})")
    print(f"Detected Sybil Clusters (>1 node): {len(clusters)}")
    print(f"Markov Transition Matrix (Absent/Active):\n{markov_mat}")
    print("==========================================================")


if __name__ == '__main__':
    EVENTS_FILE = "hsdir_ring_events.jsonl"
    SNAPSHOTS_FILE = "rotated_tracked_hsdir_consensus_snapshots.jsonl"
    
    run_full_pipeline(EVENTS_FILE, SNAPSHOTS_FILE)