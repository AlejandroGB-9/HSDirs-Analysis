def compute_chronological_uptime(df_slice, context_label):
    """
    Computes daily chronological uptime distributions (Mean, Median, Percentiles)
    for HSDir nodes identified by 'fingerprint' and correlates them with daily
    stability churn metrics (New, Disappeared, and Reconnected HSDirs).
    """
    os.makedirs("analysis-results/chronological_uptime", exist_ok=True)

    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    if "hour" not in df_slice.columns or "fingerprint" not in df_slice.columns or "date" not in df_slice.columns:
        print(f"[CHRONO-UPTIME-ERROR] Missing critical structural fields ('date', 'hour', or 'fingerprint') for label: {context_label}")
        return None

    df_working = df_slice.copy()

    # -------------------------------------------------------------------------
    # 1. GHOST NODE FILTERING (consecutive_hourly_absences <= 1)
    # -------------------------------------------------------------------------
    if "consecutive_hourly_absences" in df_working.columns:
        df_working = df_working[
            df_working["consecutive_hourly_absences"].isna() | 
            (df_working["consecutive_hourly_absences"] <= 1)
        ]

    df_working = df_working[
        df_working['fingerprint'].notna() & (~df_working['fingerprint'].isin(['None', '', 'nan']))
    ]

    if df_working.empty:
        print(f"[CHRN-UPTIME-WARNING] No valid records after filtering for context: {context_label}")
        return None
    
    # Hour numerical normalization
    if df_working["hour"].dtype == object or isinstance(df_working["hour"].iloc[0], str):
        if df_working["hour"].astype(str).str.contains(":").any():
            hour_parts = df_working["hour"].astype(str).str.split(":", expand=True)
            df_working["hour_num"] = hour_parts[0].astype(int) + hour_parts[1].astype(int) / 60.0
        else:
            df_working["hour_num"] = pd.to_numeric(df_working["hour"], errors='coerce').fillna(0)
    else:
        df_working["hour_num"] = df_working["hour"].astype(float)

    unique_days = [d for d in df_working["date"].unique() if d not in ['', 'None', None] and pd.notna(d)]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    # -------------------------------------------------------------------------
    # 2. CHRONOLOGICAL STABILITY & CHURN TRACKING (HOURLY TRANSITION LOGIC)
    # -------------------------------------------------------------------------
    # Sort dataset chronologically by date and hour_num
    df_working = df_working.sort_values(by=["date", "hour_num"])
    
    # Extract unique hourly snapshot timestamps across the whole observation timeline
    snapshot_groups = df_working.groupby(["date", "hour_num"], sort=False)
    
    active_nodes_per_snap = {}
    all_nodes_per_snap = {}
    snapshot_order = []

    for (day, hr), group in snapshot_groups:
        snap_key = (day, hr)
        snapshot_order.append(snap_key)
        
        # Active nodes are those explicitly marked as ACTIVE_IN_RING or None (default active state)
        active_mask = group.get("status", "ACTIVE_IN_RING").fillna("ACTIVE_IN_RING").isin(["ACTIVE_IN_RING", "None"])
        active_fps = set(group[active_mask]["fingerprint"])
        all_fps = set(group["fingerprint"])
        
        active_nodes_per_snap[snap_key] = active_fps
        all_nodes_per_snap[snap_key] = all_fps

    # Track churn dynamics chronologically
    seen_fingerprints = set()
    prev_active_fps = set()
    prev_all_fps = set()
    
    daily_churn = {d: {"new": 0, "disappeared": 0, "reconnected": 0} for d in unique_days_sorted}

    for idx, snap_key in enumerate(snapshot_order):
        day, hr = snap_key
        curr_active = active_nodes_per_snap[snap_key]
        curr_all = all_nodes_per_snap[snap_key]

        if idx > 0:
            # A. DISAPPEARANCE LOGIC:
            # - If a node was ACTIVE_IN_RING in previous hour, and in current hour status != ACTIVE_IN_RING (or absent), count as disappearance.
            # - If a node was NOT ACTIVE_IN_RING in previous hour, and in current hour it is absent/inactive, it is NOT counted again.
            disappeared = prev_active_fps - curr_active
            daily_churn[day]["disappeared"] += len(disappeared)

            # B. RECONNECTION LOGIC:
            # - Node was seen previously in history, was NOT ACTIVE_IN_RING in previous hour, and IS ACTIVE_IN_RING in current hour.
            reconnected = (curr_active & seen_fingerprints) - prev_active_fps
            daily_churn[day]["reconnected"] += len(reconnected)

            # C. NEW ARRIVAL LOGIC:
            # - Node is ACTIVE_IN_RING in current hour and has NEVER been seen before in snapshot history.
            new_arrivals = curr_active - seen_fingerprints
            daily_churn[day]["new"] += len(new_arrivals)
        else:
            # First snapshot baseline
            new_arrivals = curr_active
            daily_churn[day]["new"] += len(new_arrivals)

        # Update historical trackers
        seen_fingerprints.update(curr_all)
        prev_active_fps = curr_active
        prev_all_fps = curr_all

    # -------------------------------------------------------------------------
    # 3. DAILY LIFESPAN CALCULATION (GENERAL HSDIR FALLBACK ONLY)
    # -------------------------------------------------------------------------
    computed_metrics = []

    for observation_day in unique_days_sorted:
        day_data = df_working[df_working["date"] == observation_day]
        all_session_durations = []

        # General daily HSDir uptime distribution analysis across fingerprints
        for fp in day_data["fingerprint"].unique():
            if fp in ['None', '', None] or pd.isna(fp):
                continue
            df_fp = day_data[day_data["fingerprint"] == fp].sort_values(by="hour_num")
            
            current_start = None
            current_last = None
            
            for _, row in df_fp.iterrows():
                is_active = row.get("status", "ACTIVE_IN_RING") in ["ACTIVE_IN_RING", "None"]
                has_temporal_gap = (current_last is not None) and (row["hour_num"] - current_last > 2.5)
                
                if is_active and not has_temporal_gap:
                    if current_start is None:
                        current_start = row["hour_num"]
                    current_last = row["hour_num"]
                else:
                    if current_start is not None:
                        duration = max(1.0, current_last - current_start)
                        all_session_durations.append(duration)
                    
                    if is_active:
                        current_start = row["hour_num"]
                        current_last = row["hour_num"]
                    else:
                        current_start = None
                        current_last = None
            
            if current_start is not None:
                duration = max(1.0, current_last - current_start)
                all_session_durations.append(duration)

        total_sessions = len(all_session_durations)
        if total_sessions == 0:
            continue

        durations_arr = np.array(all_session_durations)
        churn_stats = daily_churn.get(observation_day, {"new": 0, "disappeared": 0, "reconnected": 0})

        computed_metrics.append({
            "Observation Date": observation_day,
            "Total Sessions": total_sessions,
            "Mean Lifespan (hrs)": round(float(durations_arr.mean()), 2),
            "P15 Lifespan (hrs)": round(float(np.percentile(durations_arr, 15)), 2),
            "P25 Lifespan (hrs)": round(float(np.percentile(durations_arr, 25)), 2),
            "Median/P50 Lifespan (hrs)": round(float(np.median(durations_arr)), 2),
            "P75 Lifespan (hrs)": round(float(np.percentile(durations_arr, 75)), 2),
            "P85 Lifespan (hrs)": round(float(np.percentile(durations_arr, 85)), 2),
            "P90 Lifespan (hrs)": round(float(np.percentile(durations_arr, 90)), 2),
            "P95 Lifespan (hrs)": round(float(np.percentile(durations_arr, 95)), 2),
            "P99 Lifespan (hrs)": round(float(np.percentile(durations_arr, 99)), 2),
            "Max Lifespan (hrs)": int(durations_arr.max()),
            "Min Lifespan (hrs)": int(durations_arr.min()),
            "Full Uptime (>=20h)": int(np.sum(durations_arr >= 20)),
            "High Uptime (12-19h)": int(np.sum((durations_arr >= 12) & (durations_arr < 20))),
            "Moderate Uptime (6-11h)": int(np.sum((durations_arr >= 6) & (durations_arr < 12))),
            "Low Uptime (<6h)": int(np.sum(durations_arr < 6)),
            # Integrated Stability Metrics
            "New HSDirs": churn_stats["new"],
            "Disappeared HSDirs": churn_stats["disappeared"],
            "Reconnected HSDirs": churn_stats["reconnected"],
            "Net Stability Churn": churn_stats["new"] + churn_stats["reconnected"] - churn_stats["disappeared"]
        })

    df_summary_matrix = pd.DataFrame(computed_metrics)
    if df_summary_matrix.empty:
        print(f"[CHRONO-UPTIME-WARNING] Summary matrix empty for context: {context_label}")
        return None

    # -------------------------------------------------------------------------
    # 4. DUAL-AXIS GRAPH PLOTTING (LIFESPAN + STABILITY CORRELATION)
    # -------------------------------------------------------------------------
    fig, ax1 = plt.subplots(figsize=(15, 7))

    # Primary Y-Axis: Session Lifespan Profile (Hours)
    l1 = ax1.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Mean Lifespan (hrs)"], marker='o', color='purple', linewidth=2, label='Mean Lifespan')
    l2 = ax1.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Median/P50 Lifespan (hrs)"], marker='s', color='teal', linewidth=2, label='Median (P50)')
    l3 = ax1.plot(df_summary_matrix["Observation Date"], df_summary_matrix["P85 Lifespan (hrs)"], marker='^', color='crimson', linewidth=1.5, linestyle='--', label='P85 Upper Percentile')
    l4 = ax1.plot(df_summary_matrix["Observation Date"], df_summary_matrix["P15 Lifespan (hrs)"], marker='v', color='darkgreen', linewidth=1.5, linestyle='--', label='P15 Lower Percentile')

    for x, y in zip(df_summary_matrix["Observation Date"], df_summary_matrix["Mean Lifespan (hrs)"]):
        ax1.annotate(f"{y}h", (x, y), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=8, color='purple', weight='bold')

    ax1.set_xlabel("Observation Timeline", fontsize=11, labelpad=10)
    ax1.set_ylabel("Lifespan Duration (Hours)", fontsize=11, color='black')
    ax1.tick_params(axis='x', rotation=45)
    ax1.grid(True, linestyle=':', alpha=0.5)

    # Secondary Y-Axis: HSDir Stability Churn Dynamics (Node Counts)
    ax2 = ax1.twinx()
    l5 = ax2.plot(df_summary_matrix["Observation Date"], df_summary_matrix["New HSDirs"], marker='*', color='#2ca02c', linewidth=1.5, linestyle='-.', label='New HSDirs')
    l6 = ax2.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Disappeared HSDirs"], marker='x', color='#d62728', linewidth=1.5, linestyle='-.', label='Disappeared HSDirs')
    l7 = ax2.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Reconnected HSDirs"], marker='d', color='#1f77b4', linewidth=1.5, linestyle=':', label='Reconnected HSDirs')

    ax2.set_ylabel("HSDir Stability Transitions (Node Count)", fontsize=11, color='#333333')

    # Combined Unified Legend
    lines = l1 + l2 + l3 + l4 + l5 + l6 + l7
    labels = [l.get_label() for l in lines]
    ax1.legend(lines, labels, loc="upper left", bbox_to_anchor=(0.01, 0.99), framealpha=0.9, fontsize=9)

    plt.title(f"Tor v3 Chronological HSDir Operational Lifespan & Stability Correlation ({context_label.replace('_', ' ').title()})", fontsize=12, pad=15)
    plt.tight_layout()
    plt.savefig(f"analysis-results/chronological_uptime/{context_label}_daily_chronological_uptime.png", dpi=300)
    plt.close()

    # CSV Summary Export
    daily_totals = {"Observation Date": "Overall Average"}
    for col in df_summary_matrix.columns:
        if col != "Observation Date":
            daily_totals[col] = round(df_summary_matrix[col].mean(), 2)

    df_summary_export = pd.concat([df_summary_matrix, pd.DataFrame([daily_totals])], ignore_index=True)
    df_summary_export.to_csv(f"analysis-results/chronological_uptime/{context_label}_daily_chronological_uptime_matrix.csv", index=False)

    print(f"[CHRONO-UPTIME-INFO] Complete chronological matrices and stability percentiles saved under label: '{context_label}'")
    return df_summary_matrix

def compute_chronological_uptime(df_slice, context_label):
    os.makedirs("analysis-results/chronological_uptime", exist_ok=True)
    computed_metrics = []

    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    if "hour" not in df_slice.columns or "fingerprint" not in df_slice.columns:
        print(f"[CHRONO-UPTIME-ERROR] Missing critical structural fields ('hour' or 'fingerprint') for label: {context_label}")
        return None

    df_working = df_slice.copy()

    # -------------------------------------------------------------------------
    # 1. GHOST NODE FILTERING (consecutive_hourly_absences <= 1)
    # -------------------------------------------------------------------------
    if "consecutive_hourly_absences" in df_working.columns:
        df_working = df_working[
            df_working["consecutive_hourly_absences"].isna() | 
            (df_working["consecutive_hourly_absences"] <= 1)
        ]

    df_working = df_working[
        df_working['fingerprint'].notna() & (~df_working['fingerprint'].isin(['None', '', 'nan']))
    ]

    if df_working.empty:
        print(f"[CHRN-UPTIME-WARNING] No valid records after filtering for context: {context_label}")
        return None
    
    # Hour numerical normalization
    if df_working["hour"].dtype == object or isinstance(df_working["hour"].iloc[0], str):
        if df_working["hour"].str.contains(":").any():
            hour_parts = df_working["hour"].str.split(":", expand=True)
            df_working["hour_num"] = hour_parts[0].astype(int) + hour_parts[1].astype(int) / 60.0
        else:
            df_working["hour_num"] = pd.to_numeric(df_working["hour"], errors='coerce').fillna(0)
    else:
        df_working["hour_num"] = df_working["hour"].astype(float)

    # Key identification: onion target field mapping vs general HSDir fallback
    onion_col = None
    if "mapped_onion" in df_working.columns:
        onion_col = "mapped_onion"
    elif "last_known_onion" in df_working.columns:
        onion_col = "last_known_onion"
    elif "onion_address" in df_working.columns:
        onion_col = "onion_address"

    unique_days = [d for d in df_working["date"].unique() if d not in ['', 'None', None]]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    for observation_day in unique_days_sorted:
        day_data = df_working[df_working["date"] == observation_day]
        all_session_durations = []

        if onion_col and day_data[onion_col].nunique() > 0 and (day_data[onion_col] != 'None').any():
            # Grouped execution per onion target and fingerprint
            unique_onions = [o for o in day_data[onion_col].unique() if o not in ['None', '', None]]
            for onion in unique_onions:
                onion_data = day_data[day_data[onion_col] == onion]
                for fp in onion_data["fingerprint"].unique():
                    if fp in ['None', '', None]:
                        continue
                    df_fp = onion_data[onion_data["fingerprint"] == fp].sort_values(by="hour_num")
                    
                    current_start = None
                    current_last = None
                    
                    for _, row in df_fp.iterrows():
                        is_active = row.get("status", "ACTIVE_IN_RING") in ["ACTIVE_IN_RING", "None"]
                        has_temporal_gap = (current_last is not None) and (row["hour_num"] - current_last > 2.5)
                        
                        if is_active and not has_temporal_gap:
                            if current_start is None:
                                current_start = row["hour_num"]
                            current_last = row["hour_num"]
                        else:
                            if current_start is not None:
                                duration = max(1.0, current_last - current_start)
                                all_session_durations.append(duration)
                            
                            if is_active:
                                current_start = row["hour_num"]
                                current_last = row["hour_num"]
                            else:
                                current_start = None
                                current_last = None
                    
                    if current_start is not None:
                        duration = max(1.0, current_last - current_start)
                        all_session_durations.append(duration)
        else:
            # Fallback: General daily HSDir uptime distribution analysis
            for fp in day_data["fingerprint"].unique():
                if fp in ['None', '', None]:
                    continue
                df_fp = day_data[day_data["fingerprint"] == fp].sort_values(by="hour_num")
                
                current_start = None
                current_last = None
                
                for _, row in df_fp.iterrows():
                    is_active = row.get("status", "ACTIVE_IN_RING") in ["ACTIVE_IN_RING", "None"]
                    has_temporal_gap = (current_last is not None) and (row["hour_num"] - current_last > 2.5)
                    
                    if is_active and not has_temporal_gap:
                        if current_start is None:
                            current_start = row["hour_num"]
                        current_last = row["hour_num"]
                    else:
                        if current_start is not None:
                            duration = max(1.0, current_last - current_start)
                            all_session_durations.append(duration)
                        
                        if is_active:
                            current_start = row["hour_num"]
                            current_last = row["hour_num"]
                        else:
                            current_start = None
                            current_last = None
                
                if current_start is not None:
                    duration = max(1.0, current_last - current_start)
                    all_session_durations.append(duration)

        total_sessions = len(all_session_durations)
        if total_sessions == 0:
            continue

        durations_arr = np.array(all_session_durations)

        computed_metrics.append({
            "Observation Date": observation_day,
            "Total Sessions": total_sessions,
            "Mean Lifespan (hrs)": round(float(durations_arr.mean()), 2),
            "P15 Lifespan (hrs)": round(float(np.percentile(durations_arr, 15)), 2),
            "P25 Lifespan (hrs)": round(float(np.percentile(durations_arr, 25)), 2),
            "Median/P50 Lifespan (hrs)": round(float(np.median(durations_arr)), 2),
            "P75 Lifespan (hrs)": round(float(np.percentile(durations_arr, 75)), 2),
            "P85 Lifespan (hrs)": round(float(np.percentile(durations_arr, 85)), 2),
            "P90 Lifespan (hrs)": round(float(np.percentile(durations_arr, 90)), 2),
            "P95 Lifespan (hrs)": round(float(np.percentile(durations_arr, 95)), 2),
            "P99 Lifespan (hrs)": round(float(np.percentile(durations_arr, 99)), 2),
            "Max Lifespan (hrs)": int(durations_arr.max()),
            "Min Lifespan (hrs)": int(durations_arr.min()),
            "Full Uptime (>=20h)": int(np.sum(durations_arr >= 20)),
            "High Uptime (12-19h)": int(np.sum((durations_arr >= 12) & (durations_arr < 20))),
            "Moderate Uptime (6-11h)": int(np.sum((durations_arr >= 6) & (durations_arr < 12))),
            "Low Uptime (<6h)": int(np.sum(durations_arr < 6))
        })

    df_summary_matrix = pd.DataFrame(computed_metrics)
    if df_summary_matrix.empty:
        print(f"[CHRONO-UPTIME-WARNING] Summary matrix empty for context: {context_label}")
        return None

    # Daily Plot Generation
    plt.figure(figsize=(14, 6))
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Mean Lifespan (hrs)"], marker='o', color='purple', linewidth=2, label='Mean Session Duration')
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Median/P50 Lifespan (hrs)"], marker='s', color='teal', linewidth=2, label='Median (P50)')
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["P85 Lifespan (hrs)"], marker='^', color='crimson', linewidth=1.5, linestyle='--', label='P85 Upper Percentile')
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["P15 Lifespan (hrs)"], marker='v', color='darkgreen', linewidth=1.5, linestyle='--', label='P15 Lower Percentile')

    for x, y in zip(df_summary_matrix["Observation Date"], df_summary_matrix["Mean Lifespan (hrs)"]):
        plt.annotate(f"{y}h", (x, y), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=8)

    plt.title(f"Tor v3 Chronological HSDir Operational Lifespan & Percentile Profile ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Lifespan (Hours)")
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"analysis-results/chronological_uptime/{context_label}_daily_chronological_uptime.png")
    plt.close()

    daily_totals = {"Observation Date": "Overall Average"}
    for col in df_summary_matrix.columns:
        if col != "Observation Date":
            daily_totals[col] = round(df_summary_matrix[col].mean(), 2)

    df_summary_export = pd.concat([df_summary_matrix, pd.DataFrame([daily_totals])], ignore_index=True)
    df_summary_export.to_csv(f"analysis-results/chronological_uptime/{context_label}_daily_chronological_uptime_matrix.csv", index=False)

    print(f"[CHRONO-UPTIME-INFO] Complete chronological matrices and percentiles saved under label: '{context_label}'")
    return df_summary_matrix