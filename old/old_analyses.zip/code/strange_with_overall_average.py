def compute_strange_churn_behaviour_analysis(df_slice, df_events, context_label):
    output_dir = "analysis-results/strange_churn_behaviour"
    os.makedirs(output_dir, exist_ok=True)
    
    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    def clear_hour_to_float(hour_str):
        if pd.isna(hour_str) or not isinstance(hour_str, str) or ":" not in hour_str:
            return 0.0
        try:
            parts = hour_str.split(":")
            return int(parts[0]) + int(parts[1]) / 60.0
        except Exception:
            return 0.0

    if df_slice.empty:
        print(f"[STRANGE-WARNING] Empty snapshot data slice received for context: {context_label}")
        return None

    # Filter failed ring events (action == FAILED and reason == NOT_FOUND)
    if df_events is None or df_events.empty:
        df_failed_events = pd.DataFrame(columns=["date", "hour", "action", "reason", "fingerprint"])
    else:
        df_failed_events = df_events[
            (df_events["action"] == "FAILED") & (df_events["reason"] == "NOT_FOUND")
        ].copy()

    df_working_snapshots = df_slice.copy()
    df_working_snapshots["hour_float"] = df_working_snapshots["hour"].apply(clear_hour_to_float)
    df_failed_events["hour_float"] = df_failed_events["hour"].apply(clear_hour_to_float) if "hour" in df_failed_events.columns else 0.0

    unique_days = [d for d in df_working_snapshots["date"].unique() if d not in ['', 'None', None]]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)
    
    computed_daily_metrics = []

    for observation_day in unique_days_sorted:
        day_snapshots = df_working_snapshots[df_working_snapshots["date"] == observation_day]
        day_events = df_failed_events[df_failed_events["date"] == observation_day]
        
        # Total uniquely identified HSDir fingerprints overall for this observation day
        total_unique_day_fps = day_snapshots["fingerprint"].nunique()
        
        active_snapshots = day_snapshots[day_snapshots["status"] == "ACTIVE_IN_RING"]
        inactive_snapshots = day_snapshots[day_snapshots["status"] != "ACTIVE_IN_RING"]
        
        total_unique_active_fps = active_snapshots["fingerprint"].nunique()
        total_unique_inactive_fps = inactive_snapshots["fingerprint"].nunique()
        
        strange_fps_this_day = set()
        not_strange_fps_this_day = set()
        
        if not day_events.empty and not day_snapshots.empty:
            snapshot_hours = np.array(sorted(day_snapshots["hour_float"].unique()))
            
            for _, event_row in day_events.iterrows():
                ev_hour = event_row["hour_float"]
                closest_snap_hour = snapshot_hours[np.argmin(np.abs(snapshot_hours - ev_hour))]
                
                # Snapshots matching closest hour
                hour_snaps = day_snapshots[day_snapshots["hour_float"] == closest_snap_hour]
                hour_active_snaps = hour_snaps[hour_snaps["status"] == "ACTIVE_IN_RING"]
                hour_inactive_snaps = hour_snaps[hour_snaps["status"] != "ACTIVE_IN_RING"]
                
                ev_fp = event_row.get("fingerprint", "None")
                if ev_fp != "None" and pd.notna(ev_fp):
                    matched_active = hour_active_snaps[hour_active_snaps["fingerprint"] == ev_fp]["fingerprint"].unique()
                    matched_inactive = hour_inactive_snaps[hour_inactive_snaps["fingerprint"] == ev_fp]["fingerprint"].unique()
                    
                    strange_fps_this_day.update(matched_active)
                    not_strange_fps_this_day.update(matched_inactive)
                    
                    if len(matched_active) == 0 and len(matched_inactive) == 0:
                        if ev_fp in active_snapshots["fingerprint"].values:
                            strange_fps_this_day.add(ev_fp)
                        else:
                            not_strange_fps_this_day.add(ev_fp)
                else:
                    strange_fps_this_day.update(hour_active_snaps["fingerprint"].unique())
                    not_strange_fps_this_day.update(hour_inactive_snaps["fingerprint"].unique())
        
        strange_count = len(strange_fps_this_day)
        not_strange_count = len(not_strange_fps_this_day)
        
        # Percentages over total uniquely identified HSDir nodes ("fingerprint")
        pct_strange_of_total = (strange_count / total_unique_day_fps * 100) if total_unique_day_fps > 0 else 0.0
        pct_not_strange_of_total = (not_strange_count / total_unique_day_fps * 100) if total_unique_day_fps > 0 else 0.0
        
        computed_daily_metrics.append({
            "Observation Date": observation_day,
            "Total Unique HSDirs": total_unique_day_fps,
            "Total Unique Active HSDirs": total_unique_active_fps,
            "Total Unique Inactive HSDirs": total_unique_inactive_fps,
            "Strange Behaviour Count": strange_count,
            "Strange % of Total HSDirs": round(pct_strange_of_total, 2),
            "Not Strange Behaviour Count": not_strange_count,
            "Not Strange % of Total HSDirs": round(pct_not_strange_of_total, 2)
        })

    df_daily_matrix = pd.DataFrame(computed_daily_metrics)
    if df_daily_matrix.empty:
        print(f"[STRANGE-ERROR] Core metric matrix is empty for context: {context_label}")
        return None

    # -------------------------------------------------------------------------
    # PLOT 1: GENERAL HSDIR NODES DAILY COUNT PROGRESSION (WITH AVERAGES)
    # -------------------------------------------------------------------------
    plt.figure(figsize=(14, 6))
    
    avg_strange_count = df_daily_matrix["Strange Behaviour Count"].mean()
    avg_not_strange_count = df_daily_matrix["Not Strange Behaviour Count"].mean()

    plt.plot(df_daily_matrix["Observation Date"], df_daily_matrix["Strange Behaviour Count"], 
             marker='o', color='darkred', linewidth=2.5, label='Strange Behaviour (Active status, Failed action)')
    plt.plot(df_daily_matrix["Observation Date"], df_daily_matrix["Not Strange Behaviour Count"], 
             marker='s', color='skyblue', linewidth=2, label='Not Strange Behaviour (Inactive status, Failed action)')
    
    # Horizontal average lines
    plt.axhline(y=avg_strange_count, color='firebrick', linestyle='--', linewidth=1.5, 
                label=f'Avg Strange Count ({avg_strange_count:.2f})')
    plt.axhline(y=avg_not_strange_count, color='dodgerblue', linestyle=':', linewidth=1.5, 
                label=f'Avg Not Strange Count ({avg_not_strange_count:.2f})')

    for x, y in zip(df_daily_matrix["Observation Date"], df_daily_matrix["Strange Behaviour Count"]):
        plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=9, fontweight='bold')
    for x, y in zip(df_daily_matrix["Observation Date"], df_daily_matrix["Not Strange Behaviour Count"]):
        plt.annotate(f"{int(y)}", (x, y), textcoords="offset points", xytext=(0, -12), ha='center', fontsize=9)
        
    plt.title(f"Tor v3 HSDir Strange vs Normal Failure Count Progression ({context_label.replace('_', ' ').title()} - Daily)")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Unique Relay Count (Fingerprints)")
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_strange_vs_normal_daily_progression.png")
    plt.close()

    # -------------------------------------------------------------------------
    # PLOT 2: PERCENTAGE OF STRANGE & NON-STRANGE OVER TOTAL UNIQUE HSDIRS
    # -------------------------------------------------------------------------
    plt.figure(figsize=(14, 6))
    
    plt.plot(df_daily_matrix["Observation Date"], df_daily_matrix["Strange % of Total HSDirs"], 
             marker='o', color='darkred', linewidth=2.5, label='Strange Behaviour (% of Total HSDirs)')
    plt.plot(df_daily_matrix["Observation Date"], df_daily_matrix["Not Strange % of Total HSDirs"], 
             marker='s', color='skyblue', linewidth=2, label='Not Strange Behaviour (% of Total HSDirs)')
    
    for x, y in zip(df_daily_matrix["Observation Date"], df_daily_matrix["Strange % of Total HSDirs"]):
        plt.annotate(f"{y:.2f}%", (x, y), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=9, fontweight='bold')
    for x, y in zip(df_daily_matrix["Observation Date"], df_daily_matrix["Not Strange % of Total HSDirs"]):
        plt.annotate(f"{y:.2f}%", (x, y), textcoords="offset points", xytext=(0, -12), ha='center', fontsize=9)
        
    max_pct = max(df_daily_matrix["Strange % of Total HSDirs"].max(), df_daily_matrix["Not Strange % of Total HSDirs"].max())
    plt.ylim(0, max_pct * 1.15 + 1)
    
    plt.title(f"Tor v3 HSDir Strange vs Normal Behaviour Percentage ({context_label.replace('_', ' ').title()} - Daily)")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Percentage of Total Unique HSDir Nodes (%)")
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"{output_dir}/{context_label}_strange_vs_normal_daily_percentage_progression.png")
    plt.close()

    # Export General Daily Matrix
    daily_totals = {
        "Observation Date": "Overall Average",
        "Total Unique HSDirs": round(df_daily_matrix["Total Unique HSDirs"].mean(), 2),
        "Total Unique Active HSDirs": round(df_daily_matrix["Total Unique Active HSDirs"].mean(), 2),
        "Total Unique Inactive HSDirs": round(df_daily_matrix["Total Unique Inactive HSDirs"].mean(), 2),
        "Strange Behaviour Count": round(df_daily_matrix["Strange Behaviour Count"].mean(), 2),
        "Strange % of Total HSDirs": round(df_daily_matrix["Strange % of Total HSDirs"].mean(), 2),
        "Not Strange Behaviour Count": round(df_daily_matrix["Not Strange Behaviour Count"].mean(), 2),
        "Not Strange % of Total HSDirs": round(df_daily_matrix["Not Strange % of Total HSDirs"].mean(), 2)
    }
    df_daily_export = pd.concat([df_daily_matrix, pd.DataFrame([daily_totals])], ignore_index=True)
    df_daily_export.to_csv(f"{output_dir}/{context_label}_strange_vs_normal_daily_matrix.csv", index=False)

    # -------------------------------------------------------------------------
    # PLOT 3: PER ONION SERVICE STRANGE/NORMAL BEHAVIOUR ANALYSIS
    # -------------------------------------------------------------------------
    onion_col = "mapped_onion" if "mapped_onion" in df_working_snapshots.columns else (
        "last_known_onion" if "last_known_onion" in df_working_snapshots.columns else "onion_address"
    )

    if onion_col in df_working_snapshots.columns:
        unique_onions = [o for o in df_working_snapshots[onion_col].unique() if o not in ['', 'None', None, 'nan']]
        onion_daily_records = []
        
        for onion_addr in unique_onions:
            onion_snaps = df_working_snapshots[df_working_snapshots[onion_col] == onion_addr]
            
            if df_events is not None and not df_events.empty and onion_col in df_events.columns:
                onion_events = df_failed_events[df_failed_events[onion_col] == onion_addr]
            elif df_events is not None and not df_events.empty and "onion_address" in df_events.columns:
                onion_events = df_failed_events[df_failed_events["onion_address"] == onion_addr]
            else:
                onion_events = pd.DataFrame()
                
            for obs_day in unique_days_sorted:
                day_o_snaps = onion_snaps[onion_snaps["date"] == obs_day]
                day_o_events = onion_events[onion_events["date"] == obs_day] if not onion_events.empty else pd.DataFrame()
                
                o_strange_fps = set()
                o_not_strange_fps = set()
                
                if not day_o_events.empty and not day_o_snaps.empty:
                    snap_hours = np.array(sorted(day_o_snaps["hour_float"].unique()))
                    for _, ev_row in day_o_events.iterrows():
                        ev_h = ev_row["hour_float"]
                        closest_h = snap_hours[np.argmin(np.abs(snap_hours - ev_h))]
                        
                        hr_snaps = day_o_snaps[day_o_snaps["hour_float"] == closest_h]
                        ev_fp = ev_row.get("fingerprint", "None")
                        
                        if ev_fp != "None" and pd.notna(ev_fp):
                            if not hr_snaps[hr_snaps["fingerprint"] == ev_fp].empty:
                                is_act = hr_snaps[hr_snaps["fingerprint"] == ev_fp]["status"].iloc[0] == "ACTIVE_IN_RING"
                                (o_strange_fps if is_act else o_not_strange_fps).add(ev_fp)
                            else:
                                o_strange_fps.add(ev_fp)
                        else:
                            o_strange_fps.update(hr_snaps[hr_snaps["status"] == "ACTIVE_IN_RING"]["fingerprint"].unique())
                            o_not_strange_fps.update(hr_snaps[hr_snaps["status"] != "ACTIVE_IN_RING"]["fingerprint"].unique())
                            
                onion_daily_records.append({
                    "Onion Service": onion_addr,
                    "Observation Date": obs_day,
                    "Strange Behaviour Count": len(o_strange_fps),
                    "Not Strange Behaviour Count": len(o_not_strange_fps)
                })

        df_onion_daily = pd.DataFrame(onion_daily_records)
        
        if not df_onion_daily.empty:
            plt.figure(figsize=(14, 7))
            unique_onion_list = list(df_onion_daily["Onion Service"].unique())
            
            for onion_addr in unique_onion_list:
                sub_o = df_onion_daily[df_onion_daily["Onion Service"] == onion_addr]
                
                # Plot lines without displaying individual onion names in legend
                plt.plot(sub_o["Observation Date"], sub_o["Strange Behaviour Count"], 
                         marker='o', linestyle='-', color='navy', alpha=0.7, linewidth=1.8)
                plt.plot(sub_o["Observation Date"], sub_o["Not Strange Behaviour Count"], 
                         marker='x', linestyle='--', color='lightseagreen', alpha=0.6, linewidth=1.5)

            # Custom Legend without onion service names
            legend_elements = [
                Line2D([0], [0], color='navy', marker='o', lw=2, label='Strange Behaviour'),
                Line2D([0], [0], color='lightseagreen', marker='x', lw=2, linestyle='--', label='Not Strange Behaviour')
            ]

            plt.title(f"Tor v3 Per-Onion Strange vs Normal Behaviour Progression ({context_label.replace('_', ' ').title()})")
            plt.xlabel("Observation Timeline")
            plt.ylabel("Absolute Node Count")
            plt.xticks(rotation=45)
            plt.legend(handles=legend_elements, loc="upper right", fontsize=10)
            plt.tight_layout()
            plt.savefig(f"{output_dir}/{context_label}_per_onion_strange_behaviour_progression.png")
            plt.close()

            # Save clean Onion Analysis Matrix
            df_onion_daily.to_csv(f"{output_dir}/{context_label}_onion_strange_behaviour_matrix.csv", index=False)

    print(f"[STRANGE-INFO] Strange vs Normal behaviour analysis successfully executed for context: '{context_label}'")
    return df_daily_matrix


def strange_churn_behaviour_analysis(df, df_events, context_label):
    print(f"=== PROCESSING {context_label.upper()} STRANGE CHURN BEHAVIOUR ANALYSIS ===")
    if df is None or df.empty:
        print(f"[STRANGE-ERROR] Missing input data layout for context '{context_label}'.")
        return None
        
    global_reporting_matrix = compute_strange_churn_behaviour_analysis(df, df_events, context_label)
    
    if context_label in ["tracked_targets", "rotated_tracked_targets"] and "service_type" in df.columns:
        unique_services = df["service_type"].dropna().unique()
        unique_services = [s for s in unique_services if s not in ['', 'nan', 'None', None]]
        
        for service in unique_services:
            print(f"    --> Isolating strange churn failures for hidden service type: {service}")
            sub_population_df = df[df["service_type"] == service]
            if not sub_population_df.empty:
                segmented_label = f"{context_label}_{str(service).lower()}"
                compute_strange_churn_behaviour_analysis(sub_population_df, df_events, segmented_label)
                
    return global_reporting_matrix

def compute_chronological_uptime(df_slice, context_label):
    os.makedirs("analysis-results/chronological_uptime", exist_ok=True)
    computed_metrics = []

    def get_day_integer(day_str):
        if isinstance(day_str, str) and len(day_str.split()) > 1 and day_str.split()[1].isdigit():
            return int(day_str.split()[1])
        return 0

    if "hour" not in df_slice.columns or "fingerprint" not in df_slice.columns:
        print(f"[CHRONO-UPTIME-ERROR] Missing critical structural fields ('hour' or 'fingerprint') for label: {context_label}")
        return None

    df_working = df_slice.copy()

    # -------------------------------------------------------------------------
    # 1. GHOST NODE FILTERING (consecutive_hourly_absences <= 1)
    # -------------------------------------------------------------------------
    if "consecutive_hourly_absences" in df_working.columns:
        df_working = df_working[
            df_working["consecutive_hourly_absences"].isna() | 
            (df_working["consecutive_hourly_absences"] <= 1)
        ]

    df_working = df_working[
        df_working['fingerprint'].notna() & (~df_working['fingerprint'].isin(['None', '', 'nan']))
    ]

    if df_working.empty:
        print(f"[CHRN-UPTIME-WARNING] No valid records after filtering for context: {context_label}")
        return None
    
    # Hour numerical normalization
    if df_working["hour"].dtype == object or isinstance(df_working["hour"].iloc[0], str):
        if df_working["hour"].str.contains(":").any():
            hour_parts = df_working["hour"].str.split(":", expand=True)
            df_working["hour_num"] = hour_parts[0].astype(int) + hour_parts[1].astype(int) / 60.0
        else:
            df_working["hour_num"] = pd.to_numeric(df_working["hour"], errors='coerce').fillna(0)
    else:
        df_working["hour_num"] = df_working["hour"].astype(float)

    # Key identification: onion target field mapping vs general HSDir fallback
    onion_col = None
    if "mapped_onion" in df_working.columns:
        onion_col = "mapped_onion"
    elif "last_known_onion" in df_working.columns:
        onion_col = "last_known_onion"
    elif "onion_address" in df_working.columns:
        onion_col = "onion_address"

    unique_days = [d for d in df_working["date"].unique() if d not in ['', 'None', None]]
    unique_days_sorted = sorted(unique_days, key=get_day_integer)

    for observation_day in unique_days_sorted:
        day_data = df_working[df_working["date"] == observation_day]
        all_session_durations = []

        if onion_col and day_data[onion_col].nunique() > 0 and (day_data[onion_col] != 'None').any():
            # Grouped execution per onion target and fingerprint
            unique_onions = [o for o in day_data[onion_col].unique() if o not in ['None', '', None]]
            for onion in unique_onions:
                onion_data = day_data[day_data[onion_col] == onion]
                for fp in onion_data["fingerprint"].unique():
                    if fp in ['None', '', None]:
                        continue
                    df_fp = onion_data[onion_data["fingerprint"] == fp].sort_values(by="hour_num")
                    
                    current_start = None
                    current_last = None
                    
                    for _, row in df_fp.iterrows():
                        is_active = row.get("status", "ACTIVE_IN_RING") in ["ACTIVE_IN_RING", "None"]
                        has_temporal_gap = (current_last is not None) and (row["hour_num"] - current_last > 2.5)
                        
                        if is_active and not has_temporal_gap:
                            if current_start is None:
                                current_start = row["hour_num"]
                            current_last = row["hour_num"]
                        else:
                            if current_start is not None:
                                duration = max(1.0, current_last - current_start)
                                all_session_durations.append(duration)
                            
                            if is_active:
                                current_start = row["hour_num"]
                                current_last = row["hour_num"]
                            else:
                                current_start = None
                                current_last = None
                    
                    if current_start is not None:
                        duration = max(1.0, current_last - current_start)
                        all_session_durations.append(duration)
        else:
            # Fallback: General daily HSDir uptime distribution analysis
            for fp in day_data["fingerprint"].unique():
                if fp in ['None', '', None]:
                    continue
                df_fp = day_data[day_data["fingerprint"] == fp].sort_values(by="hour_num")
                
                current_start = None
                current_last = None
                
                for _, row in df_fp.iterrows():
                    is_active = row.get("status", "ACTIVE_IN_RING") in ["ACTIVE_IN_RING", "None"]
                    has_temporal_gap = (current_last is not None) and (row["hour_num"] - current_last > 2.5)
                    
                    if is_active and not has_temporal_gap:
                        if current_start is None:
                            current_start = row["hour_num"]
                        current_last = row["hour_num"]
                    else:
                        if current_start is not None:
                            duration = max(1.0, current_last - current_start)
                            all_session_durations.append(duration)
                        
                        if is_active:
                            current_start = row["hour_num"]
                            current_last = row["hour_num"]
                        else:
                            current_start = None
                            current_last = None
                
                if current_start is not None:
                    duration = max(1.0, current_last - current_start)
                    all_session_durations.append(duration)

        total_sessions = len(all_session_durations)
        if total_sessions == 0:
            continue

        durations_arr = np.array(all_session_durations)

        computed_metrics.append({
            "Observation Date": observation_day,
            "Total Sessions": total_sessions,
            "Mean Lifespan (hrs)": round(float(durations_arr.mean()), 2),
            "P15 Lifespan (hrs)": round(float(np.percentile(durations_arr, 15)), 2),
            "P25 Lifespan (hrs)": round(float(np.percentile(durations_arr, 25)), 2),
            "Median/P50 Lifespan (hrs)": round(float(np.median(durations_arr)), 2),
            "P75 Lifespan (hrs)": round(float(np.percentile(durations_arr, 75)), 2),
            "P85 Lifespan (hrs)": round(float(np.percentile(durations_arr, 85)), 2),
            "P90 Lifespan (hrs)": round(float(np.percentile(durations_arr, 90)), 2),
            "P95 Lifespan (hrs)": round(float(np.percentile(durations_arr, 95)), 2),
            "P99 Lifespan (hrs)": round(float(np.percentile(durations_arr, 99)), 2),
            "Max Lifespan (hrs)": int(durations_arr.max()),
            "Min Lifespan (hrs)": int(durations_arr.min()),
            "Full Uptime (>=20h)": int(np.sum(durations_arr >= 20)),
            "High Uptime (12-19h)": int(np.sum((durations_arr >= 12) & (durations_arr < 20))),
            "Moderate Uptime (6-11h)": int(np.sum((durations_arr >= 6) & (durations_arr < 12))),
            "Low Uptime (<6h)": int(np.sum(durations_arr < 6))
        })

    df_summary_matrix = pd.DataFrame(computed_metrics)
    if df_summary_matrix.empty:
        print(f"[CHRONO-UPTIME-WARNING] Summary matrix empty for context: {context_label}")
        return None

    # Daily Plot Generation
    plt.figure(figsize=(14, 6))
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Mean Lifespan (hrs)"], marker='o', color='purple', linewidth=2, label='Mean Session Duration')
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["Median/P50 Lifespan (hrs)"], marker='s', color='teal', linewidth=2, label='Median (P50)')
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["P85 Lifespan (hrs)"], marker='^', color='crimson', linewidth=1.5, linestyle='--', label='P85 Upper Percentile')
    plt.plot(df_summary_matrix["Observation Date"], df_summary_matrix["P15 Lifespan (hrs)"], marker='v', color='darkgreen', linewidth=1.5, linestyle='--', label='P15 Lower Percentile')

    for x, y in zip(df_summary_matrix["Observation Date"], df_summary_matrix["Mean Lifespan (hrs)"]):
        plt.annotate(f"{y}h", (x, y), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=8)

    plt.title(f"Tor v3 Chronological HSDir Operational Lifespan & Percentile Profile ({context_label.replace('_', ' ').title()})")
    plt.xlabel("Observation Timeline")
    plt.ylabel("Lifespan (Hours)")
    plt.xticks(rotation=45)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(f"analysis-results/chronological_uptime/{context_label}_daily_chronological_uptime.png")
    plt.close()

    daily_totals = {"Observation Date": "Overall Average"}
    for col in df_summary_matrix.columns:
        if col != "Observation Date":
            daily_totals[col] = round(df_summary_matrix[col].mean(), 2)

    df_summary_export = pd.concat([df_summary_matrix, pd.DataFrame([daily_totals])], ignore_index=True)
    df_summary_export.to_csv(f"analysis-results/chronological_uptime/{context_label}_daily_chronological_uptime_matrix.csv", index=False)

    print(f"[CHRONO-UPTIME-INFO] Complete chronological matrices and percentiles saved under label: '{context_label}'")
    return df_summary_matrix